/*
  # Add videos table for educational content

  1. New Tables
    - `videos`
      - `id` (uuid, primary key)
      - `url` (text, required)
      - `title` (text, required)
      - `level` (text, required)
      - `tags` (text[], required)
      - `created_at` (timestamptz)
      - `created_by` (uuid, references auth.users)

  2. Security
    - Enable RLS on `videos` table
    - Add policies for:
      - All authenticated users can read videos
      - All authenticated users can insert videos
*/

CREATE TABLE IF NOT EXISTS videos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  url text NOT NULL,
  title text NOT NULL,
  level text NOT NULL,
  tags text[] NOT NULL,
  created_at timestamptz DEFAULT now(),
  created_by uuid REFERENCES auth.users(id) DEFAULT auth.uid()
);

-- Add constraint to ensure level is one of the allowed values
ALTER TABLE videos ADD CONSTRAINT videos_level_check 
  CHECK (level IN ('superbeginner', 'beginner', 'intermediate', 'advanced'));

-- Create index for faster filtering
CREATE INDEX videos_level_idx ON videos(level);
CREATE INDEX videos_tags_idx ON videos USING gin(tags);

-- Enable RLS
ALTER TABLE videos ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Anyone can read videos"
  ON videos
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert videos"
  ON videos
  FOR INSERT
  TO authenticated
  WITH CHECK (true);