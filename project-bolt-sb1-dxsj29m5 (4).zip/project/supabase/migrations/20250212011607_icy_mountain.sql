/*
  # Add Leaderboard Support

  1. New Tables
    - `user_profiles`
      - User profile information and achievements
    - `user_achievements`
      - Track user achievements and badges
    - `user_stats`
      - Aggregate user statistics
  
  2. Security
    - Enable RLS on all tables
    - Add policies for read/write access
    
  3. Functions
    - Add functions for stats calculation
    - Add achievement tracking
*/

-- Create user_profiles table
CREATE TABLE IF NOT EXISTS user_profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name text,
  avatar_url text,
  bio text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create user_achievements table
CREATE TABLE IF NOT EXISTS user_achievements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  achievement_type text NOT NULL,
  achievement_data jsonb DEFAULT '{}'::jsonb,
  unlocked_at timestamptz DEFAULT now(),
  UNIQUE(user_id, achievement_type)
);

-- Create user_stats table
CREATE TABLE IF NOT EXISTS user_stats (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  current_streak integer DEFAULT 0,
  longest_streak integer DEFAULT 0,
  total_minutes integer DEFAULT 0,
  weekly_minutes integer DEFAULT 0,
  monthly_minutes integer DEFAULT 0,
  total_videos_watched integer DEFAULT 0,
  level integer DEFAULT 1,
  last_activity_at timestamptz,
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_achievements ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_stats ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Public profiles are viewable by everyone"
  ON user_profiles
  FOR SELECT
  USING (true);

CREATE POLICY "Users can update own profile"
  ON user_profiles
  FOR UPDATE
  USING (auth.uid() = id);

CREATE POLICY "Achievements are viewable by everyone"
  ON user_achievements
  FOR SELECT
  USING (true);

CREATE POLICY "Stats are viewable by everyone"
  ON user_stats
  FOR SELECT
  USING (true);

-- Create function to update user stats
CREATE OR REPLACE FUNCTION update_user_stats()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_streak integer;
  v_total_minutes integer;
  v_weekly_minutes integer;
  v_monthly_minutes integer;
  v_total_videos integer;
BEGIN
  -- Calculate current streak
  SELECT 
    COUNT(DISTINCT date)::integer INTO v_streak
  FROM time_entries
  WHERE user_id = NEW.user_id
    AND date > CURRENT_DATE - INTERVAL '30 days'
    AND date <= CURRENT_DATE
  GROUP BY user_id;

  -- Calculate total minutes
  SELECT 
    COALESCE(SUM(minutes), 0)::integer INTO v_total_minutes
  FROM time_entries
  WHERE user_id = NEW.user_id;

  -- Calculate weekly minutes
  SELECT 
    COALESCE(SUM(minutes), 0)::integer INTO v_weekly_minutes
  FROM time_entries
  WHERE user_id = NEW.user_id
    AND date > CURRENT_DATE - INTERVAL '7 days';

  -- Calculate monthly minutes
  SELECT 
    COALESCE(SUM(minutes), 0)::integer INTO v_monthly_minutes
  FROM time_entries
  WHERE user_id = NEW.user_id
    AND date > CURRENT_DATE - INTERVAL '30 days';

  -- Calculate total videos watched
  SELECT 
    COUNT(DISTINCT video_id)::integer INTO v_total_videos
  FROM time_entries
  WHERE user_id = NEW.user_id
    AND video_id IS NOT NULL;

  -- Update user stats
  INSERT INTO user_stats (
    user_id,
    current_streak,
    total_minutes,
    weekly_minutes,
    monthly_minutes,
    total_videos_watched,
    last_activity_at,
    updated_at
  ) VALUES (
    NEW.user_id,
    v_streak,
    v_total_minutes,
    v_weekly_minutes,
    v_monthly_minutes,
    v_total_videos,
    NOW(),
    NOW()
  )
  ON CONFLICT (user_id) DO UPDATE
  SET
    current_streak = EXCLUDED.current_streak,
    longest_streak = GREATEST(user_stats.longest_streak, EXCLUDED.current_streak),
    total_minutes = EXCLUDED.total_minutes,
    weekly_minutes = EXCLUDED.weekly_minutes,
    monthly_minutes = EXCLUDED.monthly_minutes,
    total_videos_watched = EXCLUDED.total_videos_watched,
    last_activity_at = EXCLUDED.last_activity_at,
    updated_at = EXCLUDED.updated_at;

  RETURN NEW;
END;
$$;

-- Create trigger to update stats
CREATE TRIGGER update_user_stats_trigger
  AFTER INSERT OR UPDATE ON time_entries
  FOR EACH ROW
  EXECUTE FUNCTION update_user_stats();

-- Create indexes
CREATE INDEX user_achievements_user_type_idx ON user_achievements(user_id, achievement_type);
CREATE INDEX user_stats_weekly_minutes_idx ON user_stats(weekly_minutes DESC);
CREATE INDEX user_stats_monthly_minutes_idx ON user_stats(monthly_minutes DESC);
CREATE INDEX user_stats_current_streak_idx ON user_stats(current_streak DESC);