/*
  # Add video_id column to time_entries table

  1. Changes
    - Add video_id column to time_entries table
    - Add foreign key constraint to videos table
    - Update trigger function to handle video_id properly

  2. Security
    - Maintain referential integrity with videos table
    - Keep existing RLS policies
*/

-- Add video_id column if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'time_entries' AND column_name = 'video_id'
  ) THEN
    ALTER TABLE time_entries 
      ADD COLUMN video_id uuid REFERENCES videos(id) ON DELETE SET NULL;
  END IF;
END $$;

-- Update the trigger function to handle the video_id properly
CREATE OR REPLACE FUNCTION handle_time_entry_delete()
RETURNS TRIGGER AS $$
BEGIN
  -- Only proceed if this is a video watching entry
  IF OLD.activity_type = 'watching' AND OLD.video_id IS NOT NULL THEN
    -- Delete corresponding watched_videos entry if it exists
    DELETE FROM watched_videos
    WHERE video_id = OLD.video_id
    AND user_id = OLD.user_id;
  END IF;
  
  RETURN OLD;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Recreate the trigger
DROP TRIGGER IF EXISTS time_entry_delete_trigger ON time_entries;
CREATE TRIGGER time_entry_delete_trigger
  AFTER DELETE ON time_entries
  FOR EACH ROW
  EXECUTE FUNCTION handle_time_entry_delete();