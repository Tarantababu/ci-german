/*
  # Add comment interactions and replies

  1. Changes
    - Add parent_id to video_comments for replies
    - Create comment_likes table for tracking likes/dislikes
    - Add proper indexes and constraints
    - Update policies for interactions

  2. Security
    - Enable RLS on new tables
    - Add proper access control
*/

-- Add parent_id to video_comments if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'video_comments' AND column_name = 'parent_id'
  ) THEN
    ALTER TABLE video_comments 
      ADD COLUMN parent_id uuid REFERENCES video_comments(id) ON DELETE CASCADE;
  END IF;
END $$;

-- Create comment_likes table
CREATE TABLE comment_likes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  comment_id uuid REFERENCES video_comments(id) ON DELETE CASCADE,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE DEFAULT auth.uid(),
  is_like boolean NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(comment_id, user_id)
);

-- Enable RLS
ALTER TABLE comment_likes ENABLE ROW LEVEL SECURITY;

-- Create indexes
CREATE INDEX comment_likes_user_idx ON comment_likes(user_id);
CREATE INDEX comment_likes_comment_idx ON comment_likes(comment_id);
CREATE INDEX video_comments_parent_idx ON video_comments(parent_id);

-- Create policies for comment_likes
CREATE POLICY "Users can manage own likes"
  ON comment_likes
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create function to handle comment likes
CREATE OR REPLACE FUNCTION handle_comment_like()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Update comment like/dislike counts
  IF TG_OP = 'INSERT' THEN
    UPDATE video_comments
    SET 
      likes = CASE WHEN NEW.is_like THEN likes + 1 ELSE likes END,
      dislikes = CASE WHEN NOT NEW.is_like THEN dislikes + 1 ELSE dislikes END
    WHERE id = NEW.comment_id;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE video_comments
    SET 
      likes = CASE WHEN OLD.is_like THEN likes - 1 ELSE likes END,
      dislikes = CASE WHEN NOT OLD.is_like THEN dislikes - 1 ELSE dislikes END
    WHERE id = OLD.comment_id;
  ELSIF TG_OP = 'UPDATE' AND OLD.is_like != NEW.is_like THEN
    UPDATE video_comments
    SET 
      likes = CASE 
        WHEN NEW.is_like THEN likes + 1
        ELSE likes - 1
      END,
      dislikes = CASE 
        WHEN NOT NEW.is_like THEN dislikes + 1
        ELSE dislikes - 1
      END
    WHERE id = NEW.comment_id;
  END IF;
  
  RETURN NEW;
END;
$$;

-- Create triggers for like handling
CREATE TRIGGER handle_comment_like_trigger
  AFTER INSERT OR UPDATE OR DELETE ON comment_likes
  FOR EACH ROW
  EXECUTE FUNCTION handle_comment_like();