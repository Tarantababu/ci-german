/*
  # Add watched videos tracking

  1. New Tables
    - `watched_videos`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `video_id` (uuid, references videos)
      - `watched_at` (timestamptz)

  2. Security
    - Enable RLS on `watched_videos` table
    - Add policies for authenticated users to manage their watched status
*/

CREATE TABLE IF NOT EXISTS watched_videos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) DEFAULT auth.uid(),
  video_id uuid REFERENCES videos(id) ON DELETE CASCADE,
  watched_at timestamptz DEFAULT now(),
  UNIQUE(user_id, video_id)
);

-- Enable RLS
ALTER TABLE watched_videos ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Users can read own watched videos"
  ON watched_videos
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own watched status"
  ON watched_videos
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Users can delete own watched status"
  ON watched_videos
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create index for faster lookups
CREATE INDEX watched_videos_user_video_idx ON watched_videos(user_id, video_id);