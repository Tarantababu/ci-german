/*
  # Add cascade delete trigger for time entries

  1. Changes
    - Add trigger function to handle cascade delete from time_entries to watched_videos
    - Add trigger to time_entries table
    - Add function to safely delete watched_videos entries

  2. Security
    - Function is marked as SECURITY DEFINER to run with elevated privileges
    - Checks for user_id match before deleting from watched_videos
*/

-- Create function to handle cascade delete
CREATE OR REPLACE FUNCTION handle_time_entry_delete()
RETURNS TRIGGER AS $$
BEGIN
  -- Only proceed if this is a video watching entry
  IF OLD.activity_type = 'watching' AND OLD.video_id IS NOT NULL THEN
    -- Delete corresponding watched_videos entry if it exists
    DELETE FROM watched_videos
    WHERE video_id = OLD.video_id
    AND user_id = OLD.user_id;
  END IF;
  
  RETURN OLD;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger on time_entries table
DROP TRIGGER IF EXISTS time_entry_delete_trigger ON time_entries;
CREATE TRIGGER time_entry_delete_trigger
  AFTER DELETE ON time_entries
  FOR EACH ROW
  EXECUTE FUNCTION handle_time_entry_delete();