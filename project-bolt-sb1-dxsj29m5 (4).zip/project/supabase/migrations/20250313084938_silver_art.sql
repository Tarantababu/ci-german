/*
  # Add badge system and social features

  1. Changes
    - Add user_badges table for achievements
    - Add user_friends table for social connections
    - Add user_reactions table for engagement
    - Add user_comments table for community interaction
  
  2. Security
    - Enable RLS
    - Add proper access control
*/

-- Drop existing trigger first
DROP TRIGGER IF EXISTS check_badges_trigger ON user_stats;

-- Create function to check and award badges first
CREATE OR REPLACE FUNCTION check_and_award_badges()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_streak integer;
  v_total_minutes integer;
  v_total_videos integer;
BEGIN
  -- Get user stats
  SELECT 
    current_streak,
    total_minutes,
    total_videos_watched
  INTO
    v_streak,
    v_total_minutes,
    v_total_videos
  FROM user_stats
  WHERE user_id = NEW.user_id;

  -- Check and award streak badges
  IF v_streak >= 100 THEN
    INSERT INTO user_badges (user_id, badge_type, tier, metadata)
    VALUES (NEW.user_id, 'streak_master', 'gold', jsonb_build_object('streak', v_streak))
    ON CONFLICT (user_id, badge_type) 
    DO UPDATE SET tier = 'gold', metadata = jsonb_build_object('streak', v_streak)
    WHERE user_badges.tier != 'gold';
  ELSIF v_streak >= 30 THEN
    INSERT INTO user_badges (user_id, badge_type, tier, metadata)
    VALUES (NEW.user_id, 'streak_master', 'silver', jsonb_build_object('streak', v_streak))
    ON CONFLICT (user_id, badge_type) 
    DO UPDATE SET tier = 'silver', metadata = jsonb_build_object('streak', v_streak)
    WHERE user_badges.tier = 'bronze';
  ELSIF v_streak >= 7 THEN
    INSERT INTO user_badges (user_id, badge_type, tier, metadata)
    VALUES (NEW.user_id, 'streak_master', 'bronze', jsonb_build_object('streak', v_streak))
    ON CONFLICT DO NOTHING;
  END IF;

  -- Check and award time badges
  IF v_total_minutes >= 1000 THEN
    INSERT INTO user_badges (user_id, badge_type, tier, metadata)
    VALUES (NEW.user_id, 'time_champion', 'gold', jsonb_build_object('minutes', v_total_minutes))
    ON CONFLICT (user_id, badge_type) 
    DO UPDATE SET tier = 'gold', metadata = jsonb_build_object('minutes', v_total_minutes)
    WHERE user_badges.tier != 'gold';
  ELSIF v_total_minutes >= 500 THEN
    INSERT INTO user_badges (user_id, badge_type, tier, metadata)
    VALUES (NEW.user_id, 'time_champion', 'silver', jsonb_build_object('minutes', v_total_minutes))
    ON CONFLICT (user_id, badge_type) 
    DO UPDATE SET tier = 'silver', metadata = jsonb_build_object('minutes', v_total_minutes)
    WHERE user_badges.tier = 'bronze';
  ELSIF v_total_minutes >= 100 THEN
    INSERT INTO user_badges (user_id, badge_type, tier, metadata)
    VALUES (NEW.user_id, 'time_champion', 'bronze', jsonb_build_object('minutes', v_total_minutes))
    ON CONFLICT DO NOTHING;
  END IF;

  -- Check and award video badges
  IF v_total_videos >= 100 THEN
    INSERT INTO user_badges (user_id, badge_type, tier, metadata)
    VALUES (NEW.user_id, 'video_expert', 'gold', jsonb_build_object('videos', v_total_videos))
    ON CONFLICT (user_id, badge_type) 
    DO UPDATE SET tier = 'gold', metadata = jsonb_build_object('videos', v_total_videos)
    WHERE user_badges.tier != 'gold';
  ELSIF v_total_videos >= 50 THEN
    INSERT INTO user_badges (user_id, badge_type, tier, metadata)
    VALUES (NEW.user_id, 'video_expert', 'silver', jsonb_build_object('videos', v_total_videos))
    ON CONFLICT (user_id, badge_type) 
    DO UPDATE SET tier = 'silver', metadata = jsonb_build_object('videos', v_total_videos)
    WHERE user_badges.tier = 'bronze';
  ELSIF v_total_videos >= 10 THEN
    INSERT INTO user_badges (user_id, badge_type, tier, metadata)
    VALUES (NEW.user_id, 'video_expert', 'bronze', jsonb_build_object('videos', v_total_videos))
    ON CONFLICT DO NOTHING;
  END IF;

  RETURN NEW;
END;
$$;

-- Create user_badges table
CREATE TABLE IF NOT EXISTS user_badges (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  badge_type text NOT NULL,
  tier text NOT NULL CHECK (tier IN ('bronze', 'silver', 'gold')),
  earned_at timestamptz DEFAULT now(),
  metadata jsonb DEFAULT '{}'::jsonb,
  UNIQUE(user_id, badge_type)
);

-- Create user_friends table
CREATE TABLE IF NOT EXISTS user_friends (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  friend_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  status text NOT NULL CHECK (status IN ('pending', 'accepted', 'declined')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id, friend_id)
);

-- Create user_reactions table
CREATE TABLE IF NOT EXISTS user_reactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  target_user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  reaction text NOT NULL CHECK (reaction IN ('fire', 'thumbsup', 'celebrate')),
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, target_user_id, reaction)
);

-- Create user_comments table
CREATE TABLE IF NOT EXISTS user_comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  target_user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  content text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE user_badges ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_friends ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_reactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_comments ENABLE ROW LEVEL SECURITY;

-- Create indexes
DO $$ 
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'user_badges_user_type_idx') THEN
    CREATE INDEX user_badges_user_type_idx ON user_badges(user_id, badge_type);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'user_friends_user_idx') THEN
    CREATE INDEX user_friends_user_idx ON user_friends(user_id);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'user_friends_friend_idx') THEN
    CREATE INDEX user_friends_friend_idx ON user_friends(friend_id);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'user_reactions_target_idx') THEN
    CREATE INDEX user_reactions_target_idx ON user_reactions(target_user_id);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'user_comments_target_idx') THEN
    CREATE INDEX user_comments_target_idx ON user_comments(target_user_id);
  END IF;
END $$;

-- Drop existing policies if they exist
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Anyone can read badges" ON user_badges;
  DROP POLICY IF EXISTS "Users can manage their own friend requests" ON user_friends;
  DROP POLICY IF EXISTS "Anyone can read reactions" ON user_reactions;
  DROP POLICY IF EXISTS "Users can manage their own reactions" ON user_reactions;
  DROP POLICY IF EXISTS "Anyone can read comments" ON user_comments;
  DROP POLICY IF EXISTS "Users can manage their own comments" ON user_comments;
END $$;

-- Create policies
CREATE POLICY "Anyone can read badges"
  ON user_badges
  FOR SELECT
  USING (true);

CREATE POLICY "Users can manage their own friend requests"
  ON user_friends
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id OR auth.uid() = friend_id);

CREATE POLICY "Anyone can read reactions"
  ON user_reactions
  FOR SELECT
  USING (true);

CREATE POLICY "Users can manage their own reactions"
  ON user_reactions
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Anyone can read comments"
  ON user_comments
  FOR SELECT
  USING (true);

CREATE POLICY "Users can manage their own comments"
  ON user_comments
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id);

-- Create function to check if users are friends
CREATE OR REPLACE FUNCTION are_users_friends(user_a uuid, user_b uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM user_friends
    WHERE status = 'accepted'
    AND ((user_id = user_a AND friend_id = user_b)
    OR (user_id = user_b AND friend_id = user_a))
  );
END;
$$;

-- Create trigger to check badges after stats update
CREATE TRIGGER check_badges_trigger
  AFTER INSERT OR UPDATE ON user_stats
  FOR EACH ROW
  EXECUTE FUNCTION check_and_award_badges();