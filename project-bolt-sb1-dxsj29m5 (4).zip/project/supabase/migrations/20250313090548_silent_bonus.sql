/*
  # Update Weekly Challenge System for Monday-Sunday Weeks

  1. Changes
    - Modify functions to use Monday as week start
    - Update challenge generation logic
    - Fix date calculations
  
  2. Security
    - Maintain existing RLS policies
    - Keep security checks in place
*/

-- Update function to generate weekly challenge with Monday start
CREATE OR REPLACE FUNCTION generate_weekly_challenge(p_start_date date)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_challenge_id uuid;
  v_target_hours integer;
  v_monday date;
BEGIN
  -- Ensure start date is a Monday
  v_monday := p_start_date - EXTRACT(DOW FROM p_start_date - 1)::integer;
  
  -- Generate random target between 10 and 25 hours
  v_target_hours := floor(random() * (25 - 10 + 1) + 10)::integer;
  
  INSERT INTO weekly_challenges (
    start_date,
    end_date,
    target_hours
  ) VALUES (
    v_monday,
    v_monday + interval '6 days',
    v_target_hours
  )
  RETURNING id INTO v_challenge_id;
  
  RETURN v_challenge_id;
END;
$$;

-- Update function to ensure weekly challenge exists with Monday start
CREATE OR REPLACE FUNCTION ensure_weekly_challenge()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_monday date;
  v_challenge_exists boolean;
BEGIN
  -- Get Monday of current week
  v_monday := CURRENT_DATE - EXTRACT(DOW FROM CURRENT_DATE - 1)::integer;
  
  -- Check if challenge exists for current week
  SELECT EXISTS (
    SELECT 1 FROM weekly_challenges
    WHERE start_date = v_monday
  ) INTO v_challenge_exists;
  
  -- Generate new challenge if none exists
  IF NOT v_challenge_exists THEN
    PERFORM generate_weekly_challenge(v_monday);
  END IF;
END;
$$;

-- Update function to check weekly challenge completion
CREATE OR REPLACE FUNCTION check_weekly_challenge_completion()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_challenge record;
  v_weekly_minutes integer;
  v_monday date;
BEGIN
  -- Get Monday of current week
  v_monday := CURRENT_DATE - EXTRACT(DOW FROM CURRENT_DATE - 1)::integer;

  -- Get current weekly challenge
  SELECT * INTO v_challenge
  FROM weekly_challenges
  WHERE start_date = v_monday
  LIMIT 1;

  IF v_challenge IS NULL THEN
    RETURN NEW;
  END IF;

  -- Get user's weekly minutes
  SELECT weekly_minutes INTO v_weekly_minutes
  FROM user_stats
  WHERE user_id = NEW.user_id;

  -- Check if challenge is completed
  IF v_weekly_minutes >= (v_challenge.target_hours * 60) THEN
    INSERT INTO weekly_challenge_completions (
      challenge_id,
      user_id
    )
    VALUES (
      v_challenge.id,
      NEW.user_id
    )
    ON CONFLICT DO NOTHING;
  END IF;

  RETURN NEW;
END;
$$;