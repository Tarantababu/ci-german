/*
  # Fix time entries security configuration

  1. Changes
    - Update RLS policies for time_entries table
    - Allow public read access to time entries
    - Maintain write protection for own entries only
  
  2. Security
    - Enable public read access
    - Maintain write security
    - Add proper indexes for performance
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Users can read own time entries" ON time_entries;
DROP POLICY IF EXISTS "Users can insert own time entries" ON time_entries;
DROP POLICY IF EXISTS "Users can update own time entries" ON time_entries;
DROP POLICY IF EXISTS "Users can delete own time entries" ON time_entries;

-- Create new policies
CREATE POLICY "Anyone can read time entries"
  ON time_entries
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can insert own time entries"
  ON time_entries
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own time entries"
  ON time_entries
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own time entries"
  ON time_entries
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create additional indexes for better performance
CREATE INDEX IF NOT EXISTS time_entries_user_date_created_idx 
  ON time_entries(user_id, date, created_at DESC);

CREATE INDEX IF NOT EXISTS time_entries_activity_type_idx 
  ON time_entries(activity_type);

-- Create function to get recent activity
CREATE OR REPLACE FUNCTION get_user_recent_activity(p_user_id uuid, p_limit integer DEFAULT 5)
RETURNS TABLE (
  id uuid,
  date date,
  minutes integer,
  activity_type text,
  description text,
  video_id uuid,
  created_at timestamptz
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    time_entries.id,
    time_entries.date,
    time_entries.minutes,
    time_entries.activity_type,
    time_entries.description,
    time_entries.video_id,
    time_entries.created_at
  FROM time_entries
  WHERE time_entries.user_id = p_user_id
  ORDER BY time_entries.created_at DESC
  LIMIT p_limit;
END;
$$;