/*
  # Fix Video Comments User Data

  1. Changes
    - Add user_data column to store user information
    - Create secure function to fetch user data
    - Add trigger to automatically update user data

  2. Security
    - Use security definer function
    - Restrict access to auth.users table
    - Maintain RLS policies
*/

-- Create function to get user data
CREATE OR REPLACE FUNCTION get_user_data(user_id uuid)
RETURNS jsonb
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT jsonb_build_object(
    'email', (SELECT email FROM auth.users WHERE id = user_id)
  );
$$;

-- Add user_data column
ALTER TABLE video_comments
  ADD COLUMN IF NOT EXISTS user_data jsonb;

-- Create function to update user data
CREATE OR REPLACE FUNCTION update_comment_user_data()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  NEW.user_data = get_user_data(NEW.user_id);
  RETURN NEW;
END;
$$;

-- Create trigger to automatically update user data
DROP TRIGGER IF EXISTS update_comment_user_data_trigger ON video_comments;
CREATE TRIGGER update_comment_user_data_trigger
  BEFORE INSERT OR UPDATE OF user_id
  ON video_comments
  FOR EACH ROW
  EXECUTE FUNCTION update_comment_user_data();

-- Update existing comments
UPDATE video_comments
SET user_data = get_user_data(user_id)
WHERE user_data IS NULL;