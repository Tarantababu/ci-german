/*
  # Video tracking system updates

  1. New Tables
    - `video_watch_sessions`
      - Tracks individual watch sessions with precise timing
      - Handles partial watches and interrupted playback
      - Maintains watch history

  2. Security
    - Enable RLS on new table
    - Add policies for CRUD operations
*/

-- Create video_watch_sessions table
CREATE TABLE IF NOT EXISTS video_watch_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  video_id uuid REFERENCES videos(id) ON DELETE CASCADE,
  user_id uuid REFERENCES auth.users(id) DEFAULT auth.uid(),
  started_at timestamptz NOT NULL DEFAULT now(),
  ended_at timestamptz,
  progress_seconds integer NOT NULL DEFAULT 0,
  is_complete boolean NOT NULL DEFAULT false,
  last_position_seconds integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Create indexes
CREATE INDEX IF NOT EXISTS video_watch_sessions_user_video_idx ON video_watch_sessions(user_id, video_id);
CREATE INDEX IF NOT EXISTS video_watch_sessions_date_idx ON video_watch_sessions(started_at);

-- Enable RLS
ALTER TABLE video_watch_sessions ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Users can read own watch sessions"
  ON video_watch_sessions
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own watch sessions"
  ON video_watch_sessions
  FOR INSERT
  TO authenticated
  WITH CHECK (true);  -- user_id is set by default

CREATE POLICY "Users can update own watch sessions"
  ON video_watch_sessions
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own watch sessions"
  ON video_watch_sessions
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);