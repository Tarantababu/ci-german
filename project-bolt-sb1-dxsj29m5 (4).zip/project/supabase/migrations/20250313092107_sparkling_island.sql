/*
  # Fix User Reactions RLS Policies

  1. Changes
    - Drop and recreate user_reactions policies
    - Add proper RLS policies for reactions
    - Fix insert/delete permissions
    
  2. Security
    - Enable proper access control
    - Maintain data integrity
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Anyone can read reactions" ON user_reactions;
DROP POLICY IF EXISTS "Users can manage their own reactions" ON user_reactions;

-- Create new policies with proper permissions
CREATE POLICY "Anyone can read reactions"
  ON user_reactions
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Users can insert reactions"
  ON user_reactions
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own reactions"
  ON user_reactions
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Ensure RLS is enabled
ALTER TABLE user_reactions ENABLE ROW LEVEL SECURITY;

-- Add function to get reaction counts
CREATE OR REPLACE FUNCTION get_user_reactions(p_user_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_reactions jsonb;
BEGIN
  SELECT jsonb_build_object(
    'fire', COUNT(*) FILTER (WHERE reaction = 'fire'),
    'thumbsup', COUNT(*) FILTER (WHERE reaction = 'thumbsup'),
    'celebrate', COUNT(*) FILTER (WHERE reaction = 'celebrate')
  )
  INTO v_reactions
  FROM user_reactions
  WHERE target_user_id = p_user_id;
  
  RETURN v_reactions;
END;
$$;