/*
  # Fix user_stats and user_profiles relationship

  1. Changes
    - Ensure all users have profiles
    - Add index for the join if it doesn't exist
  
  2. Security
    - Maintain existing RLS policies
*/

-- First ensure all users have profiles
DO $$ 
BEGIN
  INSERT INTO user_profiles (id)
  SELECT id FROM auth.users
  WHERE id NOT IN (SELECT id FROM user_profiles)
  ON CONFLICT DO NOTHING;
END $$;

-- Create index for the join if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE indexname = 'user_stats_user_profile_idx'
  ) THEN
    CREATE INDEX user_stats_user_profile_idx ON user_stats(user_id);
  END IF;
END $$;