/*
  # Add update policy for watched_videos table

  1. Changes
    - Add RLS policy to allow authenticated users to update their own watched videos entries
  
  2. Security
    - Only allows users to update their own records
    - Maintains existing security model
*/

-- Add update policy for watched_videos table
CREATE POLICY "Users can update own watched status"
  ON watched_videos
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);