-- Drop existing video_comments table and recreate with proper relationships
DROP TABLE IF EXISTS video_comments CASCADE;

CREATE TABLE video_comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  video_id uuid REFERENCES videos(id) ON DELETE CASCADE,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE DEFAULT auth.uid(),
  content text NOT NULL,
  likes integer DEFAULT 0,
  dislikes integer DEFAULT 0,
  parent_id uuid REFERENCES video_comments(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now()
);

-- Create indexes for better performance
CREATE INDEX video_comments_video_id_idx ON video_comments(video_id);
CREATE INDEX video_comments_user_id_idx ON video_comments(user_id);
CREATE INDEX video_comments_parent_id_idx ON video_comments(parent_id);

-- Enable RLS
ALTER TABLE video_comments ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Anyone can read comments"
  ON video_comments
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can insert own comments"
  ON video_comments
  FOR INSERT
  TO authenticated
  WITH CHECK (true);  -- user_id is set by default

CREATE POLICY "Users can update own comments"
  ON video_comments
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own comments"
  ON video_comments
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create function to handle comment user data
CREATE OR REPLACE FUNCTION get_comment_user(comment_row video_comments)
RETURNS jsonb
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT jsonb_build_object(
    'id', u.id,
    'email', u.email
  )
  FROM auth.users u
  WHERE u.id = comment_row.user_id;
$$;