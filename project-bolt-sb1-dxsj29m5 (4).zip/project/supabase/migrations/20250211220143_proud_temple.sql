/*
  # Video tracking system improvements
  
  1. Changes
    - Add audit logging table
    - Add constraints and validations
    - Add functions for time calculations
    - Add session management improvements
    
  2. Security
    - Maintain existing RLS policies
    - Add validation checks
*/

-- Create audit logging table
CREATE TABLE IF NOT EXISTS video_watch_audit_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) DEFAULT auth.uid(),
  video_id uuid REFERENCES videos(id),
  action text NOT NULL,
  details jsonb,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS on audit logs
ALTER TABLE video_watch_audit_logs ENABLE ROW LEVEL SECURITY;

-- Only allow inserts and selects on audit logs
CREATE POLICY "Users can read own audit logs"
  ON video_watch_audit_logs
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create audit logs"
  ON video_watch_audit_logs
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Add constraints to video_watch_sessions
ALTER TABLE video_watch_sessions
  ADD CONSTRAINT valid_progress_check 
  CHECK (progress_seconds >= 0 AND last_position_seconds >= 0),
  ADD CONSTRAINT valid_timestamps_check
  CHECK (ended_at IS NULL OR ended_at > started_at);

-- Add constraints to video_time_entries
ALTER TABLE video_time_entries
  ADD CONSTRAINT valid_duration_check
  CHECK (duration_seconds >= 0),
  ADD CONSTRAINT valid_times_check
  CHECK (end_time >= start_time);

-- Create function to log watch events
CREATE OR REPLACE FUNCTION log_watch_event(
  p_video_id uuid,
  p_action text,
  p_details jsonb DEFAULT '{}'::jsonb
) RETURNS void AS $$
BEGIN
  INSERT INTO video_watch_audit_logs (video_id, action, details)
  VALUES (p_video_id, p_action, p_details);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create function to calculate watch time
CREATE OR REPLACE FUNCTION calculate_watch_time(
  p_user_id uuid,
  p_date date
) RETURNS integer AS $$
DECLARE
  total_seconds integer;
BEGIN
  SELECT COALESCE(SUM(duration_seconds), 0)
  INTO total_seconds
  FROM video_time_entries
  WHERE user_id = p_user_id
    AND date = p_date;
  
  RETURN total_seconds;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create function to handle watch session updates
CREATE OR REPLACE FUNCTION update_watch_session() RETURNS trigger AS $$
BEGIN
  -- Log the update
  PERFORM log_watch_event(
    NEW.video_id,
    CASE
      WHEN NEW.is_complete AND OLD.is_complete = false THEN 'session_completed'
      WHEN NEW.progress_seconds > OLD.progress_seconds THEN 'progress_updated'
      ELSE 'session_updated'
    END,
    jsonb_build_object(
      'old_progress', OLD.progress_seconds,
      'new_progress', NEW.progress_seconds,
      'old_position', OLD.last_position_seconds,
      'new_position', NEW.last_position_seconds
    )
  );
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for watch session updates
CREATE TRIGGER watch_session_audit
  AFTER UPDATE ON video_watch_sessions
  FOR EACH ROW
  EXECUTE FUNCTION update_watch_session();