/*
  # Fix comment permissions and policies

  1. Changes
    - Drop and recreate comment permissions table with simplified structure
    - Update policies to prevent infinite recursion
    - Add proper indexes for performance

  2. Security
    - Enable RLS
    - Add policies for proper access control
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Anyone can read comments" ON video_comments;
DROP POLICY IF EXISTS "Users can read active comments" ON video_comments;

-- Recreate comment permissions table
DROP TABLE IF EXISTS comment_permissions CASCADE;
CREATE TABLE comment_permissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  video_id uuid REFERENCES videos(id) ON DELETE CASCADE,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  role text NOT NULL CHECK (role IN ('moderator', 'admin')),
  created_at timestamptz DEFAULT now(),
  UNIQUE(video_id, user_id)
);

-- Enable RLS on comment permissions
ALTER TABLE comment_permissions ENABLE ROW LEVEL SECURITY;

-- Create indexes
CREATE INDEX comment_permissions_video_user_idx ON comment_permissions(video_id, user_id);
CREATE INDEX comment_permissions_role_idx ON comment_permissions(role);

-- Create simplified comment policies
CREATE POLICY "Anyone can read active comments"
  ON video_comments
  FOR SELECT
  TO authenticated
  USING (status = 'active');

CREATE POLICY "Moderators can read all comments"
  ON video_comments
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 
      FROM comment_permissions 
      WHERE video_id = video_comments.video_id 
      AND user_id = auth.uid()
      AND role IN ('moderator', 'admin')
    )
  );

-- Create permission policies
CREATE POLICY "Users can view own permissions"
  ON comment_permissions
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Admins can manage permissions"
  ON comment_permissions
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 
      FROM comment_permissions 
      WHERE user_id = auth.uid()
      AND role = 'admin'
      AND video_id = comment_permissions.video_id
    )
  );

-- Function to check user permission level
CREATE OR REPLACE FUNCTION get_user_permission_level(p_video_id uuid)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_role text;
BEGIN
  SELECT role INTO v_role
  FROM comment_permissions
  WHERE video_id = p_video_id
    AND user_id = auth.uid()
  LIMIT 1;
    
  RETURN COALESCE(v_role, 'viewer');
END;
$$;

-- Function to moderate comment
CREATE OR REPLACE FUNCTION moderate_comment(
  p_comment_id uuid,
  p_action text
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_video_id uuid;
  v_role text;
BEGIN
  -- Get video_id for the comment
  SELECT video_id INTO v_video_id
  FROM video_comments
  WHERE id = p_comment_id;
  
  -- Get user's role
  SELECT role INTO v_role
  FROM comment_permissions
  WHERE video_id = v_video_id
    AND user_id = auth.uid()
  LIMIT 1;
  
  IF v_role NOT IN ('moderator', 'admin') THEN
    RETURN false;
  END IF;
  
  -- Perform moderation action
  UPDATE video_comments
  SET status = 
    CASE p_action
      WHEN 'hide' THEN 'hidden'
      WHEN 'delete' THEN 'deleted'
      WHEN 'restore' THEN 'active'
    END
  WHERE id = p_comment_id;
  
  RETURN true;
END;
$$;