-- Create function to get daily leaderboard
CREATE OR REPLACE FUNCTION get_daily_leaderboard(
  p_date date,
  p_user_ids uuid[] DEFAULT NULL
)
RETURNS TABLE (
  user_id uuid,
  current_streak integer,
  longest_streak integer,
  total_minutes integer,
  weekly_minutes integer,
  monthly_minutes integer,
  total_videos_watched integer,
  level integer,
  daily_minutes bigint,
  user_profiles jsonb
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  WITH daily_minutes AS (
    SELECT 
      t.user_id,
      SUM(t.minutes) as minutes
    FROM time_entries t
    WHERE t.date = p_date
    AND (p_user_ids IS NULL OR t.user_id = ANY(p_user_ids))
    GROUP BY t.user_id
  )
  SELECT 
    s.user_id,
    s.current_streak,
    s.longest_streak,
    s.total_minutes,
    s.weekly_minutes,
    s.monthly_minutes,
    s.total_videos_watched,
    s.level,
    COALESCE(d.minutes, 0)::bigint as daily_minutes,
    jsonb_build_object(
      'display_name', p.display_name,
      'avatar_url', p.avatar_url,
      'username', p.username
    ) as user_profiles
  FROM daily_minutes d
  JOIN user_stats s ON s.user_id = d.user_id
  JOIN user_profiles p ON p.id = d.user_id
  ORDER BY d.minutes DESC;
END;
$$;