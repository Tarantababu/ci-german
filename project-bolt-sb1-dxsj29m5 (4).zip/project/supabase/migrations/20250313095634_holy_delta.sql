-- Create function to get community statistics
CREATE OR REPLACE FUNCTION get_community_stats()
RETURNS TABLE (
  total_users bigint,
  active_today bigint,
  average_streak numeric
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  SELECT
    (SELECT COUNT(*) FROM user_stats) as total_users,
    (
      SELECT COUNT(DISTINCT user_id)
      FROM time_entries
      WHERE date = CURRENT_DATE
    ) as active_today,
    COALESCE(
      (SELECT ROUND(AVG(current_streak)::numeric, 1)
      FROM user_stats
      WHERE current_streak > 0),
      0
    ) as average_streak;
END;
$$;

-- Create index for performance
CREATE INDEX IF NOT EXISTS time_entries_date_idx ON time_entries(date);