/*
  # Add Username Support
  
  1. Changes
    - Add username column to user_profiles table
    - Add unique constraint and validation for usernames
    - Add function to validate username format
  
  2. Security
    - Enable RLS policies for username updates
    - Add validation trigger
*/

-- Add username column with constraints
ALTER TABLE user_profiles
  ADD COLUMN IF NOT EXISTS username text UNIQUE,
  ADD CONSTRAINT username_length CHECK (char_length(username) BETWEEN 3 AND 20),
  ADD CONSTRAINT username_format CHECK (username ~ '^[a-zA-Z0-9_]+$');

-- Create function to validate username
CREATE OR REPLACE FUNCTION validate_username()
RETURNS trigger AS $$
BEGIN
  -- Check if username is already taken (case insensitive)
  IF EXISTS (
    SELECT 1 FROM user_profiles
    WHERE lower(username) = lower(NEW.username)
    AND id != NEW.id
  ) THEN
    RAISE EXCEPTION 'Username already taken';
  END IF;

  -- Convert to lowercase
  NEW.username := lower(NEW.username);
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for username validation
DROP TRIGGER IF EXISTS validate_username_trigger ON user_profiles;
CREATE TRIGGER validate_username_trigger
  BEFORE INSERT OR UPDATE OF username ON user_profiles
  FOR EACH ROW
  EXECUTE FUNCTION validate_username();