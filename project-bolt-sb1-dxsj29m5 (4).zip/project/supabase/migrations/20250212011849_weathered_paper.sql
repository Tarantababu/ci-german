/*
  # Fix user_stats and user_profiles relationship

  1. Changes
    - Drop existing foreign key if it exists
    - Add proper foreign key relationship between user_stats and user_profiles
    - Create index for better join performance
  
  2. Security
    - Maintain existing RLS policies
*/

-- Drop existing foreign key if it exists
DO $$ 
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'user_stats_user_id_fkey'
  ) THEN
    ALTER TABLE user_stats DROP CONSTRAINT user_stats_user_id_fkey;
  END IF;
END $$;

-- Add foreign key relationship
ALTER TABLE user_stats
  ADD CONSTRAINT user_stats_user_id_fkey 
  FOREIGN KEY (user_id) 
  REFERENCES user_profiles(id)
  ON DELETE CASCADE;

-- Create index for better join performance
CREATE INDEX IF NOT EXISTS user_stats_user_profile_idx ON user_stats(user_id);