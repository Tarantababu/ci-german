/*
  # Secure History Implementation

  1. Changes
    - Add audit columns to time_entries table
    - Create audit log table for tracking changes
    - Add RLS policies for secure access
    - Create audit logging functions and triggers

  2. Security
    - Enable RLS
    - Add proper access control
    - Implement audit logging
*/

-- Add audit columns to time_entries if they don't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'time_entries' AND column_name = 'created_by'
  ) THEN
    ALTER TABLE time_entries 
      ADD COLUMN created_by uuid REFERENCES auth.users(id) DEFAULT auth.uid(),
      ADD COLUMN updated_by uuid REFERENCES auth.users(id),
      ADD COLUMN updated_at timestamptz;
  END IF;
END $$;

-- Create audit log table
CREATE TABLE IF NOT EXISTS time_entries_audit_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  entry_id uuid REFERENCES time_entries(id) ON DELETE CASCADE,
  user_id uuid REFERENCES auth.users(id),
  action text NOT NULL CHECK (action IN ('create', 'update', 'delete')),
  old_data jsonb,
  new_data jsonb,
  ip_address text,
  user_agent text,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS on audit log
ALTER TABLE time_entries_audit_log ENABLE ROW LEVEL SECURITY;

-- Create audit log policies
CREATE POLICY "Users can read own audit logs"
  ON time_entries_audit_log
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

-- Create function to record audit log
CREATE OR REPLACE FUNCTION log_time_entry_change()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_old_data jsonb := NULL;
  v_new_data jsonb := NULL;
  v_action text;
BEGIN
  -- Determine action and prepare data
  IF (TG_OP = 'DELETE') THEN
    v_action := 'delete';
    v_old_data := row_to_json(OLD)::jsonb;
  ELSIF (TG_OP = 'UPDATE') THEN
    v_action := 'update';
    v_old_data := row_to_json(OLD)::jsonb;
    v_new_data := row_to_json(NEW)::jsonb;
  ELSE
    v_action := 'create';
    v_new_data := row_to_json(NEW)::jsonb;
  END IF;

  -- Insert audit log
  INSERT INTO time_entries_audit_log (
    entry_id,
    user_id,
    action,
    old_data,
    new_data,
    ip_address,
    user_agent
  ) VALUES (
    COALESCE(OLD.id, NEW.id),
    auth.uid(),
    v_action,
    v_old_data,
    v_new_data,
    current_setting('request.headers', true)::json->>'x-forwarded-for',
    current_setting('request.headers', true)::json->>'user-agent'
  );

  -- For updates, set updated_by and updated_at
  IF (TG_OP = 'UPDATE') THEN
    NEW.updated_by := auth.uid();
    NEW.updated_at := now();
  END IF;

  RETURN COALESCE(NEW, OLD);
END;
$$;

-- Create triggers for audit logging
DROP TRIGGER IF EXISTS time_entries_audit_trigger ON time_entries;
CREATE TRIGGER time_entries_audit_trigger
  AFTER INSERT OR UPDATE OR DELETE ON time_entries
  FOR EACH ROW
  EXECUTE FUNCTION log_time_entry_change();

-- Update RLS policies for time_entries
DROP POLICY IF EXISTS "Anyone can read time entries" ON time_entries;
DROP POLICY IF EXISTS "Users can insert own time entries" ON time_entries;
DROP POLICY IF EXISTS "Users can update own time entries" ON time_entries;
DROP POLICY IF EXISTS "Users can delete own time entries" ON time_entries;

-- Create strict RLS policies
CREATE POLICY "Users can read own time entries"
  ON time_entries
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can insert own time entries"
  ON time_entries
  FOR INSERT
  TO authenticated
  WITH CHECK (
    auth.uid() = user_id AND
    created_by = auth.uid()
  );

CREATE POLICY "Users can update own time entries"
  ON time_entries
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own time entries"
  ON time_entries
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create function to get user history with audit info
CREATE OR REPLACE FUNCTION get_user_history(
  p_user_id uuid,
  p_limit integer DEFAULT 50,
  p_offset integer DEFAULT 0
)
RETURNS TABLE (
  id uuid,
  date date,
  minutes integer,
  activity_type text,
  description text,
  video_id uuid,
  created_at timestamptz,
  created_by uuid,
  updated_at timestamptz,
  updated_by uuid,
  last_modified_by_email text,
  has_audit_logs boolean
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    t.id,
    t.date,
    t.minutes,
    t.activity_type,
    t.description,
    t.video_id,
    t.created_at,
    t.created_by,
    t.updated_at,
    t.updated_by,
    (SELECT email FROM auth.users WHERE id = COALESCE(t.updated_by, t.created_by)),
    EXISTS (
      SELECT 1 FROM time_entries_audit_log 
      WHERE entry_id = t.id
    ) as has_audit_logs
  FROM time_entries t
  WHERE t.user_id = p_user_id
  ORDER BY t.date DESC, t.created_at DESC
  LIMIT p_limit
  OFFSET p_offset;
END;
$$;