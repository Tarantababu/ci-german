/*
  # Secure Comment Management System

  1. New Tables
    - comment_permissions
      - permission_id (uuid, primary key)
      - video_id (uuid, references videos)
      - user_id (uuid, references auth.users)
      - access_level (text)
      - created_at (timestamptz)

  2. Changes
    - Add status field to video_comments
    - Add validation for access levels
    - Add rate limiting function

  3. Security
    - Enable RLS on all tables
    - Add policies for permission-based access
    - Add input validation
*/

-- Add status field to video_comments
ALTER TABLE video_comments 
  ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'active' 
  CHECK (status IN ('active', 'hidden', 'deleted'));

-- Create comment_permissions table
CREATE TABLE IF NOT EXISTS comment_permissions (
  permission_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  video_id uuid REFERENCES videos(id) ON DELETE CASCADE,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  access_level text NOT NULL CHECK (access_level IN ('viewer', 'moderator', 'admin')),
  created_at timestamptz DEFAULT now(),
  UNIQUE(video_id, user_id)
);

-- Enable RLS
ALTER TABLE comment_permissions ENABLE ROW LEVEL SECURITY;

-- Create indexes
CREATE INDEX IF NOT EXISTS comment_permissions_video_user_idx 
  ON comment_permissions(video_id, user_id);

-- Create rate limiting function
CREATE OR REPLACE FUNCTION check_comment_rate_limit(p_user_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  recent_comments integer;
BEGIN
  SELECT COUNT(*)
  INTO recent_comments
  FROM video_comments
  WHERE user_id = p_user_id
    AND created_at > NOW() - INTERVAL '1 minute';
    
  RETURN recent_comments < 5; -- Max 5 comments per minute
END;
$$;

-- Create comment validation function
CREATE OR REPLACE FUNCTION validate_comment()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Check content length
  IF LENGTH(NEW.content) < 2 OR LENGTH(NEW.content) > 1000 THEN
    RAISE EXCEPTION 'Comment must be between 2 and 1000 characters';
  END IF;

  -- Basic content sanitization (remove null bytes and control characters)
  NEW.content = regexp_replace(NEW.content, '[\x00-\x1F\x7F]', '', 'g');
  
  -- Check rate limit
  IF NOT check_comment_rate_limit(auth.uid()) THEN
    RAISE EXCEPTION 'Rate limit exceeded. Please wait before posting again.';
  END IF;

  RETURN NEW;
END;
$$;

-- Create trigger for comment validation
DROP TRIGGER IF EXISTS validate_comment_trigger ON video_comments;
CREATE TRIGGER validate_comment_trigger
  BEFORE INSERT OR UPDATE ON video_comments
  FOR EACH ROW
  EXECUTE FUNCTION validate_comment();

-- Update comment policies
DROP POLICY IF EXISTS "Anyone can read comments" ON video_comments;
CREATE POLICY "Users can read active comments"
  ON video_comments
  FOR SELECT
  TO authenticated
  USING (
    status = 'active' OR 
    auth.uid() IN (
      SELECT user_id 
      FROM comment_permissions 
      WHERE video_id = video_comments.video_id 
      AND access_level IN ('moderator', 'admin')
    )
  );

-- Policies for comment_permissions
CREATE POLICY "Users can view own permissions"
  ON comment_permissions
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Admins can manage permissions"
  ON comment_permissions
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 
      FROM comment_permissions 
      WHERE user_id = auth.uid() 
      AND video_id = comment_permissions.video_id
      AND access_level = 'admin'
    )
  );

-- Function to check user permission level
CREATE OR REPLACE FUNCTION get_user_permission_level(p_user_id uuid, p_video_id uuid)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_access_level text;
BEGIN
  SELECT access_level INTO v_access_level
  FROM comment_permissions
  WHERE user_id = p_user_id
    AND video_id = p_video_id;
    
  RETURN COALESCE(v_access_level, 'viewer');
END;
$$;

-- Function to moderate comment
CREATE OR REPLACE FUNCTION moderate_comment(
  p_comment_id uuid,
  p_action text,
  p_user_id uuid
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_video_id uuid;
  v_permission text;
BEGIN
  -- Get video_id for the comment
  SELECT video_id INTO v_video_id
  FROM video_comments
  WHERE id = p_comment_id;
  
  -- Check permission level
  v_permission := get_user_permission_level(p_user_id, v_video_id);
  
  IF v_permission NOT IN ('moderator', 'admin') THEN
    RETURN false;
  END IF;
  
  -- Perform moderation action
  UPDATE video_comments
  SET status = 
    CASE p_action
      WHEN 'hide' THEN 'hidden'
      WHEN 'delete' THEN 'deleted'
      WHEN 'restore' THEN 'active'
    END
  WHERE id = p_comment_id;
  
  RETURN true;
END;
$$;