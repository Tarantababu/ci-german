/*
  # Add user profile and stats tables

  1. Changes
    - Add user_profiles table
    - Add user_stats table
    - Add proper indexes and constraints
    - Add triggers for stats updates
  
  2. Security
    - Enable RLS
    - Add proper access control
*/

-- Create user_profiles table if it doesn't exist
CREATE TABLE IF NOT EXISTS user_profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username text UNIQUE,
  display_name text,
  avatar_url text,
  bio text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT username_length CHECK (char_length(username) BETWEEN 3 AND 20),
  CONSTRAINT username_format CHECK (username ~ '^[a-zA-Z0-9_]+$')
);

-- Create user_stats table
CREATE TABLE IF NOT EXISTS user_stats (
  user_id uuid PRIMARY KEY REFERENCES user_profiles(id) ON DELETE CASCADE,
  current_streak integer DEFAULT 0,
  longest_streak integer DEFAULT 0,
  total_minutes integer DEFAULT 0,
  weekly_minutes integer DEFAULT 0,
  monthly_minutes integer DEFAULT 0,
  total_videos_watched integer DEFAULT 0,
  level integer DEFAULT 1,
  last_activity_at timestamptz,
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_stats ENABLE ROW LEVEL SECURITY;

-- Create indexes (with IF NOT EXISTS)
DO $$ 
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'user_stats_current_streak_idx') THEN
    CREATE INDEX user_stats_current_streak_idx ON user_stats(current_streak DESC);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'user_stats_weekly_minutes_idx') THEN
    CREATE INDEX user_stats_weekly_minutes_idx ON user_stats(weekly_minutes DESC);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'user_stats_monthly_minutes_idx') THEN
    CREATE INDEX user_stats_monthly_minutes_idx ON user_stats(monthly_minutes DESC);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'user_stats_user_profile_idx') THEN
    CREATE INDEX user_stats_user_profile_idx ON user_stats(user_id);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'user_profiles_username_lower_idx') THEN
    CREATE INDEX user_profiles_username_lower_idx ON user_profiles(lower(username));
  END IF;
END $$;

-- Drop existing policies if they exist
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Public profiles are viewable by everyone" ON user_profiles;
  DROP POLICY IF EXISTS "Users can update own profile" ON user_profiles;
  DROP POLICY IF EXISTS "Stats are viewable by everyone" ON user_stats;
END $$;

-- Create policies
CREATE POLICY "Public profiles are viewable by everyone"
  ON user_profiles
  FOR SELECT
  USING (true);

CREATE POLICY "Users can update own profile"
  ON user_profiles
  FOR UPDATE
  USING (auth.uid() = id);

CREATE POLICY "Stats are viewable by everyone"
  ON user_stats
  FOR SELECT
  USING (true);

-- Create function to update user stats
CREATE OR REPLACE FUNCTION update_user_stats()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Calculate current streak
  WITH streak_calc AS (
    SELECT 
      COUNT(DISTINCT date)::integer as streak_count
    FROM time_entries
    WHERE user_id = NEW.user_id
      AND date > CURRENT_DATE - INTERVAL '30 days'
      AND date <= CURRENT_DATE
    GROUP BY user_id
  )
  -- Update user stats
  INSERT INTO user_stats (
    user_id,
    current_streak,
    total_minutes,
    weekly_minutes,
    monthly_minutes,
    total_videos_watched,
    last_activity_at,
    updated_at
  )
  SELECT
    NEW.user_id,
    COALESCE((SELECT streak_count FROM streak_calc), 0),
    COALESCE((
      SELECT SUM(minutes)::integer
      FROM time_entries
      WHERE user_id = NEW.user_id
    ), 0),
    COALESCE((
      SELECT SUM(minutes)::integer
      FROM time_entries
      WHERE user_id = NEW.user_id
        AND date > CURRENT_DATE - INTERVAL '7 days'
    ), 0),
    COALESCE((
      SELECT SUM(minutes)::integer
      FROM time_entries
      WHERE user_id = NEW.user_id
        AND date > CURRENT_DATE - INTERVAL '30 days'
    ), 0),
    COALESCE((
      SELECT COUNT(DISTINCT video_id)::integer
      FROM time_entries
      WHERE user_id = NEW.user_id
        AND video_id IS NOT NULL
    ), 0),
    NOW(),
    NOW()
  ON CONFLICT (user_id) DO UPDATE
  SET
    current_streak = EXCLUDED.current_streak,
    longest_streak = GREATEST(user_stats.longest_streak, EXCLUDED.current_streak),
    total_minutes = EXCLUDED.total_minutes,
    weekly_minutes = EXCLUDED.weekly_minutes,
    monthly_minutes = EXCLUDED.monthly_minutes,
    total_videos_watched = EXCLUDED.total_videos_watched,
    last_activity_at = EXCLUDED.last_activity_at,
    updated_at = EXCLUDED.updated_at;

  RETURN NEW;
END;
$$;

-- Create trigger for stats update
DROP TRIGGER IF EXISTS update_user_stats_trigger ON time_entries;
CREATE TRIGGER update_user_stats_trigger
  AFTER INSERT OR UPDATE ON time_entries
  FOR EACH ROW
  EXECUTE FUNCTION update_user_stats();