/*
  # User Registration Flow

  1. New Tables
    - None (using existing tables)
  
  2. Changes
    - Add trigger for automatic user profile creation
    - Add trigger for initializing user stats
    - Add trigger for logging first user activity
  
  3. Security
    - Maintain existing RLS policies
    - Add function-level security
*/

-- Create function to initialize user profile
CREATE OR REPLACE FUNCTION handle_new_user_registration()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Create user profile
  INSERT INTO user_profiles (id)
  VALUES (NEW.id)
  ON CONFLICT (id) DO NOTHING;

  -- Initialize user stats
  INSERT INTO user_stats (
    user_id,
    current_streak,
    longest_streak,
    total_minutes,
    weekly_minutes,
    monthly_minutes,
    total_videos_watched,
    level,
    last_activity_at,
    updated_at
  )
  VALUES (
    NEW.id,
    0,
    0,
    0,
    0,
    0,
    0,
    1,
    NOW(),
    NOW()
  )
  ON CONFLICT (user_id) DO NOTHING;

  -- Log first activity
  INSERT INTO user_achievements (
    user_id,
    achievement_type,
    achievement_data,
    unlocked_at
  )
  VALUES (
    NEW.id,
    'account_created',
    jsonb_build_object(
      'email', NEW.email,
      'created_at', NOW()
    ),
    NOW()
  )
  ON CONFLICT (user_id, achievement_type) DO NOTHING;

  RETURN NEW;
END;
$$;

-- Create trigger for new user registration
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION handle_new_user_registration();

-- Create function to validate user data
CREATE OR REPLACE FUNCTION validate_user_data()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Verify all required tables have entries
  IF NOT EXISTS (SELECT 1 FROM user_profiles WHERE id = NEW.id) OR
     NOT EXISTS (SELECT 1 FROM user_stats WHERE user_id = NEW.id) THEN
    
    -- Attempt to create missing entries
    INSERT INTO user_profiles (id)
    VALUES (NEW.id)
    ON CONFLICT (id) DO NOTHING;

    INSERT INTO user_stats (user_id)
    VALUES (NEW.id)
    ON CONFLICT (user_id) DO NOTHING;
    
    -- Verify again
    IF NOT EXISTS (SELECT 1 FROM user_profiles WHERE id = NEW.id) OR
       NOT EXISTS (SELECT 1 FROM user_stats WHERE user_id = NEW.id) THEN
      RAISE EXCEPTION 'Failed to create required user data';
    END IF;
  END IF;

  RETURN NEW;
END;
$$;

-- Create trigger to validate user data
DROP TRIGGER IF EXISTS validate_user_data_trigger ON auth.users;
CREATE TRIGGER validate_user_data_trigger
  AFTER INSERT OR UPDATE ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION validate_user_data();