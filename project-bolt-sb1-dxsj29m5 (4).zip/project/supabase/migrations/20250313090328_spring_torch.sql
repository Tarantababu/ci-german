/*
  # Add Weekly Challenge System

  1. New Tables
    - `weekly_challenges`
      - Stores weekly challenge target hours
      - Tracks start and end dates
      - Records completion status for users

  2. Security
    - Enable RLS
    - Add policies for read/write access
*/

-- Create weekly_challenges table
CREATE TABLE IF NOT EXISTS weekly_challenges (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  start_date date NOT NULL,
  end_date date NOT NULL,
  target_hours integer NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create weekly_challenge_completions table
CREATE TABLE IF NOT EXISTS weekly_challenge_completions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  challenge_id uuid REFERENCES weekly_challenges(id) ON DELETE CASCADE,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  completed_at timestamptz DEFAULT now(),
  UNIQUE(challenge_id, user_id)
);

-- Enable RLS
ALTER TABLE weekly_challenges ENABLE ROW LEVEL SECURITY;
ALTER TABLE weekly_challenge_completions ENABLE ROW LEVEL SECURITY;

-- Create indexes
CREATE INDEX weekly_challenges_date_idx ON weekly_challenges(start_date, end_date);
CREATE INDEX weekly_challenge_completions_user_idx ON weekly_challenge_completions(user_id);

-- Create policies
CREATE POLICY "Anyone can read weekly challenges"
  ON weekly_challenges
  FOR SELECT
  USING (true);

CREATE POLICY "Anyone can read challenge completions"
  ON weekly_challenge_completions
  FOR SELECT
  USING (true);

CREATE POLICY "Users can mark own completions"
  ON weekly_challenge_completions
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Function to generate new weekly challenge
CREATE OR REPLACE FUNCTION generate_weekly_challenge(p_start_date date)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_challenge_id uuid;
  v_target_hours integer;
BEGIN
  -- Generate random target between 10 and 25 hours
  v_target_hours := floor(random() * (25 - 10 + 1) + 10)::integer;
  
  INSERT INTO weekly_challenges (
    start_date,
    end_date,
    target_hours
  ) VALUES (
    p_start_date,
    p_start_date + interval '6 days',
    v_target_hours
  )
  RETURNING id INTO v_challenge_id;
  
  RETURN v_challenge_id;
END;
$$;

-- Function to check and update challenge completion
CREATE OR REPLACE FUNCTION check_weekly_challenge_completion()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_challenge record;
  v_weekly_minutes integer;
BEGIN
  -- Get current weekly challenge
  SELECT * INTO v_challenge
  FROM weekly_challenges
  WHERE start_date <= CURRENT_DATE
    AND end_date >= CURRENT_DATE
  ORDER BY start_date DESC
  LIMIT 1;

  IF v_challenge IS NULL THEN
    RETURN NEW;
  END IF;

  -- Get user's weekly minutes
  SELECT weekly_minutes INTO v_weekly_minutes
  FROM user_stats
  WHERE user_id = NEW.user_id;

  -- Check if challenge is completed
  IF v_weekly_minutes >= (v_challenge.target_hours * 60) THEN
    INSERT INTO weekly_challenge_completions (
      challenge_id,
      user_id
    )
    VALUES (
      v_challenge.id,
      NEW.user_id
    )
    ON CONFLICT DO NOTHING;
  END IF;

  RETURN NEW;
END;
$$;

-- Create trigger for challenge completion check
CREATE TRIGGER check_weekly_challenge_completion_trigger
  AFTER UPDATE OF weekly_minutes ON user_stats
  FOR EACH ROW
  EXECUTE FUNCTION check_weekly_challenge_completion();

-- Function to ensure weekly challenge exists
CREATE OR REPLACE FUNCTION ensure_weekly_challenge()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_start_date date;
  v_challenge_exists boolean;
BEGIN
  -- Get start of current week
  v_start_date := date_trunc('week', CURRENT_DATE)::date;
  
  -- Check if challenge exists for current week
  SELECT EXISTS (
    SELECT 1 FROM weekly_challenges
    WHERE start_date = v_start_date
  ) INTO v_challenge_exists;
  
  -- Generate new challenge if none exists
  IF NOT v_challenge_exists THEN
    PERFORM generate_weekly_challenge(v_start_date);
  END IF;
END;
$$;