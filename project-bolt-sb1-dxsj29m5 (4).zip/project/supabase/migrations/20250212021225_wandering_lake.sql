/*
  # Update user stats on time entry deletion

  1. Changes
    - Add trigger function to recalculate user stats after time entry deletion
    - Add trigger to time_entries table
    - Ensure stats are updated for:
      - Total minutes
      - Weekly minutes
      - Monthly minutes
      - Current streak
      - Total videos watched
*/

-- Create function to update user stats after deletion
CREATE OR REPLACE FUNCTION update_user_stats_after_delete()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_streak integer;
  v_total_minutes integer;
  v_weekly_minutes integer;
  v_monthly_minutes integer;
  v_total_videos integer;
BEGIN
  -- Calculate current streak
  SELECT 
    COUNT(DISTINCT date)::integer INTO v_streak
  FROM time_entries
  WHERE user_id = OLD.user_id
    AND date > CURRENT_DATE - INTERVAL '30 days'
    AND date <= CURRENT_DATE
  GROUP BY user_id;

  -- Calculate total minutes
  SELECT 
    COALESCE(SUM(minutes), 0)::integer INTO v_total_minutes
  FROM time_entries
  WHERE user_id = OLD.user_id;

  -- Calculate weekly minutes
  SELECT 
    COALESCE(SUM(minutes), 0)::integer INTO v_weekly_minutes
  FROM time_entries
  WHERE user_id = OLD.user_id
    AND date > CURRENT_DATE - INTERVAL '7 days';

  -- Calculate monthly minutes
  SELECT 
    COALESCE(SUM(minutes), 0)::integer INTO v_monthly_minutes
  FROM time_entries
  WHERE user_id = OLD.user_id
    AND date > CURRENT_DATE - INTERVAL '30 days';

  -- Calculate total videos watched
  SELECT 
    COUNT(DISTINCT video_id)::integer INTO v_total_videos
  FROM time_entries
  WHERE user_id = OLD.user_id
    AND video_id IS NOT NULL;

  -- Update user stats
  UPDATE user_stats
  SET
    current_streak = v_streak,
    total_minutes = v_total_minutes,
    weekly_minutes = v_weekly_minutes,
    monthly_minutes = v_monthly_minutes,
    total_videos_watched = v_total_videos,
    updated_at = NOW()
  WHERE user_id = OLD.user_id;

  RETURN OLD;
END;
$$;

-- Create trigger for stats update after deletion
DROP TRIGGER IF EXISTS update_stats_after_delete_trigger ON time_entries;
CREATE TRIGGER update_stats_after_delete_trigger
  AFTER DELETE ON time_entries
  FOR EACH ROW
  EXECUTE FUNCTION update_user_stats_after_delete();