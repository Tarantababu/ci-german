/*
  # Add video time tracking

  1. New Columns
    - Add `duration_seconds` to videos table
  
  2. New Tables
    - `video_time_entries`
      - `id` (uuid, primary key)
      - `video_id` (uuid, references videos)
      - `user_id` (uuid, references auth.users)
      - `date` (date)
      - `start_time` (time)
      - `end_time` (time)
      - `duration_seconds` (integer)
      - `notes` (text)
      - `created_at` (timestamptz)

  3. Security
    - Enable RLS on new table
    - Add policies for CRUD operations
*/

-- Add duration_seconds to videos table
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'videos' AND column_name = 'duration_seconds'
  ) THEN
    ALTER TABLE videos ADD COLUMN duration_seconds integer;
  END IF;
END $$;

-- Create video_time_entries table
CREATE TABLE IF NOT EXISTS video_time_entries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  video_id uuid REFERENCES videos(id) ON DELETE CASCADE,
  user_id uuid REFERENCES auth.users(id) DEFAULT auth.uid(),
  date date NOT NULL,
  start_time time NOT NULL,
  end_time time NOT NULL,
  duration_seconds integer NOT NULL,
  notes text,
  created_at timestamptz DEFAULT now()
);

-- Create indexes
CREATE INDEX IF NOT EXISTS video_time_entries_user_date_idx ON video_time_entries(user_id, date);
CREATE INDEX IF NOT EXISTS video_time_entries_video_idx ON video_time_entries(video_id);

-- Enable RLS
ALTER TABLE video_time_entries ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Users can read own time entries"
  ON video_time_entries
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own time entries"
  ON video_time_entries
  FOR INSERT
  TO authenticated
  WITH CHECK (true);  -- user_id is set by default

CREATE POLICY "Users can update own time entries"
  ON video_time_entries
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own time entries"
  ON video_time_entries
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);