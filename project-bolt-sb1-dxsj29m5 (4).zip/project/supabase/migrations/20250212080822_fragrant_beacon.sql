/*
  # Fix Database Triggers

  1. Changes
    - Re-enable all triggers that may have been disabled
    - Add error handling to trigger functions
    - Update trigger execution order
    - Add missing trigger dependencies

  2. Fixes
    - update_user_stats_trigger not firing consistently
    - watch_session_audit not firing
    - validate_username_trigger partial functionality
*/

-- Drop and recreate triggers with proper error handling
DROP TRIGGER IF EXISTS update_user_stats_trigger ON time_entries;
DROP TRIGGER IF EXISTS watch_session_audit ON video_watch_sessions;
DROP TRIGGER IF EXISTS validate_username_trigger ON user_profiles;

-- Recreate update_user_stats trigger with error handling
CREATE OR REPLACE FUNCTION update_user_stats()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Add error handling wrapper
  BEGIN
    -- Calculate current streak
    WITH streak_calc AS (
      SELECT 
        COUNT(DISTINCT date)::integer as streak_count
      FROM time_entries
      WHERE user_id = NEW.user_id
        AND date > CURRENT_DATE - INTERVAL '30 days'
        AND date <= CURRENT_DATE
      GROUP BY user_id
    )
    -- Update user stats
    INSERT INTO user_stats (
      user_id,
      current_streak,
      total_minutes,
      weekly_minutes,
      monthly_minutes,
      total_videos_watched,
      last_activity_at,
      updated_at
    )
    SELECT
      NEW.user_id,
      COALESCE((SELECT streak_count FROM streak_calc), 0),
      COALESCE((
        SELECT SUM(minutes)::integer
        FROM time_entries
        WHERE user_id = NEW.user_id
      ), 0),
      COALESCE((
        SELECT SUM(minutes)::integer
        FROM time_entries
        WHERE user_id = NEW.user_id
          AND date > CURRENT_DATE - INTERVAL '7 days'
      ), 0),
      COALESCE((
        SELECT SUM(minutes)::integer
        FROM time_entries
        WHERE user_id = NEW.user_id
          AND date > CURRENT_DATE - INTERVAL '30 days'
      ), 0),
      COALESCE((
        SELECT COUNT(DISTINCT video_id)::integer
        FROM time_entries
        WHERE user_id = NEW.user_id
          AND video_id IS NOT NULL
      ), 0),
      NOW(),
      NOW()
    ON CONFLICT (user_id) DO UPDATE
    SET
      current_streak = EXCLUDED.current_streak,
      longest_streak = GREATEST(user_stats.longest_streak, EXCLUDED.current_streak),
      total_minutes = EXCLUDED.total_minutes,
      weekly_minutes = EXCLUDED.weekly_minutes,
      monthly_minutes = EXCLUDED.monthly_minutes,
      total_videos_watched = EXCLUDED.total_videos_watched,
      last_activity_at = EXCLUDED.last_activity_at,
      updated_at = EXCLUDED.updated_at;

    RETURN NEW;
  EXCEPTION
    WHEN OTHERS THEN
      -- Log error but don't block the transaction
      RAISE WARNING 'Error in update_user_stats: %', SQLERRM;
      RETURN NEW;
  END;
END;
$$;

-- Recreate watch session audit trigger with error handling
CREATE OR REPLACE FUNCTION update_watch_session()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  BEGIN
    -- Log the update with error handling
    INSERT INTO video_watch_audit_logs (
      video_id,
      user_id,
      action,
      details
    ) VALUES (
      NEW.video_id,
      NEW.user_id,
      CASE
        WHEN NEW.is_complete AND OLD.is_complete = false THEN 'session_completed'
        WHEN NEW.progress_seconds > OLD.progress_seconds THEN 'progress_updated'
        ELSE 'session_updated'
      END,
      jsonb_build_object(
        'old_progress', OLD.progress_seconds,
        'new_progress', NEW.progress_seconds,
        'old_position', OLD.last_position_seconds,
        'new_position', NEW.last_position_seconds,
        'timestamp', NOW()
      )
    );
    
    RETURN NEW;
  EXCEPTION
    WHEN OTHERS THEN
      RAISE WARNING 'Error in update_watch_session: %', SQLERRM;
      RETURN NEW;
  END;
END;
$$;

-- Recreate username validation trigger with error handling
CREATE OR REPLACE FUNCTION validate_username()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  BEGIN
    -- Check if username is already taken (case insensitive)
    IF EXISTS (
      SELECT 1 FROM user_profiles
      WHERE lower(username) = lower(NEW.username)
      AND id != NEW.id
    ) THEN
      RAISE EXCEPTION 'Username already taken';
    END IF;

    -- Convert to lowercase
    NEW.username := lower(NEW.username);
    
    RETURN NEW;
  EXCEPTION
    WHEN OTHERS THEN
      -- Re-raise username taken error but handle other errors gracefully
      IF SQLERRM LIKE '%Username already taken%' THEN
        RAISE;
      ELSE
        RAISE WARNING 'Error in validate_username: %', SQLERRM;
        RETURN NEW;
      END IF;
  END;
END;
$$;

-- Re-create triggers with proper order and dependencies
CREATE TRIGGER update_user_stats_trigger
  AFTER INSERT OR UPDATE ON time_entries
  FOR EACH ROW
  EXECUTE FUNCTION update_user_stats();

CREATE TRIGGER watch_session_audit
  AFTER UPDATE ON video_watch_sessions
  FOR EACH ROW
  EXECUTE FUNCTION update_watch_session();

CREATE TRIGGER validate_username_trigger
  BEFORE INSERT OR UPDATE OF username ON user_profiles
  FOR EACH ROW
  EXECUTE FUNCTION validate_username();

-- Enable all triggers explicitly
ALTER TABLE time_entries ENABLE TRIGGER update_user_stats_trigger;
ALTER TABLE video_watch_sessions ENABLE TRIGGER watch_session_audit;
ALTER TABLE user_profiles ENABLE TRIGGER validate_username_trigger;

-- Create index for better trigger performance
CREATE INDEX IF NOT EXISTS time_entries_user_date_idx ON time_entries(user_id, date);
CREATE INDEX IF NOT EXISTS video_watch_sessions_user_progress_idx ON video_watch_sessions(user_id, progress_seconds);
CREATE INDEX IF NOT EXISTS user_profiles_username_lower_idx ON user_profiles(lower(username));