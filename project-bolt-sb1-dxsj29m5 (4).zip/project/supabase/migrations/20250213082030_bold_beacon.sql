/*
  # Fix comment system policies

  1. Changes
    - Drop all existing policies first
    - Recreate comment permissions table
    - Add proper indexes
    - Create new policies with proper checks
    - Add moderation functions

  2. Security
    - Enable RLS
    - Add proper role-based access control
    - Implement secure moderation functions
*/

-- Drop all existing policies
DO $$ 
BEGIN
  -- Drop video_comments policies
  DROP POLICY IF EXISTS "Anyone can read comments" ON video_comments;
  DROP POLICY IF EXISTS "Users can read active comments" ON video_comments;
  DROP POLICY IF EXISTS "Moderators can read all comments" ON video_comments;
  DROP POLICY IF EXISTS "Users can create comments" ON video_comments;
  DROP POLICY IF EXISTS "Users can update own comments" ON video_comments;
  
  -- Drop comment_permissions policies
  DROP POLICY IF EXISTS "Users can view permissions" ON comment_permissions;
  DROP POLICY IF EXISTS "Users can view own permissions" ON comment_permissions;
  DROP POLICY IF EXISTS "Admins can manage permissions" ON comment_permissions;
END $$;

-- Recreate comment permissions table
DROP TABLE IF EXISTS comment_permissions CASCADE;
CREATE TABLE comment_permissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  video_id uuid REFERENCES videos(id) ON DELETE CASCADE,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  role text NOT NULL CHECK (role IN ('moderator', 'admin')),
  created_at timestamptz DEFAULT now(),
  UNIQUE(video_id, user_id)
);

-- Enable RLS on comment permissions
ALTER TABLE comment_permissions ENABLE ROW LEVEL SECURITY;

-- Create indexes for better performance
CREATE INDEX comment_permissions_video_user_idx ON comment_permissions(video_id, user_id);
CREATE INDEX comment_permissions_role_idx ON comment_permissions(role);

-- Ensure video_comments has status column
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'video_comments' AND column_name = 'status'
  ) THEN
    ALTER TABLE video_comments ADD COLUMN status text NOT NULL DEFAULT 'active';
    ALTER TABLE video_comments ADD CONSTRAINT valid_status CHECK (status IN ('active', 'hidden', 'deleted'));
  END IF;
END $$;

-- Create index for status
CREATE INDEX IF NOT EXISTS video_comments_status_idx ON video_comments(status);

-- Create new policies for video_comments
CREATE POLICY "Read active comments"
  ON video_comments
  FOR SELECT
  TO authenticated
  USING (status = 'active');

CREATE POLICY "Create own comments"
  ON video_comments
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id AND status = 'active');

CREATE POLICY "Update own comments"
  ON video_comments
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id AND status = 'active');

-- Create policies for comment_permissions
CREATE POLICY "View own permissions"
  ON comment_permissions
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Admin manage permissions"
  ON comment_permissions
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 
      FROM comment_permissions cp
      WHERE cp.user_id = auth.uid()
      AND cp.role = 'admin'
      AND cp.video_id = comment_permissions.video_id
    )
  );

-- Create function to check user permission level
CREATE OR REPLACE FUNCTION get_user_permission_level(p_video_id uuid)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_role text;
BEGIN
  SELECT role INTO v_role
  FROM comment_permissions
  WHERE video_id = p_video_id
    AND user_id = auth.uid()
  LIMIT 1;
    
  RETURN COALESCE(v_role, 'viewer');
END;
$$;

-- Create function to moderate comments
CREATE OR REPLACE FUNCTION moderate_comment(
  p_comment_id uuid,
  p_action text
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_video_id uuid;
  v_role text;
BEGIN
  -- Get video_id for the comment
  SELECT video_id INTO v_video_id
  FROM video_comments
  WHERE id = p_comment_id;
  
  -- Get user's role
  SELECT role INTO v_role
  FROM comment_permissions
  WHERE video_id = v_video_id
    AND user_id = auth.uid()
  LIMIT 1;
  
  -- Only moderators and admins can moderate
  IF v_role NOT IN ('moderator', 'admin') THEN
    RETURN false;
  END IF;
  
  -- Perform moderation action
  UPDATE video_comments
  SET status = 
    CASE p_action
      WHEN 'hide' THEN 'hidden'
      WHEN 'delete' THEN 'deleted'
      WHEN 'restore' THEN 'active'
    END
  WHERE id = p_comment_id;
  
  RETURN true;
END;
$$;