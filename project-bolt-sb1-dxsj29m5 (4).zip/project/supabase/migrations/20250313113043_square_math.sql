/*
  # Add Social Sharing Analytics

  1. New Tables
    - `share_analytics`
      - Track sharing events and referrals
      - Monitor click-through rates
      - Record new sign-ups from shared links

  2. Security
    - Enable RLS
    - Add policies for tracking
*/

-- Create share analytics table
CREATE TABLE IF NOT EXISTS share_analytics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id),
  share_type text NOT NULL CHECK (share_type IN ('email', 'facebook', 'twitter', 'linkedin', 'whatsapp', 'copy')),
  referral_code text,
  clicks integer DEFAULT 0,
  conversions integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE share_analytics ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can view own share analytics"
  ON share_analytics
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can create share analytics"
  ON share_analytics
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

-- Create function to track share event
CREATE OR REPLACE FUNCTION track_share_event(
  p_share_type text,
  p_referral_code text DEFAULT NULL
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_share_id uuid;
BEGIN
  INSERT INTO share_analytics (
    user_id,
    share_type,
    referral_code
  ) VALUES (
    auth.uid(),
    p_share_type,
    p_referral_code
  )
  RETURNING id INTO v_share_id;
  
  RETURN v_share_id;
END;
$$;

-- Create function to track share click
CREATE OR REPLACE FUNCTION track_share_click(
  p_referral_code text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE share_analytics
  SET 
    clicks = clicks + 1,
    updated_at = now()
  WHERE referral_code = p_referral_code;
END;
$$;

-- Create function to track share conversion
CREATE OR REPLACE FUNCTION track_share_conversion(
  p_referral_code text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE share_analytics
  SET 
    conversions = conversions + 1,
    updated_at = now()
  WHERE referral_code = p_referral_code;
END;
$$;

-- Create indexes for better performance
CREATE INDEX share_analytics_user_idx ON share_analytics(user_id);
CREATE INDEX share_analytics_referral_code_idx ON share_analytics(referral_code);
CREATE INDEX share_analytics_type_idx ON share_analytics(share_type);