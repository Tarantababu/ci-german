/*
  # Fix User Registration Flow

  1. Changes
    - Drop and recreate user registration triggers in correct order
    - Add proper error handling
    - Ensure atomic operations
  
  2. Security
    - Maintain RLS policies
    - Use SECURITY DEFINER for sensitive operations
*/

-- Drop existing triggers and functions
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP TRIGGER IF EXISTS validate_user_data_trigger ON auth.users;
DROP FUNCTION IF EXISTS handle_new_user_registration();
DROP FUNCTION IF EXISTS validate_user_data();

-- Create function to handle new user registration
CREATE OR REPLACE FUNCTION handle_new_user_registration()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Create user profile first
  INSERT INTO user_profiles (id)
  VALUES (NEW.id)
  ON CONFLICT (id) DO NOTHING;

  -- Initialize user stats
  INSERT INTO user_stats (
    user_id,
    current_streak,
    longest_streak,
    total_minutes,
    weekly_minutes,
    monthly_minutes,
    total_videos_watched,
    level,
    last_activity_at,
    updated_at
  )
  VALUES (
    NEW.id,
    0,
    0,
    0,
    0,
    0,
    0,
    1,
    NOW(),
    NOW()
  )
  ON CONFLICT (user_id) DO NOTHING;

  -- Log first achievement
  INSERT INTO user_achievements (
    user_id,
    achievement_type,
    achievement_data,
    unlocked_at
  )
  VALUES (
    NEW.id,
    'account_created',
    jsonb_build_object(
      'email', NEW.email,
      'created_at', NOW()
    ),
    NOW()
  )
  ON CONFLICT (user_id, achievement_type) DO NOTHING;

  RETURN NEW;
EXCEPTION
  WHEN OTHERS THEN
    -- Log error details
    RAISE WARNING 'Error in handle_new_user_registration: %', SQLERRM;
    RETURN NEW;
END;
$$;

-- Create trigger for new user registration
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION handle_new_user_registration();

-- Create function to ensure data consistency
CREATE OR REPLACE FUNCTION ensure_user_data_consistency()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Ensure user profile exists
  INSERT INTO user_profiles (id)
  VALUES (NEW.id)
  ON CONFLICT (id) DO NOTHING;

  -- Ensure user stats exist
  INSERT INTO user_stats (user_id)
  VALUES (NEW.id)
  ON CONFLICT (user_id) DO NOTHING;

  RETURN NEW;
EXCEPTION
  WHEN OTHERS THEN
    RAISE WARNING 'Error in ensure_user_data_consistency: %', SQLERRM;
    RETURN NEW;
END;
$$;

-- Create trigger for data consistency
CREATE TRIGGER ensure_user_data_consistency_trigger
  AFTER INSERT OR UPDATE ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION ensure_user_data_consistency();