/*
  # Add delete policy for time entries

  1. Changes
    - Add new RLS policy to allow users to delete their own time entries
  
  2. Security
    - Policy ensures users can only delete their own time entries
    - Requires authentication
*/

-- Add delete policy for time entries
CREATE POLICY "Users can delete own time entries"
  ON time_entries
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);