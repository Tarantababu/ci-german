/*
  # Fix type mismatch in get_user_history function

  1. Changes
    - Cast email to text to match return type
    - Maintain existing security and functionality
*/

-- Drop and recreate the function with proper type casting
CREATE OR REPLACE FUNCTION get_user_history(
  p_user_id uuid,
  p_limit integer DEFAULT 50,
  p_offset integer DEFAULT 0
)
RETURNS TABLE (
  id uuid,
  date date,
  minutes integer,
  activity_type text,
  description text,
  video_id uuid,
  created_at timestamptz,
  created_by uuid,
  updated_at timestamptz,
  updated_by uuid,
  last_modified_by_email text,
  has_audit_logs boolean
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  WITH audit_logs AS (
    SELECT DISTINCT entry_id
    FROM time_entries_audit_log
  )
  SELECT 
    t.id,
    t.date,
    t.minutes,
    t.activity_type,
    t.description,
    t.video_id,
    t.created_at,
    t.created_by,
    t.updated_at,
    t.updated_by,
    (SELECT u.email::text FROM auth.users u WHERE u.id = COALESCE(t.updated_by, t.created_by)),
    EXISTS (
      SELECT 1 FROM audit_logs a 
      WHERE a.entry_id = t.id
    ) as has_audit_logs
  FROM time_entries t
  WHERE t.user_id = p_user_id
  ORDER BY t.date DESC, t.created_at DESC
  LIMIT p_limit
  OFFSET p_offset;
END;
$$;