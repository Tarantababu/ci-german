/*
  # Fix Time Entries Audit Log

  1. Changes
    - Drop ON DELETE CASCADE from audit log foreign key
    - Update trigger function to handle deletions properly
    - Add proper error handling
  
  2. Security
    - Maintain existing RLS policies
    - Keep security checks in place
*/

-- First drop the existing foreign key constraint
ALTER TABLE time_entries_audit_log
  DROP CONSTRAINT IF EXISTS time_entries_audit_log_entry_id_fkey;

-- Add the foreign key back without CASCADE
ALTER TABLE time_entries_audit_log
  ADD CONSTRAINT time_entries_audit_log_entry_id_fkey
  FOREIGN KEY (entry_id)
  REFERENCES time_entries(id)
  ON DELETE SET NULL;

-- Update the audit log function to handle deletions properly
CREATE OR REPLACE FUNCTION log_time_entry_change()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_old_data jsonb := NULL;
  v_new_data jsonb := NULL;
  v_action text;
BEGIN
  -- Determine action and prepare data
  IF (TG_OP = 'DELETE') THEN
    v_action := 'delete';
    v_old_data := row_to_json(OLD)::jsonb;

    -- For deletions, insert the audit log before the deletion occurs
    INSERT INTO time_entries_audit_log (
      entry_id,
      user_id,
      action,
      old_data,
      new_data,
      ip_address,
      user_agent
    ) VALUES (
      OLD.id,
      auth.uid(),
      v_action,
      v_old_data,
      NULL,
      current_setting('request.headers', true)::json->>'x-forwarded-for',
      current_setting('request.headers', true)::json->>'user-agent'
    );

  ELSIF (TG_OP = 'UPDATE') THEN
    v_action := 'update';
    v_old_data := row_to_json(OLD)::jsonb;
    v_new_data := row_to_json(NEW)::jsonb;

    -- For updates, insert the audit log
    INSERT INTO time_entries_audit_log (
      entry_id,
      user_id,
      action,
      old_data,
      new_data,
      ip_address,
      user_agent
    ) VALUES (
      NEW.id,
      auth.uid(),
      v_action,
      v_old_data,
      v_new_data,
      current_setting('request.headers', true)::json->>'x-forwarded-for',
      current_setting('request.headers', true)::json->>'user-agent'
    );

    -- Set updated_by and updated_at
    NEW.updated_by := auth.uid();
    NEW.updated_at := now();

  ELSE
    v_action := 'create';
    v_new_data := row_to_json(NEW)::jsonb;

    -- For inserts, insert the audit log
    INSERT INTO time_entries_audit_log (
      entry_id,
      user_id,
      action,
      old_data,
      new_data,
      ip_address,
      user_agent
    ) VALUES (
      NEW.id,
      auth.uid(),
      v_action,
      NULL,
      v_new_data,
      current_setting('request.headers', true)::json->>'x-forwarded-for',
      current_setting('request.headers', true)::json->>'user-agent'
    );
  END IF;

  -- Return the appropriate record
  IF (TG_OP = 'DELETE') THEN
    RETURN OLD;
  ELSE
    RETURN NEW;
  END IF;

EXCEPTION
  WHEN OTHERS THEN
    -- Log error but don't block the operation
    RAISE WARNING 'Error in log_time_entry_change: %', SQLERRM;
    
    IF (TG_OP = 'DELETE') THEN
      RETURN OLD;
    ELSE
      RETURN NEW;
    END IF;
END;
$$;