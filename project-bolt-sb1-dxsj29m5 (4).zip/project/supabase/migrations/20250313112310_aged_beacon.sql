/*
  # Update User Level Calculation

  1. Changes
    - Add function to calculate user level based on total minutes
    - Update trigger to recalculate level on time entry changes
    - Add level thresholds and progression logic
  
  2. Security
    - Maintain RLS policies
    - Use SECURITY DEFINER for sensitive operations
*/

-- Create function to calculate user level based on total minutes
CREATE OR REPLACE FUNCTION calculate_user_level(p_total_minutes integer)
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Level thresholds (in minutes):
  -- Level 1: 0-3000 (0-50 hours)
  -- Level 2: 3000-9000 (50-150 hours)
  -- Level 3: 9000-18000 (150-300 hours)
  -- Level 4: 18000-36000 (300-600 hours)
  -- Level 5: 36000-60000 (600-1000 hours)
  -- Level 6: 60000-90000 (1000-1500 hours)
  -- Level 7: 90000+ (1500+ hours)

  RETURN CASE
    WHEN p_total_minutes < 3000 THEN 1
    WHEN p_total_minutes < 9000 THEN 2
    WHEN p_total_minutes < 18000 THEN 3
    WHEN p_total_minutes < 36000 THEN 4
    WHEN p_total_minutes < 60000 THEN 5
    WHEN p_total_minutes < 90000 THEN 6
    ELSE 7
  END;
END;
$$;

-- Update the user stats update function to include level calculation
CREATE OR REPLACE FUNCTION update_user_stats()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_streak integer;
  v_total_minutes integer;
  v_weekly_minutes integer;
  v_monthly_minutes integer;
  v_total_videos integer;
  v_new_level integer;
BEGIN
  -- Calculate current streak
  SELECT 
    COUNT(DISTINCT date)::integer INTO v_streak
  FROM time_entries
  WHERE user_id = NEW.user_id
    AND date > CURRENT_DATE - INTERVAL '30 days'
    AND date <= CURRENT_DATE
  GROUP BY user_id;

  -- Calculate total minutes
  SELECT 
    COALESCE(SUM(minutes), 0)::integer INTO v_total_minutes
  FROM time_entries
  WHERE user_id = NEW.user_id;

  -- Calculate weekly minutes
  SELECT 
    COALESCE(SUM(minutes), 0)::integer INTO v_weekly_minutes
  FROM time_entries
  WHERE user_id = NEW.user_id
    AND date > CURRENT_DATE - INTERVAL '7 days';

  -- Calculate monthly minutes
  SELECT 
    COALESCE(SUM(minutes), 0)::integer INTO v_monthly_minutes
  FROM time_entries
  WHERE user_id = NEW.user_id
    AND date > CURRENT_DATE - INTERVAL '30 days';

  -- Calculate total videos watched
  SELECT 
    COUNT(DISTINCT video_id)::integer INTO v_total_videos
  FROM time_entries
  WHERE user_id = NEW.user_id
    AND video_id IS NOT NULL;

  -- Calculate new level based on total minutes
  v_new_level := calculate_user_level(v_total_minutes);

  -- Update user stats
  INSERT INTO user_stats (
    user_id,
    current_streak,
    longest_streak,
    total_minutes,
    weekly_minutes,
    monthly_minutes,
    total_videos_watched,
    level,
    last_activity_at,
    updated_at
  ) VALUES (
    NEW.user_id,
    COALESCE(v_streak, 0),
    0, -- Will be updated in the ON CONFLICT clause
    v_total_minutes,
    v_weekly_minutes,
    v_monthly_minutes,
    v_total_videos,
    v_new_level,
    NOW(),
    NOW()
  )
  ON CONFLICT (user_id) DO UPDATE
  SET
    current_streak = EXCLUDED.current_streak,
    longest_streak = GREATEST(user_stats.longest_streak, EXCLUDED.current_streak),
    total_minutes = EXCLUDED.total_minutes,
    weekly_minutes = EXCLUDED.weekly_minutes,
    monthly_minutes = EXCLUDED.monthly_minutes,
    total_videos_watched = EXCLUDED.total_videos_watched,
    level = EXCLUDED.level,
    last_activity_at = EXCLUDED.last_activity_at,
    updated_at = EXCLUDED.updated_at;

  -- Log level up event if level increased
  IF v_new_level > COALESCE((SELECT level FROM user_stats WHERE user_id = NEW.user_id), 1) THEN
    INSERT INTO user_achievements (
      user_id,
      achievement_type,
      achievement_data,
      unlocked_at
    ) VALUES (
      NEW.user_id,
      'level_up',
      jsonb_build_object(
        'old_level', (SELECT level FROM user_stats WHERE user_id = NEW.user_id),
        'new_level', v_new_level,
        'total_minutes', v_total_minutes
      ),
      NOW()
    )
    ON CONFLICT (user_id, achievement_type) DO UPDATE
    SET 
      achievement_data = EXCLUDED.achievement_data,
      unlocked_at = EXCLUDED.unlocked_at;
  END IF;

  RETURN NEW;
END;
$$;

-- Create function to get level progress
CREATE OR REPLACE FUNCTION get_level_progress(p_total_minutes integer)
RETURNS TABLE (
  current_level integer,
  next_level integer,
  progress_percentage numeric,
  minutes_needed integer
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_current_level integer;
  v_next_level_threshold integer;
  v_current_level_threshold integer;
BEGIN
  -- Get current level
  v_current_level := calculate_user_level(p_total_minutes);
  
  -- Calculate thresholds
  v_current_level_threshold := CASE v_current_level
    WHEN 1 THEN 0
    WHEN 2 THEN 3000
    WHEN 3 THEN 9000
    WHEN 4 THEN 18000
    WHEN 5 THEN 36000
    WHEN 6 THEN 60000
    WHEN 7 THEN 90000
  END;
  
  v_next_level_threshold := CASE v_current_level
    WHEN 1 THEN 3000
    WHEN 2 THEN 9000
    WHEN 3 THEN 18000
    WHEN 4 THEN 36000
    WHEN 5 THEN 60000
    WHEN 6 THEN 90000
    ELSE NULL
  END;

  RETURN QUERY
  SELECT 
    v_current_level as current_level,
    v_current_level + 1 as next_level,
    CASE 
      WHEN v_current_level = 7 THEN 100
      ELSE ROUND(
        ((p_total_minutes - v_current_level_threshold)::numeric / 
        (v_next_level_threshold - v_current_level_threshold)::numeric * 100)::numeric,
        1
      )
    END as progress_percentage,
    CASE 
      WHEN v_current_level = 7 THEN 0
      ELSE v_next_level_threshold - p_total_minutes
    END as minutes_needed;
END;
$$;