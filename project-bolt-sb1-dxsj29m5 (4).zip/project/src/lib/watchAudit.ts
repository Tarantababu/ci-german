import { supabase } from './supabase';
import toast from 'react-hot-toast';

interface WatchAuditLog {
  videoId: string;
  action: 'watch_start' | 'watch_complete' | 'watch_cancel';
  details?: Record<string, any>;
}

export class WatchAuditManager {
  async logWatchEvent({ videoId, action, details = {} }: WatchAuditLog): Promise<void> {
    try {
      const { error } = await supabase
        .from('video_watch_audit_logs')
        .insert({
          video_id: videoId,
          action,
          details
        });

      if (error) throw error;
    } catch (error) {
      console.error('Error logging watch event:', error);
      throw error;
    }
  }

  async getWatchHistory(videoId: string) {
    try {
      const { data, error } = await supabase
        .from('video_watch_audit_logs')
        .select('*')
        .eq('video_id', videoId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error fetching watch history:', error);
      throw error;
    }
  }
}

export const watchAuditManager = new WatchAuditManager();