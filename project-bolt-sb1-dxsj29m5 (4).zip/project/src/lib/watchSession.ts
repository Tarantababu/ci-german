import { supabase } from './supabase';
import { VideoWatchSession } from '../types';

export class WatchSessionManager {
  private currentSession: VideoWatchSession | null = null;
  private updateInterval: number | null = null;
  private lastUpdateTime: number = 0;
  private readonly UPDATE_INTERVAL = 5000; // 5 seconds

  async startSession(videoId: string): Promise<VideoWatchSession | null> {
    try {
      // End any existing sessions
      await this.endCurrentSession();

      // Start new session
      const { data, error } = await supabase
        .from('video_watch_sessions')
        .insert({
          video_id: videoId,
          progress_seconds: 0,
          last_position_seconds: 0
        })
        .select()
        .single();

      if (error) throw error;

      this.currentSession = data;
      this.startProgressTracking();

      return data;
    } catch (error) {
      console.error('Error starting watch session:', error);
      return null;
    }
  }

  async updateProgress(position: number): Promise<void> {
    if (!this.currentSession) return;

    const now = Date.now();
    if (now - this.lastUpdateTime < this.UPDATE_INTERVAL) return;

    try {
      const { error } = await supabase
        .from('video_watch_sessions')
        .update({
          progress_seconds: position,
          last_position_seconds: position
        })
        .eq('id', this.currentSession.id);

      if (error) throw error;
      this.lastUpdateTime = now;
    } catch (error) {
      console.error('Error updating progress:', error);
    }
  }

  async endCurrentSession(): Promise<void> {
    if (!this.currentSession) return;

    try {
      const { error } = await supabase
        .from('video_watch_sessions')
        .update({
          ended_at: new Date().toISOString(),
          is_complete: true
        })
        .eq('id', this.currentSession.id);

      if (error) throw error;

      this.stopProgressTracking();
      this.currentSession = null;
    } catch (error) {
      console.error('Error ending watch session:', error);
    }
  }

  private startProgressTracking(): void {
    if (this.updateInterval) return;

    this.updateInterval = window.setInterval(() => {
      // Implement progress tracking logic here
      // This should be connected to the video player's time update event
    }, this.UPDATE_INTERVAL);
  }

  private stopProgressTracking(): void {
    if (this.updateInterval) {
      clearInterval(this.updateInterval);
      this.updateInterval = null;
    }
  }

  // Clean up when component unmounts
  destroy(): void {
    this.stopProgressTracking();
    this.endCurrentSession();
  }
}

export const watchSessionManager = new WatchSessionManager();