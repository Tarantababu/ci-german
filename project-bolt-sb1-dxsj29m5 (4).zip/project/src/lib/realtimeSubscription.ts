import { RealtimeChannel } from '@supabase/supabase-js';
import { supabase } from './supabase';
import toast from 'react-hot-toast';

type SubscriptionCallback = () => void;
type ErrorCallback = (error: Error) => void;

class RealtimeSubscriptionManager {
  private channels: Map<string, RealtimeChannel> = new Map();
  private callbacks: Map<string, Set<SubscriptionCallback>> = new Map();
  private errorCallbacks: Map<string, ErrorCallback> = new Map();

  subscribe(
    table: string,
    callback: SubscriptionCallback,
    onError?: ErrorCallback
  ): () => void {
    // Create a unique identifier for this subscription
    const subscriptionId = `${table}_${Date.now()}`;

    // Store the callback
    if (!this.callbacks.has(table)) {
      this.callbacks.set(table, new Set());
    }
    this.callbacks.get(table)?.add(callback);

    if (onError) {
      this.errorCallbacks.set(subscriptionId, onError);
    }

    // Create or reuse channel
    if (!this.channels.has(table)) {
      const channel = supabase
        .channel(`${table}_changes`)
        .on(
          'postgres_changes',
          { event: '*', schema: 'public', table },
          async (payload) => {
            try {
              // Execute all callbacks for this table
              const callbacks = this.callbacks.get(table);
              if (callbacks) {
                for (const cb of callbacks) {
                  await cb();
                }
              }
            } catch (error) {
              console.error(`Error in realtime subscription for ${table}:`, error);
              const errorCallback = this.errorCallbacks.get(subscriptionId);
              if (errorCallback) {
                errorCallback(error instanceof Error ? error : new Error(String(error)));
              }
              toast.error('Failed to update data');
            }
          }
        )
        .subscribe((status) => {
          if (status === 'SUBSCRIBED') {
            console.debug(`Subscribed to ${table} changes`);
          } else if (status === 'CHANNEL_ERROR') {
            console.error(`Error subscribing to ${table} changes`);
            const errorCallback = this.errorCallbacks.get(subscriptionId);
            if (errorCallback) {
              errorCallback(new Error(`Failed to subscribe to ${table} changes`));
            }
            toast.error('Failed to establish real-time connection');
          }
        });

      this.channels.set(table, channel);
    }

    // Return unsubscribe function
    return () => {
      const callbacks = this.callbacks.get(table);
      if (callbacks) {
        callbacks.delete(callback);
        if (callbacks.size === 0) {
          const channel = this.channels.get(table);
          if (channel) {
            channel.unsubscribe();
            this.channels.delete(table);
          }
          this.callbacks.delete(table);
        }
      }
      this.errorCallbacks.delete(subscriptionId);
    };
  }

  unsubscribeAll() {
    for (const channel of this.channels.values()) {
      channel.unsubscribe();
    }
    this.channels.clear();
    this.callbacks.clear();
    this.errorCallbacks.clear();
  }
}

export const realtimeManager = new RealtimeSubscriptionManager();