import { supabase } from './supabase';
import { sanitizeHtml } from './utils';

export interface Comment {
  id: string;
  video_id: string;
  user_id: string;
  content: string;
  status: 'active' | 'hidden' | 'deleted';
  likes: number;
  dislikes: number;
  created_at: string;
  parent_id?: string;
  user_data: {
    email: string;
  };
}

interface FetchCommentsOptions {
  videoId: string;
  page?: number;
  limit?: number;
}

export const commentService = {
  async fetchComments({ videoId, page = 1, limit = 20 }: FetchCommentsOptions) {
    const start = (page - 1) * limit;
    
    const { data, error, count } = await supabase
      .from('video_comments')
      .select('*', { count: 'exact' })
      .eq('video_id', videoId)
      .eq('status', 'active')
      .order('created_at', { ascending: false })
      .range(start, start + limit - 1);

    if (error) throw error;

    return {
      comments: data as Comment[],
      total: count || 0,
      hasMore: (count || 0) > start + limit
    };
  },

  async addComment(videoId: string, content: string, parentId?: string) {
    // Sanitize content
    const sanitizedContent = sanitizeHtml(content);

    const { data, error } = await supabase
      .from('video_comments')
      .insert({
        video_id: videoId,
        content: sanitizedContent,
        parent_id: parentId
      })
      .select()
      .single();

    if (error) throw error;
    return data as Comment;
  },

  async updateComment(commentId: string, content: string) {
    const sanitizedContent = sanitizeHtml(content);

    const { data, error } = await supabase
      .from('video_comments')
      .update({ content: sanitizedContent })
      .eq('id', commentId)
      .select()
      .single();

    if (error) throw error;
    return data as Comment;
  },

  async deleteComment(commentId: string) {
    const { error } = await supabase
      .from('video_comments')
      .update({ status: 'deleted' })
      .eq('id', commentId);

    if (error) throw error;
  },

  async moderateComment(commentId: string, action: 'hide' | 'delete' | 'restore') {
    const { data, error } = await supabase
      .rpc('moderate_comment', {
        p_comment_id: commentId,
        p_action: action
      });

    if (error) throw error;
    return data;
  },

  async getUserPermissionLevel(videoId: string) {
    const { data, error } = await supabase
      .rpc('get_user_permission_level', {
        p_video_id: videoId
      });

    if (error) throw error;
    return data as 'viewer' | 'moderator' | 'admin';
  }
};