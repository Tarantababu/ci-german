import React, { useState, useEffect } from 'react';
import { X } from 'lucide-react';

export interface Alert {
  id: string;
  message: string;
  type: 'error' | 'warning' | 'info' | 'success';
  duration?: number;
}

interface AlertSystemProps {
  alerts: Alert[];
  onDismiss: (id: string) => void;
}

export function AlertSystem({ alerts, onDismiss }: AlertSystemProps) {
  const getAlertStyles = (type: Alert['type']) => {
    switch (type) {
      case 'error':
        return 'bg-red-50 border-red-200 text-red-800';
      case 'warning':
        return 'bg-yellow-50 border-yellow-200 text-yellow-800';
      case 'success':
        return 'bg-green-50 border-green-200 text-green-800';
      default:
        return 'bg-blue-50 border-blue-200 text-blue-800';
    }
  };

  return (
    <div className="fixed bottom-5 right-5 z-50 flex flex-col-reverse gap-2 max-w-[400px]">
      {alerts.slice(0, 3).map((alert) => (
        <div
          key={alert.id}
          className={`flex items-start gap-2 p-4 rounded-lg border shadow-sm animate-fade-in ${getAlertStyles(alert.type)}`}
          style={{ minWidth: '300px' }}
        >
          <p className="flex-1 text-sm">{alert.message}</p>
          <button
            onClick={() => onDismiss(alert.id)}
            className="p-1 hover:opacity-75 transition-opacity"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      ))}
    </div>
  );
}