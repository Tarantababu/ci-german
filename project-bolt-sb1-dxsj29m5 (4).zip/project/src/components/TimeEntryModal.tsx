import React, { useState } from 'react';
import { format } from 'date-fns';
import { supabase } from '../lib/supabase';
import { Film, Headphones, Users } from 'lucide-react';
import { useAlerts } from '../hooks/useAlerts';

interface TimeEntryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: () => void;
}

export function TimeEntryModal({ isOpen, onClose, onSave }: TimeEntryModalProps) {
  const { showSuccess, showError } = useAlerts();
  const [date, setDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [hours, setHours] = useState(0);
  const [minutes, setMinutes] = useState(0);
  const [activityType, setActivityType] = useState<'watching' | 'listening' | 'talking'>('watching');
  const [description, setDescription] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      const totalMinutes = hours * 60 + minutes;
      const { error } = await supabase
        .from('time_entries')
        .insert({
          date,
          minutes: totalMinutes,
          activity_type: activityType,
          description,
        });

      if (error) throw error;
      
      showSuccess('Time entry saved!');
      onSave();
      onClose();
    } catch (error) {
      console.error('Error saving time entry:', error);
      showError('Failed to save time entry');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg max-w-md w-full p-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold">Add time outside the platform</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            ×
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">Date</label>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Activity</label>
            <div className="grid grid-cols-3 gap-4 mt-1">
              <button
                type="button"
                onClick={() => setActivityType('watching')}
                className={`p-4 rounded-lg flex flex-col items-center ${
                  activityType === 'watching' ? 'bg-orange-500 text-white' : 'bg-gray-100'
                }`}
              >
                <Film className="mb-2" />
                <span className="text-sm">Watching</span>
                <span className="text-xs">Movies / TV shows</span>
              </button>
              <button
                type="button"
                onClick={() => setActivityType('listening')}
                className={`p-4 rounded-lg flex flex-col items-center ${
                  activityType === 'listening' ? 'bg-orange-500 text-white' : 'bg-gray-100'
                }`}
              >
                <Headphones className="mb-2" />
                <span className="text-sm">Listening</span>
                <span className="text-xs">To podcasts / audiobooks</span>
              </button>
              <button
                type="button"
                onClick={() => setActivityType('talking')}
                className={`p-4 rounded-lg flex flex-col items-center ${
                  activityType === 'talking' ? 'bg-orange-500 text-white' : 'bg-gray-100'
                }`}
              >
                <Users className="mb-2" />
                <span className="text-sm">Talking</span>
                <span className="text-xs">With friends</span>
              </button>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Duration</label>
            <div className="grid grid-cols-2 gap-4 mt-1">
              <div>
                <input
                  type="number"
                  min="0"
                  value={hours}
                  onChange={(e) => setHours(parseInt(e.target.value) || 0)}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  placeholder="0"
                />
                <span className="text-sm text-gray-500">Hours</span>
              </div>
              <div>
                <input
                  type="number"
                  min="0"
                  max="59"
                  value={minutes}
                  onChange={(e) => setMinutes(parseInt(e.target.value) || 0)}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  placeholder="0"
                />
                <span className="text-sm text-gray-500">Minutes</span>
              </div>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Description (optional)
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              placeholder="E.g., name of TV show, podcast, etc."
              rows={3}
            />
          </div>

          <div className="flex justify-end gap-4">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-gray-700 hover:text-gray-500"
              disabled={loading}
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-4 py-2 text-sm font-medium text-white bg-orange-500 rounded-md hover:bg-orange-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500"
            >
              {loading ? 'Saving...' : 'Save'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}