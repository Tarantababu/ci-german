import React from 'react';
import { VideoLevel } from '../types';
import { X, Eye, EyeOff, Filter, Clock } from 'lucide-react';
import { LevelIndicator } from './LevelIndicator';

interface VideoFiltersProps {
  selectedLevels: VideoLevel[];
  setSelectedLevels: (levels: VideoLevel[]) => void;
  selectedTags: string[];
  setSelectedTags: (tags: string[]) => void;
  availableTags: string[];
  hideWatched: boolean;
  setHideWatched: (hide: boolean) => void;
  durationRange: [number, number];
  setDurationRange: (range: [number, number]) => void;
  onClearFilters: () => void;
}

const DURATION_RANGES = [
  { label: 'Any length', min: 0, max: Infinity },
  { label: 'Under 4 minutes', min: 0, max: 4 },
  { label: '4-10 minutes', min: 4, max: 10 },
  { label: '10-20 minutes', min: 10, max: 20 },
  { label: 'Over 20 minutes', min: 20, max: Infinity }
];

export function VideoFilters({
  selectedLevels,
  setSelectedLevels,
  selectedTags,
  setSelectedTags,
  availableTags,
  hideWatched,
  setHideWatched,
  durationRange,
  setDurationRange,
  onClearFilters,
}: VideoFiltersProps) {
  const levels: VideoLevel[] = ['superbeginner', 'beginner', 'intermediate', 'advanced'];

  const toggleLevel = (level: VideoLevel) => {
    if (selectedLevels.includes(level)) {
      setSelectedLevels(selectedLevels.filter((l) => l !== level));
    } else {
      setSelectedLevels([...selectedLevels, level]);
    }
  };

  const toggleTag = (tag: string) => {
    if (selectedTags.includes(tag)) {
      setSelectedTags(selectedTags.filter((t) => t !== tag));
    } else {
      setSelectedTags([...selectedTags, tag]);
    }
  };

  const hasActiveFilters = selectedLevels.length > 0 || 
    selectedTags.length > 0 || 
    hideWatched || 
    (durationRange[0] !== 0 || durationRange[1] !== Infinity);

  return (
    <div className="bg-white rounded-lg shadow-sm divide-y sticky top-0 z-10">
      <div className="p-4">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Filter className="w-5 h-5 text-gray-500" />
            <h2 className="text-lg font-medium text-gray-900">Filters</h2>
          </div>
          {hasActiveFilters && (
            <button
              onClick={onClearFilters}
              className="text-sm text-gray-500 hover:text-gray-700 flex items-center gap-1"
            >
              <X className="w-4 h-4" />
              Clear all
            </button>
          )}
        </div>

        <div className="flex items-center justify-between border-b pb-4">
          <div className="flex items-center gap-2">
            {hideWatched ? (
              <EyeOff className="w-5 h-5 text-purple-500" />
            ) : (
              <Eye className="w-5 h-5 text-gray-400" />
            )}
            <span className="text-sm font-medium text-gray-700">Hide watched videos</span>
          </div>
          <button
            onClick={() => setHideWatched(!hideWatched)}
            className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
              hideWatched ? 'bg-purple-500' : 'bg-gray-200'
            }`}
            role="switch"
            aria-checked={hideWatched}
          >
            <span
              className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                hideWatched ? 'translate-x-6' : 'translate-x-1'
              }`}
            />
          </button>
        </div>
      </div>

      <div className="p-4">
        <h3 className="text-sm font-medium text-gray-700 mb-2">Level</h3>
        <div className="flex flex-wrap gap-2">
          {levels.map((level) => (
            <button
              key={level}
              onClick={() => toggleLevel(level)}
              className={`transition-transform ${
                selectedLevels.includes(level) ? 'scale-110' : 'opacity-75 hover:opacity-100'
              }`}
            >
              <LevelIndicator 
                level={level} 
                showLabel={true}
                size="sm"
              />
            </button>
          ))}
        </div>
      </div>

      <div className="p-4">
        <h3 className="text-sm font-medium text-gray-700 mb-2">Channels</h3>
        <div className="flex flex-wrap gap-2">
          {availableTags.map((tag) => (
            <button
              key={tag}
              onClick={() => toggleTag(tag)}
              className={`px-3 py-1 rounded-full text-sm transition-colors ${
                selectedTags.includes(tag)
                  ? 'bg-orange-100 text-orange-800'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              {tag}
            </button>
          ))}
        </div>
      </div>

      <div className="p-4">
        <div className="flex items-center gap-2 mb-2">
          <Clock className="w-4 h-4 text-gray-500" />
          <h3 className="text-sm font-medium text-gray-700">Duration</h3>
        </div>
        <div className="space-y-2">
          {DURATION_RANGES.map((range) => (
            <button
              key={range.label}
              onClick={() => setDurationRange([range.min, range.max])}
              className={`w-full text-left px-3 py-2 rounded-lg text-sm transition-colors ${
                durationRange[0] === range.min && durationRange[1] === range.max
                  ? 'bg-orange-100 text-orange-800'
                  : 'hover:bg-gray-100 text-gray-600'
              }`}
            >
              {range.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}