import React, { useState } from 'react';
import { Globe2, BookOpen, Brain, MessageCircle, Clock, ArrowLeft, Play, Lightbulb } from 'lucide-react';
import { Link } from 'react-router-dom';
import { TutorialPopup } from './TutorialPopup';

export function MethodPage() {
  const [showTutorial, setShowTutorial] = useState(false);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-2">
          <div className="flex items-center gap-4 h-14">
            <Link
              to="/"
              className="flex items-center gap-2 text-gray-600 hover:text-gray-900"
            >
              <ArrowLeft className="w-5 h-5" />
              Back to dashboard
            </Link>
            <div className="flex items-center gap-2">
              <Globe2 className="w-8 h-8 text-orange-500" />
              <span className="text-xl font-medium">ComprehensibleGerman</span>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-12">
        <div className="bg-white rounded-lg shadow-sm p-8 md:p-12 prose prose-orange max-w-none">
          <h1 className="flex items-center gap-3 text-3xl font-bold text-gray-900 mb-8">
            <Brain className="w-8 h-8 text-orange-500" />
            The ComprehensibleGerman Method
          </h1>

          {/* Quick Tutorial Section */}
          <div className="bg-purple-50 rounded-lg p-8 mb-12">
            <div className="flex items-start justify-between gap-8">
              <div>
                <h2 className="text-2xl font-bold text-purple-900 flex items-center gap-2 mb-4">
                  <Lightbulb className="w-6 h-6" />
                  Quick Tutorial
                </h2>
                <p className="text-purple-800 mb-6">
                  New to ComprehensibleGerman? Learn how our unique method works in just a few minutes.
                </p>
                <button
                  onClick={() => setShowTutorial(true)}
                  className="inline-flex items-center gap-2 px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
                >
                  <Play className="w-5 h-5" />
                  Start Tutorial
                </button>
              </div>
              <div className="hidden md:block">
                <img
                  src="https://images.unsplash.com/photo-1488190211105-8b0e65b80b4e?w=300&h=200&fit=crop"
                  alt="Learning illustration"
                  className="rounded-lg"
                />
              </div>
            </div>
          </div>

          <section className="mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">The Power of Comprehensible Input</h2>
            <p className="text-gray-600 leading-relaxed">
              Comprehensible input—the natural way we all learned our first language. It's not just about exposure to German, but about understanding what you hear and read. This method, backed by decades of research, shows that we acquire language best when we focus on understanding meaningful messages.
            </p>
          </section>

          <section className="mb-12">
            <h3 className="text-xl font-bold text-gray-900 mb-4">Why Traditional Methods Fall Short</h3>
            <div className="bg-red-50 border border-red-100 rounded-lg p-6 mb-6">
              <p className="text-gray-800">
                Traditional language education often fails because it focuses on memorizing rules and vocabulary lists. Students spend years studying grammar but struggle to have basic conversations. This approach treats language as something to be analyzed rather than acquired naturally through comprehensible input.
              </p>
            </div>
            <p className="text-gray-600 leading-relaxed">
              Research by experts like Dr. Stephen Krashen has shown that explicit grammar study and memorization are far less effective than comprehensible input for achieving real fluency. The key is understanding messages in German, not studying about German.
            </p>
          </section>

          <div className="border-t border-gray-200 my-12"></div>

          <section className="mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-8">The ComprehensibleGerman Approach</h2>
            
            <div className="grid gap-8">
              <div className="bg-orange-50 border border-orange-100 rounded-lg p-6">
                <h3 className="text-xl font-bold text-orange-900 mb-4">Understanding is Everything</h3>
                <p className="text-gray-800">
                  The core of our method is <strong>comprehensible input</strong>—content that you can understand, even if you don't know every word. When you understand the message, your brain naturally acquires the language patterns, just like a child learning their first language.
                </p>
              </div>

              <div className="bg-blue-50 border border-blue-100 rounded-lg p-6">
                <h3 className="text-xl font-bold text-blue-900 mb-4">Natural Acquisition vs. Conscious Learning</h3>
                <p className="text-gray-800 mb-4">
                  Instead of consciously studying grammar rules, you'll develop an intuitive grasp of German through exposure to understandable content. This leads to:
                </p>
                <ul className="list-disc list-inside space-y-2 text-gray-800">
                  <li>Natural, fluent conversations without mental translation</li>
                  <li>Authentic understanding of native speech</li>
                  <li>Effortless reading comprehension</li>
                  <li>Natural writing ability</li>
                </ul>
              </div>
            </div>
          </section>

          <div className="border-t border-gray-200 my-12"></div>

          <section className="mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-8">How to Use ComprehensibleGerman</h2>
            
            <div className="grid gap-8">
              <div>
                <h3 className="text-xl font-bold text-gray-900 mb-4">Making the Most of Our Content</h3>
                <div className="bg-green-50 border border-green-100 rounded-lg p-6">
                  <p className="text-gray-800 mb-4">
                    Simply watching and understanding our videos <strong>is</strong> the method. You don't need to take notes, memorize vocabulary, or do exercises. The magic happens when you focus on understanding the message.
                  </p>
                  <ul className="list-disc list-inside space-y-2 text-gray-800">
                    <li><strong>Focus on the message, not the language.</strong> Enjoy the content without analyzing the grammar.</li>
                    <li><strong>Choose the right level.</strong> You should understand enough to follow along comfortably.</li>
                    <li><strong>Don't worry about perfect understanding.</strong> It's normal and helpful to have some unknown words.</li>
                    <li><strong>Trust the process.</strong> Your brain will naturally acquire the patterns it needs.</li>
                  </ul>
                </div>
              </div>

              <div>
                <h3 className="text-xl font-bold text-gray-900 mb-4">When to Start Speaking</h3>
                <p className="text-gray-600 leading-relaxed">
                  Speaking will develop naturally after you've built a strong foundation through comprehensible input. Forcing early output can lead to fossilized errors and anxiety. Let your speaking ability emerge organically as your understanding grows.
                </p>
              </div>

              <div>
                <h3 className="text-xl font-bold text-gray-900 mb-4">Reading and Writing Development</h3>
                <p className="text-gray-600 leading-relaxed">
                  Once you've developed a solid base through listening and understanding, reading becomes a powerful tool for expanding your German abilities. We recommend starting with simple texts around level 5 or 6.
                </p>
              </div>
            </div>
          </section>

          <div className="border-t border-gray-200 my-12"></div>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-8">Your Path to Fluency</h2>
            <div className="bg-gradient-to-br from-orange-50 to-yellow-50 border border-orange-100 rounded-lg p-6">
              <p className="text-gray-800 mb-4">
                Language acquisition happens gradually through consistent exposure to comprehensible input. That's why we track progress by hours of input rather than test scores or grammar knowledge.
              </p>
              <p className="text-gray-800">
                Success with this method is inevitable—it's how every human has learned their first language. The key is simple: <strong>immerse yourself in comprehensible German content</strong>. The more you understand, the faster you'll progress toward natural fluency.
              </p>
            </div>

            <div className="mt-8 text-center">
              <Link
                to="/"
                className="inline-flex items-center gap-2 px-6 py-3 bg-orange-500 text-white rounded-full hover:bg-orange-600 transition-colors"
              >
                <Clock className="w-5 h-5" />
                Start tracking your progress
              </Link>
            </div>
          </section>
        </div>
      </div>

      <TutorialPopup isOpen={showTutorial} onClose={() => setShowTutorial(false)} />
    </div>
  );
}