import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Video } from '../types';
import { Play, Pause, SkipForward, SkipBack, Shuffle, Volume2, VolumeX, CheckCircle, Clock } from 'lucide-react';
import toast from 'react-hot-toast';
import { LevelIndicator } from './LevelIndicator';
import { CommentSection } from './CommentSection';

export function VideoPlayerPage() {
  const [video, setVideo] = useState<Video | null>(null);
  const [playlist, setPlaylist] = useState<Video[]>([]);
  const [loading, setLoading] = useState(true);
  const [autoplay, setAutoplay] = useState(true);
  const [shuffle, setShuffle] = useState(false);
  const [muted, setMuted] = useState(false);

  useEffect(() => {
    const videoId = new URLSearchParams(window.location.search).get('v');
    if (videoId) {
      fetchVideo(videoId);
      fetchPlaylist(videoId);
    }
  }, []);

  const fetchVideo = async (videoId: string) => {
    try {
      const { data, error } = await supabase
        .from('videos')
        .select(`
          *,
          watched_videos!left(id)
        `)
        .eq('id', videoId)
        .single();

      if (error) throw error;
      setVideo({
        ...data,
        is_watched: data.watched_videos.length > 0
      });
    } catch (error) {
      console.error('Error fetching video:', error);
      toast.error('Failed to load video');
    } finally {
      setLoading(false);
    }
  };

  const fetchPlaylist = async (currentVideoId: string) => {
    try {
      const { data, error } = await supabase
        .from('videos')
        .select(`
          *,
          watched_videos!left(id)
        `)
        .neq('id', currentVideoId)
        .limit(20);

      if (error) throw error;
      
      const playlistWithWatchStatus = (data || []).map(video => ({
        ...video,
        is_watched: video.watched_videos.length > 0
      }));
      
      setPlaylist(playlistWithWatchStatus);
    } catch (error) {
      console.error('Error fetching playlist:', error);
      toast.error('Failed to load playlist');
    }
  };

  const toggleWatchedStatus = async () => {
    if (!video) return;

    try {
      if (video.is_watched) {
        const { error: watchedError } = await supabase
          .from('watched_videos')
          .delete()
          .eq('video_id', video.id);

        if (watchedError) throw watchedError;

        const { error: timeError } = await supabase
          .from('time_entries')
          .delete()
          .match({
            video_id: video.id,
            activity_type: 'watching'
          });

        if (timeError) throw timeError;

        setVideo({ ...video, is_watched: false });
        toast.success('Marked as unwatched');
      } else {
        const { error: watchedError } = await supabase
          .from('watched_videos')
          .insert({ video_id: video.id });

        if (watchedError) throw watchedError;

        const currentDate = new Date().toISOString().split('T')[0];
        const { error: timeError } = await supabase
          .from('time_entries')
          .insert({
            date: currentDate,
            minutes: Math.ceil(video.duration_seconds / 60),
            activity_type: 'watching',
            description: video.title,
            video_id: video.id
          });

        if (timeError) throw timeError;

        setVideo({ ...video, is_watched: true });
        toast.success('Marked as watched');
      }
    } catch (error) {
      console.error('Error toggling watched status:', error);
      toast.error('Failed to update watch status');
    }
  };

  const getYouTubeVideoId = (url: string) => {
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
    const match = url.match(regExp);
    return match && match[2].length === 11 ? match[2] : null;
  };

  const handleVideoEnd = () => {
    if (!autoplay) return;
    
    const nextVideo = shuffle 
      ? playlist[Math.floor(Math.random() * playlist.length)]
      : playlist[0];
      
    if (nextVideo) {
      window.history.pushState({}, '', `?v=${nextVideo.id}`);
      setVideo(nextVideo);
      setPlaylist(prev => prev.filter(v => v.id !== nextVideo.id));
    }
  };

  const playNext = () => {
    const nextVideo = shuffle 
      ? playlist[Math.floor(Math.random() * playlist.length)]
      : playlist[0];
      
    if (nextVideo) {
      window.history.pushState({}, '', `?v=${nextVideo.id}`);
      setVideo(nextVideo);
      setPlaylist(prev => prev.filter(v => v.id !== nextVideo.id));
    } else {
      toast.info('No more videos in playlist');
    }
  };

  const playPrevious = () => {
    toast.info('Previous video feature coming soon');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-500"></div>
      </div>
    );
  }

  if (!video) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-600">Video not found</p>
      </div>
    );
  }

  const youtubeId = getYouTubeVideoId(video.url);
  if (!youtubeId) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-600">Invalid video URL</p>
      </div>
    );
  }

  const formatDuration = (seconds: number): string => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  return (
    <div className="max-w-[1200px] mx-auto px-4">
      <div className="flex flex-col lg:flex-row gap-6">
        {/* Main Content */}
        <div className="lg:w-[70%]">
          {/* Video Player */}
          <div className="relative pb-[56.25%] h-0 bg-black rounded-lg overflow-hidden">
            <iframe
              src={`https://www.youtube.com/embed/${youtubeId}?enablejsapi=1&origin=${window.location.origin}&autoplay=1&mute=${muted ? 1 : 0}`}
              title={video.title}
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
              className="absolute top-0 left-0 w-full h-full"
              onEnded={handleVideoEnd}
            />
          </div>

          {/* Video Controls */}
          <div className="mt-4 bg-white p-4 rounded-lg shadow-sm">
            <div className="flex items-center justify-between flex-wrap gap-4">
              <div className="flex items-center gap-4">
                <button
                  onClick={playPrevious}
                  className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                  title="Previous video"
                >
                  <SkipBack className="w-6 h-6" />
                </button>
                <button
                  onClick={playNext}
                  className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                  title="Next video"
                >
                  <SkipForward className="w-6 h-6" />
                </button>
                <button
                  onClick={() => setMuted(!muted)}
                  className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                  title={muted ? 'Unmute' : 'Mute'}
                >
                  {muted ? <VolumeX className="w-6 h-6" /> : <Volume2 className="w-6 h-6" />}
                </button>
              </div>
              <div className="flex items-center gap-4">
                <button
                  onClick={toggleWatchedStatus}
                  className={`p-2 rounded-full transition-colors ${
                    video.is_watched 
                      ? 'bg-green-500 text-white' 
                      : 'bg-white text-gray-400 hover:text-gray-600'
                  }`}
                  title={video.is_watched ? 'Mark as unwatched' : 'Mark as watched'}
                >
                  <CheckCircle className="w-6 h-6" />
                </button>
                <button
                  onClick={() => setShuffle(!shuffle)}
                  className={`p-2 rounded-full transition-colors ${
                    shuffle ? 'bg-orange-100 text-orange-600' : 'hover:bg-gray-100'
                  }`}
                  title="Shuffle playlist"
                >
                  <Shuffle className="w-6 h-6" />
                </button>
                <button
                  onClick={() => setAutoplay(!autoplay)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-md transition-colors ${
                    autoplay ? 'bg-orange-100 text-orange-600' : 'hover:bg-gray-100'
                  }`}
                >
                  {autoplay ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                  <span className="text-sm font-medium">Autoplay</span>
                </button>
              </div>
            </div>
          </div>

          {/* Video Info */}
          <div className="mt-4 bg-white p-6 rounded-lg shadow-sm">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">{video.title}</h1>
            <div className="flex flex-wrap items-center gap-3 mb-4">
              <LevelIndicator level={video.level} size="lg" />
              <span className="flex items-center gap-1 text-sm text-gray-600">
                <Clock className="w-4 h-4" />
                {formatDuration(video.duration_seconds)}
              </span>
              {video.tags.map((tag) => (
                <span
                  key={tag}
                  className="px-2 py-1 bg-gray-100 text-gray-600 rounded-full text-sm"
                >
                  {tag}
                </span>
              ))}
            </div>
          </div>

          {/* Comments Section */}
          <div className="mt-4">
            <CommentSection videoId={video.id} />
          </div>
        </div>

        {/* Playlist Sidebar */}
        <div className="lg:w-[30%]">
          <div className="bg-white rounded-lg shadow-sm overflow-hidden">
            <div className="p-4 border-b sticky top-0 bg-white z-10">
              <h2 className="text-lg font-semibold">Up Next</h2>
            </div>
            <div className="overflow-y-auto" style={{ maxHeight: 'calc(100vh - 200px)' }}>
              <div className="divide-y">
                {playlist.map((item) => {
                  const thumbId = getYouTubeVideoId(item.url);
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        window.history.pushState({}, '', `?v=${item.id}`);
                        setVideo(item);
                        setPlaylist(prev => [...prev.filter(v => v.id !== item.id), video]);
                      }}
                      className={`w-full flex gap-3 p-3 hover:bg-gray-50 transition-colors ${
                        item.id === video.id ? 'bg-blue-50 border-l-4 border-blue-500' : ''
                      }`}
                    >
                      <div className="relative w-[120px] h-[68px] rounded-md overflow-hidden bg-gray-100 flex-shrink-0">
                        <img
                          src={`https://img.youtube.com/vi/${thumbId}/mqdefault.jpg`}
                          alt=""
                          className="w-full h-full object-cover hover:opacity-80 transition-opacity"
                          loading="lazy"
                        />
                        <div className="absolute bottom-1 right-1 bg-black/75 text-white text-xs px-1 rounded">
                          {formatDuration(item.duration_seconds)}
                        </div>
                        {item.is_watched && (
                          <div className="absolute top-1 right-1 bg-green-500 text-white rounded-full p-1">
                            <CheckCircle className="w-3 h-3" />
                          </div>
                        )}
                      </div>
                      <div className="flex-1 text-left min-w-0">
                        <h3 className={`text-sm line-clamp-2 mb-1 ${
                          item.id === video.id ? 'font-bold' : 'font-medium'
                        }`}>
                          {item.title}
                        </h3>
                        <LevelIndicator level={item.level} size="sm" showLabel={false} />
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}