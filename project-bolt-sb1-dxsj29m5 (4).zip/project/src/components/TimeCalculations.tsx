import React from 'react';
import { TimeEntry, LEVELS } from '../types';

interface TimeCalculationsProps {
  entries: TimeEntry[];
}

export function TimeCalculations({ entries }: TimeCalculationsProps) {
  // Calculate total minutes and hours for each entry
  const entryCalculations = entries.map(entry => ({
    minutes: entry.minutes,
    hours: Number((entry.minutes / 60).toFixed(2))
  }));

  // Calculate level pars in minutes and hours
  const levelPars = LEVELS.map(level => ({
    level: level.number,
    minutes: level.hoursRequired * 60,
    hours: level.hoursRequired
  }));

  return (
    <div className="bg-white p-6 rounded-lg shadow-sm space-y-6">
      <div>
        <h2 className="text-xl font-semibold mb-4">Time Calculations</h2>
        <div className="space-y-2">
          {entryCalculations.map((calc, index) => (
            <div key={index} className="text-gray-700">
              Total time: {calc.minutes} minutes ({calc.hours.toFixed(2)} hours)
            </div>
          ))}
        </div>
      </div>

      <div>
        <h2 className="text-xl font-semibold mb-4">Level Pars</h2>
        <div className="space-y-2">
          {levelPars.map(par => (
            <div key={par.level} className="text-gray-700">
              Level {par.level}: {par.minutes} minutes ({par.hours.toFixed(2)} hours)
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}