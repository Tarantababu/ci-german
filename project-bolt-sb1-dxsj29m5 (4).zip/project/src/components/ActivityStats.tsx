import React from 'react';
import { format, startOfWeek, endOfWeek, eachDayOfInterval, subWeeks } from 'date-fns';
import { Flame, Calendar, BookOpen } from 'lucide-react';

interface TimeEntry {
  date: string;  // Format: 'yyyy-MM-dd'
}

interface ActivityStatsProps {
  entries: TimeEntry[];
}

export function ActivityStats({ entries }: ActivityStatsProps) {
  const calculateCurrentStreak = () => {
    const today = new Date();
    let streak = 0;
    let currentDate = today;
    while (true) {
      const dateStr = format(currentDate, 'yyyy-MM-dd');
      const hasEntry = entries.some(entry => entry.date === dateStr);
      
      if (!hasEntry) break;
      streak++;
      currentDate = new Date(currentDate.setDate(currentDate.getDate() - 1));
    }
    return streak;
  };

  const calculateWeeksInARow = () => {
    const today = new Date();
    let weeks = 0;
    let currentWeekStart = startOfWeek(today);
    while (weeks < 52) {
      const weekDays = eachDayOfInterval({
        start: currentWeekStart,
        end: endOfWeek(currentWeekStart)
      });
      const hasEntryInWeek = weekDays.some(day => 
        entries.some(entry => entry.date === format(day, 'yyyy-MM-dd'))
      );
      if (!hasEntryInWeek) break;
      
      weeks++;
      currentWeekStart = subWeeks(currentWeekStart, 1);
    }
    return weeks;
  };

  const calculateTotalEntries = () => {
    return entries.length;
  };

  const currentStreak = calculateCurrentStreak();
  const weeksInARow = calculateWeeksInARow();
  const totalEntries = calculateTotalEntries();

  return (
    <div className="w-full max-w-3xl mx-auto p-4 bg-gradient-to-br from-slate-50 to-slate-100 rounded-lg">
      <h2 className="text-xl font-semibold mb-4 text-slate-800">Activity Overview</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-lg shadow group hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
          <div className="flex items-center justify-between pb-2">
            <Flame className="text-orange-500" />
            <span className="text-2xl font-bold text-slate-800">{currentStreak}</span>
          </div>
          <p className="text-sm text-slate-600">Current Streak</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow group hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
          <div className="flex items-center justify-between pb-2">
            <Calendar className="text-blue-500" />
            <span className="text-2xl font-bold text-slate-800">{weeksInARow}</span>
          </div>
          <p className="text-sm text-slate-600">Weeks in a Row</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow group hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
          <div className="flex items-center justify-between pb-2">
            <BookOpen className="text-green-500" />
            <span className="text-2xl font-bold text-slate-800">{totalEntries}</span>
          </div>
          <p className="text-sm text-slate-600">Total Entries</p>
        </div>
      </div>
    </div>
  );
}