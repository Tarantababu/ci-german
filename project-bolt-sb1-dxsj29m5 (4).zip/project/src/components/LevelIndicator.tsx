import React from 'react';
import { VideoLevel } from '../types';
import { Star, Sparkles, Zap, Flame } from 'lucide-react';

interface LevelIndicatorProps {
  level: VideoLevel;
  showLabel?: boolean;
  size?: 'sm' | 'md' | 'lg';
}

export function LevelIndicator({ level, showLabel = true, size = 'md' }: LevelIndicatorProps) {
  const getIcon = () => {
    switch (level) {
      case 'superbeginner':
        return <Star className={iconClasses} />;
      case 'beginner':
        return <Sparkles className={iconClasses} />;
      case 'intermediate':
        return <Zap className={iconClasses} />;
      case 'advanced':
        return <Flame className={iconClasses} />;
    }
  };

  const getDescription = () => {
    switch (level) {
      case 'superbeginner':
        return 'Absolute beginners.';
      case 'beginner':
        return 'Basic vocab/grammar.';
      case 'intermediate':
        return 'Natural speech.';
      case 'advanced':
        return 'Native-level.';
    }
  };

  const iconClasses = size === 'sm' ? 'w-4 h-4' : size === 'lg' ? 'w-6 h-6' : 'w-5 h-5';
  const containerClasses = size === 'sm' ? 'text-xs' : size === 'lg' ? 'text-base' : 'text-sm';

  const getColorClasses = () => {
    switch (level) {
      case 'superbeginner':
        return 'bg-green-100 text-green-800 hover:bg-green-200';
      case 'beginner':
        return 'bg-blue-100 text-blue-800 hover:bg-blue-200';
      case 'intermediate':
        return 'bg-yellow-100 text-yellow-800 hover:bg-yellow-200';
      case 'advanced':
        return 'bg-red-100 text-red-800 hover:bg-red-200';
    }
  };

  return (
    <div className="group relative">
      <div
        className={`
          inline-flex items-center gap-1.5 px-2 py-1 rounded-full font-medium
          transition-colors cursor-help ${getColorClasses()} ${containerClasses}
        `}
        aria-label={`${level} level - ${getDescription()}`}
      >
        {getIcon()}
        {showLabel && <span>{level}</span>}
      </div>

      {/* Tooltip */}
      <div className="
        absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-3 py-2
        bg-gray-900 text-white text-sm rounded-lg whitespace-nowrap
        opacity-0 invisible group-hover:opacity-100 group-hover:visible
        transition-all duration-200 z-10 pointer-events-none
        before:content-[''] before:absolute before:top-full before:left-1/2
        before:-translate-x-1/2 before:border-4 before:border-transparent
        before:border-t-gray-900
      ">
        {getDescription()}
      </div>
    </div>
  );
}