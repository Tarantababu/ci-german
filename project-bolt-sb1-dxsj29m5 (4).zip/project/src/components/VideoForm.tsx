import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { VideoLevel } from '../types';
import toast from 'react-hot-toast';

interface VideoFormProps {
  onSubmit: () => void;
  onCancel: () => void;
}

export function VideoForm({ onSubmit, onCancel }: VideoFormProps) {
  const [url, setUrl] = useState('');
  const [title, setTitle] = useState('');
  const [level, setLevel] = useState<VideoLevel>('beginner');
  const [tags, setTags] = useState('');
  const [duration, setDuration] = useState('');
  const [loading, setLoading] = useState(false);

  const parseDuration = (input: string): number => {
    const parts = input.split(':').map(Number);
    if (parts.length === 3) {
      return parts[0] * 3600 + parts[1] * 60 + parts[2];
    }
    if (parts.length === 2) {
      return parts[0] * 60 + parts[1];
    }
    return 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const durationSeconds = parseDuration(duration);
      
      const { error } = await supabase.from('videos').insert({
        url,
        title,
        level,
        tags: tags.split(',').map((tag) => tag.trim()).filter(Boolean),
        duration_seconds: durationSeconds,
      });

      if (error) throw error;

      toast.success('Video added successfully!');
      onSubmit();
    } catch (error) {
      console.error('Error adding video:', error);
      toast.error('Failed to add video');
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-700">
          Video URL
        </label>
        <input
          type="url"
          required
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-orange-500 focus:ring-orange-500"
          placeholder="https://youtube.com/..."
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">
          Title
        </label>
        <input
          type="text"
          required
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-orange-500 focus:ring-orange-500"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">
          Duration (HH:MM:SS)
        </label>
        <input
          type="text"
          required
          value={duration}
          onChange={(e) => setDuration(e.target.value)}
          pattern="^(?:(?:([01]?\d|2[0-3]):)?([0-5]?\d):)?([0-5]?\d)$"
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-orange-500 focus:ring-orange-500"
          placeholder="00:10:00"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">
          Level
        </label>
        <select
          value={level}
          onChange={(e) => setLevel(e.target.value as VideoLevel)}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-orange-500 focus:ring-orange-500"
        >
          <option value="superbeginner">Superbeginner</option>
          <option value="beginner">Beginner</option>
          <option value="intermediate">Intermediate</option>
          <option value="advanced">Advanced</option>
        </select>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">
          Tags (comma-separated)
        </label>
        <input
          type="text"
          required
          value={tags}
          onChange={(e) => setTags(e.target.value)}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-orange-500 focus:ring-orange-500"
          placeholder="grammar, vocabulary, listening"
        />
      </div>

      <div className="flex justify-end gap-4 pt-4">
        <button
          type="button"
          onClick={onCancel}
          className="px-4 py-2 text-sm font-medium text-gray-700 hover:text-gray-500"
          disabled={loading}
        >
          Cancel
        </button>
        <button
          type="submit"
          disabled={loading}
          className="px-4 py-2 text-sm font-medium text-white bg-orange-500 rounded-md hover:bg-orange-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500"
        >
          {loading ? 'Adding...' : 'Add Video'}
        </button>
      </div>
    </form>
  );
}