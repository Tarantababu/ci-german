import React from 'react';
import { Video } from '../types';
import { ExternalLink, CheckCircle, Clock, Eye, AlertCircle, RefreshCw } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAlerts } from '../hooks/useAlerts';
import { LevelIndicator } from './LevelIndicator';

interface VideoGridProps {
  videos: Video[];
  onToggleWatched: (videoId: string, currentStatus: boolean) => void;
  onVideoSelect: (videoId: string) => void;
}

export function VideoGrid({ videos, onToggleWatched, onVideoSelect }: VideoGridProps) {
  const { showSuccess, showError } = useAlerts();

  const getYouTubeVideoId = (url: string): string | null => {
    try {
      const patterns = [
        /(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/i,
        /^[a-zA-Z0-9_-]{11}$/
      ];

      for (const pattern of patterns) {
        const match = url.match(pattern);
        if (match && match[1]) {
          return match[1];
        }
      }
      return null;
    } catch (error) {
      console.error('Error parsing YouTube URL:', error);
      return null;
    }
  };

  const getThumbnailUrls = (videoId: string) => {
    return {
      maxres: `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`,
      high: `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`,
      medium: `https://img.youtube.com/vi/${videoId}/mqdefault.jpg`,
      default: `https://img.youtube.com/vi/${videoId}/default.jpg`
    };
  };

  const handleImageError = (event: React.SyntheticEvent<HTMLImageElement>) => {
    const img = event.currentTarget;
    const videoId = img.dataset.videoId;
    
    if (!videoId) return;

    const urls = getThumbnailUrls(videoId);
    
    if (img.src === urls.maxres) {
      img.src = urls.high;
    } else if (img.src === urls.high) {
      img.src = urls.medium;
    } else if (img.src === urls.medium) {
      img.src = urls.default;
    } else {
      img.onerror = null;
      img.src = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="%23ccc" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"%3E%3Cpath d="M22 12A10 10 0 1 1 12 2a10 10 0 0 1 10 10z"%3E%3C/path%3E%3Cpath d="M12 8v4"%3E%3C/path%3E%3Cpath d="M12 16h.01"%3E%3C/path%3E%3C/svg%3E';
      img.classList.add('object-contain', 'p-4');
    }
  };

  const handleWatchToggle = async (video: Video, currentStatus: boolean) => {
    try {
      if (!currentStatus) {
        const currentDate = new Date().toISOString().split('T')[0];
        const { error: timeError } = await supabase
          .from('time_entries')
          .insert({
            date: currentDate,
            minutes: Math.ceil(video.duration_seconds / 60),
            activity_type: 'watching',
            description: video.title,
            video_id: video.id
          });

        if (timeError) throw timeError;
        await onToggleWatched(video.id, currentStatus);
        showSuccess(`Marked "${video.title}" as watched`);
      } else {
        const { error: deleteError } = await supabase
          .from('time_entries')
          .delete()
          .match({
            video_id: video.id,
            activity_type: 'watching'
          });

        if (deleteError) {
          const { error: updateError } = await supabase
            .from('time_entries')
            .update({ minutes: 0 })
            .match({
              video_id: video.id,
              activity_type: 'watching'
            });

          if (updateError) throw updateError;
        }

        await onToggleWatched(video.id, currentStatus);
        showSuccess(`Marked "${video.title}" as unwatched`);
      }
    } catch (error) {
      console.error('Error updating watch status:', error);
      showError('Failed to update watch status');
    }
  };

  const formatDuration = (seconds: number): string => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const remainingSeconds = seconds % 60;

    if (hours > 0) {
      return `${hours}:${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
    }
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const getDurationCategory = (seconds: number): string => {
    if (seconds < 300) return 'Short';
    if (seconds < 1200) return 'Medium';
    return 'Long';
  };

  if (videos.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500">No videos found</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      {videos.map((video) => {
        const videoId = getYouTubeVideoId(video.url);
        const thumbnailUrls = videoId ? getThumbnailUrls(videoId) : null;
        const durationCategory = getDurationCategory(video.duration_seconds);
        
        return (
          <div
            key={video.id}
            className="group bg-white rounded-lg shadow-sm overflow-hidden hover:shadow-md transition-all duration-300 transform hover:-translate-y-1"
            role="article"
            aria-label={`${video.title} - ${durationCategory} video`}
          >
            <div className="relative">
              <button
                onClick={() => onVideoSelect(video.id)}
                className="block relative group w-full focus:outline-none focus:ring-2 focus:ring-orange-500"
                aria-label={video.is_watched ? `Watch "${video.title}" again` : `Play "${video.title}"`}
              >
                {thumbnailUrls ? (
                  <div className="aspect-w-16 aspect-h-9">
                    <img
                      src={thumbnailUrls.maxres}
                      alt={video.title}
                      data-video-id={videoId}
                      className={`w-full h-full object-cover bg-gray-100 transition-all duration-300 ${
                        video.is_watched ? 'opacity-75 group-hover:opacity-100' : ''
                      }`}
                      onError={handleImageError}
                      loading="lazy"
                    />
                  </div>
                ) : (
                  <div className="aspect-w-16 aspect-h-9 bg-gray-100 flex flex-col items-center justify-center text-gray-400">
                    <AlertCircle className="w-8 h-8 mb-2" />
                    <span className="text-sm">Invalid video URL</span>
                  </div>
                )}

                {video.is_watched && (
                  <div className="absolute inset-0 flex items-center justify-center bg-black/0 group-hover:bg-black/20 transition-all duration-300">
                    <div className="bg-white/90 backdrop-blur-sm px-4 py-2 rounded-full flex items-center gap-2 text-orange-500 transform scale-0 group-hover:scale-100 transition-all duration-300">
                      <RefreshCw className="w-4 h-4" />
                      <span className="text-sm font-medium">Watch Again</span>
                    </div>
                  </div>
                )}
              </button>
              
              <button
                onClick={() => handleWatchToggle(video, video.is_watched || false)}
                className={`absolute top-2 right-2 p-2 rounded-full transition-all duration-300 ${
                  video.is_watched 
                    ? 'bg-green-500 text-white hover:bg-green-600' 
                    : 'bg-white/90 text-gray-400 hover:text-gray-600 hover:bg-white'
                } shadow-sm`}
                title={video.is_watched ? 'Mark as unwatched' : 'Mark as watched'}
                aria-label={video.is_watched ? 'Mark as unwatched' : 'Mark as watched'}
              >
                <CheckCircle className="w-5 h-5" />
              </button>

              <div className="absolute bottom-2 right-2 flex gap-2">
                <span className="bg-black/75 text-white text-xs px-2 py-1 rounded-full flex items-center gap-1 backdrop-blur-sm">
                  <Clock className="w-3 h-3" />
                  {formatDuration(video.duration_seconds)}
                </span>
                <span className="bg-black/75 text-white text-xs px-2 py-1 rounded-full flex items-center gap-1 backdrop-blur-sm">
                  <Eye className="w-3 h-3" />
                  {Math.floor(Math.random() * 1000)} views
                </span>
              </div>
            </div>

            <div className="p-4">
              <h3 className="font-medium text-gray-900 mb-2 line-clamp-2 min-h-[2.5rem]">
                {video.title}
              </h3>
              
              <div className="flex flex-wrap gap-2 mb-3">
                <LevelIndicator level={video.level} size="sm" />
                <span className="px-2 py-1 bg-gray-100 text-gray-600 rounded-full text-xs">
                  {durationCategory}
                </span>
              </div>

              <div className="flex flex-wrap gap-1">
                {video.tags.map((tag) => (
                  <span
                    key={tag}
                    className="px-2 py-1 bg-gray-100 text-gray-600 rounded-full text-xs hover:bg-gray-200 transition-colors"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}