import React, { useState, useEffect, useMemo } from 'react';
import { supabase } from '../lib/supabase';
import { Video, VideoLevel } from '../types';
import { VideoForm } from './VideoForm';
import { VideoGrid } from './VideoGrid';
import { VideoFilters } from './VideoFilters';
import { VideoPlayerPage } from './VideoPlayerPage';
import { Plus, X, ArrowLeft, Filter, Clock, ChevronLeft, ChevronRight, Search, Loader2 } from 'lucide-react';
import { useAlerts } from '../hooks/useAlerts';
import { useRealtimeSubscription } from '../hooks/useRealtimeSubscription';
import { useDebounce } from '../hooks/useDebounce';

const PAGE_SIZE_OPTIONS = [12, 24, 50];
const DEFAULT_PAGE_SIZE = 24; // Changed from 50 for better initial load

export function WatchPage() {
  const { showSuccess, showError } = useAlerts();
  const [videos, setVideos] = useState<Video[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [selectedLevels, setSelectedLevels] = useState<VideoLevel[]>([]);
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [durationRange, setDurationRange] = useState<[number, number]>([0, Infinity]);
  const [hideWatched, setHideWatched] = useState(() => {
    const saved = localStorage.getItem('hideWatched');
    return saved ? JSON.parse(saved) : false;
  });
  const [selectedVideoId, setSelectedVideoId] = useState<string | null>(() => {
    const params = new URLSearchParams(window.location.search);
    return params.get('v');
  });
  const [showFilters, setShowFilters] = useState(true);
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
  const [currentPage, setCurrentPage] = useState(() => {
    const params = new URLSearchParams(window.location.search);
    return parseInt(params.get('page') || '1', 10);
  });
  const [pageSize, setPageSize] = useState(() => {
    const saved = localStorage.getItem('pageSize');
    return saved ? parseInt(saved, 10) : DEFAULT_PAGE_SIZE;
  });
  const [searchQuery, setSearchQuery] = useState('');
  const debouncedSearch = useDebounce(searchQuery, 300);

  // Calculate available tags from all videos
  const availableTags = useMemo(() => {
    const tagSet = new Set<string>();
    videos.forEach(video => {
      video.tags.forEach(tag => tagSet.add(tag));
    });
    return Array.from(tagSet).sort((a, b) => a.localeCompare(b));
  }, [videos]);

  useEffect(() => {
    const handleResize = () => setIsMobile(window.innerWidth < 768);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    localStorage.setItem('pageSize', pageSize.toString());
  }, [pageSize]);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    params.set('page', currentPage.toString());
    window.history.replaceState({}, '', `${window.location.pathname}?${params.toString()}`);
  }, [currentPage]);

const fetchVideos = async () => {
    try {
      setLoading(true);
      let allVideos = [];
      let page = 0;
      const pageSize = 1000; // Supabase's maximum limit
      let hasMore = true;

      while (hasMore) {
        const { data, error, count } = await supabase
          .from('videos')
          .select(`
            *,
            watched_videos!left(id)
          `, { count: 'exact' })
          .order('created_at', { ascending: false })
          .range(page * pageSize, (page + 1) * pageSize - 1);

        if (error) throw error;

        if (!data || data.length === 0) {
          hasMore = false;
        } else {
          const videosWithWatchedStatus = data.map(video => ({
            ...video,
            is_watched: video.watched_videos.length > 0
          }));
          allVideos = [...allVideos, ...videosWithWatchedStatus];
          page++;
          
          // Check if we've received less than pageSize records
          if (data.length < pageSize) {
            hasMore = false;
          }
        }
      }

      setVideos(allVideos);
    } catch (error) {
      console.error('Error fetching videos:', error);
      showError('Failed to load videos');
    } finally {
      setLoading(false);
    }
  };

  useRealtimeSubscription('videos', fetchVideos);
  useRealtimeSubscription('watched_videos', fetchVideos);
  useRealtimeSubscription('time_entries', fetchVideos);

  useEffect(() => {
    fetchVideos();
  }, []);

  const filteredVideos = useMemo(() => {
    return videos.filter((video) => {
      if (hideWatched && video.is_watched) return false;
      
      const levelMatch = selectedLevels.length === 0 || selectedLevels.includes(video.level);
      const tagMatch = selectedTags.length === 0 || selectedTags.some((tag) => video.tags.includes(tag));
      const durationMatch = video.duration_seconds >= durationRange[0] * 60 && 
        (durationRange[1] === Infinity || video.duration_seconds <= durationRange[1] * 60);
      
      // Search functionality
      const searchMatch = !debouncedSearch || 
        video.title.toLowerCase().includes(debouncedSearch.toLowerCase()) ||
        video.tags.some(tag => tag.toLowerCase().includes(debouncedSearch.toLowerCase()));
      
      return levelMatch && tagMatch && durationMatch && searchMatch;
    });
  }, [videos, selectedLevels, selectedTags, durationRange, hideWatched, debouncedSearch]);

  const totalPages = Math.ceil(filteredVideos.length / pageSize);
  const startIndex = (currentPage - 1) * pageSize;
  const endIndex = startIndex + pageSize;
  const currentVideos = filteredVideos.slice(startIndex, endIndex);

  const handlePageChange = (page: number) => {
    if (page < 1 || page > totalPages) return;
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handlePageSizeChange = (size: number) => {
    setPageSize(size);
    setCurrentPage(1);
  };

  const renderPagination = () => {
    const pages = [];
    const maxVisiblePages = 5;
    let startPage = Math.max(1, currentPage - Math.floor(maxVisiblePages / 2));
    let endPage = Math.min(totalPages, startPage + maxVisiblePages - 1);

    if (endPage - startPage + 1 < maxVisiblePages) {
      startPage = Math.max(1, endPage - maxVisiblePages + 1);
    }

    for (let i = startPage; i <= endPage; i++) {
      pages.push(
        <button
          key={i}
          onClick={() => handlePageChange(i)}
          className={`px-3 py-2 rounded-md ${
            currentPage === i
              ? 'bg-orange-500 text-white'
              : 'text-gray-600 hover:bg-gray-100'
          }`}
          aria-current={currentPage === i ? 'page' : undefined}
        >
          {i}
        </button>
      );
    }

    return (
      <div className="flex items-center justify-between mt-6 bg-white p-4 rounded-lg shadow-sm">
        <div className="flex items-center gap-2">
          <label className="text-sm text-gray-600">Show:</label>
          <select
            value={pageSize}
            onChange={(e) => handlePageSizeChange(parseInt(e.target.value, 10))}
            className="px-2 py-1 border rounded-md text-sm"
          >
            {PAGE_SIZE_OPTIONS.map((size) => (
              <option key={size} value={size}>
                {size} per page
              </option>
            ))}
          </select>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => handlePageChange(currentPage - 1)}
            disabled={currentPage === 1}
            className="p-2 rounded-md hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed"
            aria-label="Previous page"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          {pages}
          <button
            onClick={() => handlePageChange(currentPage + 1)}
            disabled={currentPage === totalPages}
            className="p-2 rounded-md hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed"
            aria-label="Next page"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
        <div className="text-sm text-gray-600">
          {filteredVideos.length} videos total
        </div>
      </div>
    );
  };

  if (selectedVideoId) {
    return (
      <div>
        <div className="max-w-[1800px] mx-auto px-4 py-4">
          <button
            onClick={() => {
              setSelectedVideoId(null);
              window.history.pushState({}, '', window.location.pathname);
            }}
            className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-4"
          >
            <ArrowLeft className="w-5 h-5" />
            Back to videos
          </button>
        </div>
        <VideoPlayerPage />
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex flex-col lg:flex-row gap-6">
        {/* Sidebar */}
        <div className={`lg:w-64 ${showFilters ? 'block' : 'hidden'} lg:block`}>
          <VideoFilters
            selectedLevels={selectedLevels}
            setSelectedLevels={setSelectedLevels}
            selectedTags={selectedTags}
            setSelectedTags={setSelectedTags}
            availableTags={availableTags}
            hideWatched={hideWatched}
            setHideWatched={setHideWatched}
            durationRange={durationRange}
            setDurationRange={setDurationRange}
            onClearFilters={() => {
              setSelectedLevels([]);
              setSelectedTags([]);
              setHideWatched(false);
              setDurationRange([0, Infinity]);
              setCurrentPage(1);
              setSearchQuery('');
            }}
          />
        </div>

        {/* Main Content */}
        <div className="flex-1">
          {/* Header */}
          <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <div className="flex items-center gap-4">
                <h1 className="text-2xl font-bold text-gray-900">Watch</h1>
                <button
                  onClick={() => setShowFilters(!showFilters)}
                  className="lg:hidden flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200 transition-colors"
                >
                  <Filter className="w-4 h-4" />
                  Filters {(selectedLevels.length + selectedTags.length + (durationRange[0] !== 0 || durationRange[1] !== Infinity ? 1 : 0)) > 0 && 
                    `(${selectedLevels.length + selectedTags.length + (durationRange[0] !== 0 || durationRange[1] !== Infinity ? 1 : 0)})`}
                </button>
              </div>
              <div className="flex items-center gap-4 w-full sm:w-auto">
                <div className="relative flex-1 sm:flex-none">
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search videos..."
                    className="w-full sm:w-64 pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                  />
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                </div>
                <button
                  onClick={() => setShowForm(true)}
                  className="flex items-center gap-2 px-4 py-2 bg-orange-500 text-white rounded-md hover:bg-orange-600 transition-colors whitespace-nowrap"
                >
                  <Plus className="w-4 h-4" />
                  Add Video
                </button>
              </div>
            </div>

            {/* Stats Bar */}
            <div className="flex flex-wrap items-center gap-4 mt-4 pt-4 border-t">
              <div className="flex items-center gap-2 text-gray-600">
                <Clock className="w-5 h-5" />
                <span className="text-sm font-medium">
                  Total Content: {Math.floor(videos.reduce((sum, video) => sum + video.duration_seconds, 0) / 3600)}h {Math.floor((videos.reduce((sum, video) => sum + video.duration_seconds, 0) % 3600) / 60)}m
                </span>
              </div>
              <div className="text-sm text-gray-600">
                {videos.length} videos • {videos.filter(v => v.is_watched).length} watched
              </div>
            </div>
          </div>

          {/* Active Filters */}
          {(selectedLevels.length > 0 || selectedTags.length > 0 || hideWatched || debouncedSearch || (durationRange[0] !== 0 || durationRange[1] !== Infinity)) && (
            <div className="flex flex-wrap gap-2 mb-6 bg-white p-4 rounded-lg shadow-sm">
              <span className="text-sm text-gray-500">Active filters:</span>
              {debouncedSearch && (
                <span className="inline-flex items-center gap-1 px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm">
                  Search: {debouncedSearch}
                  <button
                    onClick={() => setSearchQuery('')}
                    className="hover:text-blue-600"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </span>
              )}
              {hideWatched && (
                <span className="inline-flex items-center gap-1 px-3 py-1 bg-purple-100 text-purple-800 rounded-full text-sm">
                  Hiding watched videos
                  <button
                    onClick={() => setHideWatched(false)}
                    className="hover:text-purple-600"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </span>
              )}
              {selectedLevels.map((level) => (
                <span
                  key={level}
                  className="inline-flex items-center gap-1 px-3 py-1 bg-orange-100 text-orange-800 rounded-full text-sm"
                >
                  {level}
                  <button
                    onClick={() => setSelectedLevels(selectedLevels.filter((l) => l !== level))}
                    className="hover:text-orange-600"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </span>
              ))}
              {selectedTags.map((tag) => (
                <span
                  key={tag}
                  className="inline-flex items-center gap-1 px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm"
                >
                  {tag}
                  <button
                    onClick={() => setSelectedTags(selectedTags.filter((t) => t !== tag))}
                    className="hover:text-blue-600"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </span>
              ))}
              {(durationRange[0] !== 0 || durationRange[1] !== Infinity) && (
                <span className="inline-flex items-center gap-1 px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm">
                  {durationRange[0] === 0 ? 'Under ' : durationRange[1] === Infinity ? 'Over ' : ''}
                  {durationRange[0] !== 0 ? `${durationRange[0]}-` : ''}
                  {durationRange[1] !== Infinity ? `${durationRange[1]}` : ''}
                  {' minutes'}
                  <button
                    onClick={() => setDurationRange([0, Infinity])}
                    className="hover:text-green-600"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </span>
              )}
            </div>
          )}

          {/* Video Grid */}
          {loading ? (
            <div className="flex flex-col items-center justify-center py-12 text-gray-500">
              <Loader2 className="w-8 h-8 animate-spin mb-4" />
              <p>Loading videos...</p>
            </div>
          ) : currentVideos.length > 0 ? (
            <>
              <VideoGrid 
                videos={currentVideos}
                onToggleWatched={async (videoId, currentStatus) => {
                  try {
                    if (currentStatus) {
                      const { error } = await supabase
                        .from('watched_videos')
                        .delete()
                        .eq('video_id', videoId);

                      if (error) throw error;
                    } else {
                      const { error } = await supabase
                        .from('watched_videos')
                        .insert({ video_id: videoId });

                      if (error) throw error;
                    }

                    await fetchVideos();
                  } catch (error) {
                    showError('Failed to update watched status');
                    console.error('Error toggling watched status:', error);
                  }
                }}
                onVideoSelect={(videoId) => {
                  setSelectedVideoId(videoId);
                  window.history.pushState({}, '', `?v=${videoId}`);
                }}
              />
              {renderPagination()}
            </>
          ) : (
            <div className="text-center py-12 bg-gray-50 rounded-lg">
              <p className="text-gray-600 mb-2">No videos found</p>
              <p className="text-sm text-gray-500">Try adjusting your filters or search query</p>
            </div>
          )}
        </div>
      </div>

      {/* Add Video Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-2xl w-full p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold">Add New Video</h2>
              <button
                onClick={() => setShowForm(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                <X className="w-6 h-6" />
              </button>
            </div>
            <VideoForm
              onSubmit={async () => {
                setShowForm(false);
                await fetchVideos();
              }}
              onCancel={() => setShowForm(false)}
            />
          </div>
        </div>
      )}
    </div>
  );
}