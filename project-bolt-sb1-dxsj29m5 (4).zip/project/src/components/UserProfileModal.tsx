import React from 'react';
import { X, Trophy, Clock, Calendar } from 'lucide-react';

interface UserStats {
  user_id: string;
  current_streak: number;
  longest_streak: number;
  total_minutes: number;
  weekly_minutes: number;
  monthly_minutes: number;
  total_videos_watched: number;
  level: number;
  user_profiles?: {
    display_name: string;
    avatar_url: string;
    username: string;
    created_at?: string;
  };
}

interface UserProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserStats;
}

export function UserProfileModal({ isOpen, onClose, user }: UserProfileModalProps) {
  if (!isOpen) return null;

  const formatMemberSince = () => {
    if (!user.user_profiles?.created_at) {
      return 'Member';
    }
    try {
      return `Member since ${new Date(user.user_profiles.created_at).toLocaleDateString('en-US', { 
        month: 'long',
        day: 'numeric',
        year: 'numeric'
      })}`;
    } catch (error) {
      console.error('Error formatting date:', error);
      return 'Member';
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl max-w-2xl w-full">
        {/* Header */}
        <div className="border-b p-6">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-full bg-orange-100 flex items-center justify-center text-2xl font-bold text-orange-600">
                {user.user_profiles?.username?.[0]?.toUpperCase() || '?'}
              </div>
              <div>
                <h2 className="text-2xl font-bold">
                  {user.user_profiles?.username && `@${user.user_profiles.username}`}
                </h2>
                <p className="text-gray-600">Level {user.level}</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-6">
          <div className="bg-blue-50 rounded-lg p-4 flex flex-col items-center">
            <Trophy className="w-8 h-8 text-blue-600 mb-2" />
            <div className="text-2xl font-bold text-blue-600">{user.current_streak}</div>
            <div className="text-sm text-blue-600">Day Streak</div>
          </div>
          <div className="bg-green-50 rounded-lg p-4 flex flex-col items-center">
            <Clock className="w-8 h-8 text-green-600 mb-2" />
            <div className="text-2xl font-bold text-green-600">{user.total_minutes}</div>
            <div className="text-sm text-green-600">Total Minutes</div>
          </div>
          <div className="bg-purple-50 rounded-lg p-4 flex flex-col items-center">
            <Calendar className="w-8 h-8 text-purple-600 mb-2" />
            <div className="text-2xl font-bold text-purple-600">{user.total_videos_watched}</div>
            <div className="text-sm text-purple-600">Videos Watched</div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-6 border-t bg-gray-50 rounded-b-xl">
          <div className="text-sm text-gray-600">
            {formatMemberSince()}
          </div>
        </div>
      </div>
    </div>
  );
}