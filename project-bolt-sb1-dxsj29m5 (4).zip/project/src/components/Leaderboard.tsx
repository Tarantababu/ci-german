import React, { useState, useEffect } from 'react';
import { Trophy, Clock, Calendar, Flame, Medal, ChevronRight } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useRealtimeSubscription } from '../hooks/useRealtimeSubscription';
import { UserReactions } from './UserReactions';

interface UserStats {
  user_id: string;
  current_streak: number;
  longest_streak: number;
  total_minutes: number;
  weekly_minutes: number;
  monthly_minutes: number;
  total_videos_watched: number;
  level: number;
  user_profiles?: {
    display_name: string;
    avatar_url: string;
    username: string;
  };
  rank?: number;
  reactions?: {
    fire: number;
    thumbsup: number;
    celebrate: number;
  };
  daily_minutes?: number;
}

interface LeaderboardProps {
  currentUserId: string;
  onUserClick?: (user: UserStats) => void;
  filters?: {
    timeframe: 'daily' | 'weekly' | 'monthly' | 'all-time';
    minLevel?: number;
    maxLevel?: number;
  };
}

export function Leaderboard({ currentUserId, onUserClick, filters }: LeaderboardProps) {
  const [users, setUsers] = useState<UserStats[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentUserRank, setCurrentUserRank] = useState<UserStats | null>(null);
  const [expandedUser, setExpandedUser] = useState<string | null>(null);

  const getTimeframeField = (timeframe?: string) => {
    switch (timeframe) {
      case 'weekly':
        return 'weekly_minutes';
      case 'monthly':
        return 'monthly_minutes';
      case 'all-time':
        return 'total_minutes';
      default:
        return 'weekly_minutes';
    }
  };

  const fetchReactions = async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from('user_reactions')
        .select('reaction')
        .eq('target_user_id', userId);

      if (error) throw error;

      return {
        fire: data?.filter(r => r.reaction === 'fire').length || 0,
        thumbsup: data?.filter(r => r.reaction === 'thumbsup').length || 0,
        celebrate: data?.filter(r => r.reaction === 'celebrate').length || 0
      };
    } catch (error) {
      console.error('Error fetching reactions:', error);
      return { fire: 0, thumbsup: 0, celebrate: 0 };
    }
  };

  const fetchLeaderboard = async () => {
    try {
      setLoading(true);
      const timeframeField = getTimeframeField(filters?.timeframe);
      
      // For daily timeframe, calculate from time_entries
      if (filters?.timeframe === 'daily') {
        const today = new Date().toISOString().split('T')[0];
        
        // First get user levels if filters are applied
        let allowedUserIds: string[] | undefined;
        if (filters?.minLevel !== undefined || filters?.maxLevel !== undefined) {
          const { data: userLevels } = await supabase
            .from('user_stats')
            .select('user_id')
            .gte('level', filters.minLevel || 0)
            .lte('level', filters.maxLevel || 999);

          allowedUserIds = userLevels?.map(u => u.user_id);
          
          if (!allowedUserIds?.length) {
            setUsers([]);
            setLoading(false);
            return;
          }
        }

        // Get daily minutes with user profiles
        const query = supabase.rpc('get_daily_leaderboard', {
          p_date: today,
          p_user_ids: allowedUserIds
        });

        const { data: dailyData, error: dailyError } = await query;

        if (dailyError) throw dailyError;

        // Add rank and fetch reactions for each user
        const rankedUsers = await Promise.all((dailyData || []).map(async (user, index) => {
          const reactions = await fetchReactions(user.user_id);
          return {
            ...user,
            rank: index + 1,
            reactions
          };
        }));

        setUsers(rankedUsers);
        
        // Find current user's rank
        const currentUser = rankedUsers.find(user => user.user_id === currentUserId);
        setCurrentUserRank(currentUser || null);
        
        setLoading(false);
        return;
      }

      // For other timeframes, use user_stats table
      let query = supabase
        .from('user_stats')
        .select(`
          *,
          user_profiles (
            display_name,
            avatar_url,
            username
          )
        `)
        .order(timeframeField, { ascending: false });

      // Apply level filters
      if (filters?.minLevel !== undefined) {
        query = query.gte('level', filters.minLevel);
      }
      if (filters?.maxLevel !== undefined) {
        query = query.lte('level', filters.maxLevel);
      }

      const { data, error } = await query.limit(50);

      if (error) throw error;

      // Add rank and fetch reactions for each user
      const rankedUsers = await Promise.all((data || []).map(async (user, index) => {
        const reactions = await fetchReactions(user.user_id);
        return {
          ...user,
          rank: index + 1,
          reactions
        };
      }));

      setUsers(rankedUsers);

      // Find current user's rank
      const currentUser = rankedUsers.find(user => user.user_id === currentUserId);
      setCurrentUserRank(currentUser || null);

    } catch (error) {
      console.error('Error fetching leaderboard:', error);
      setUsers([]);
    } finally {
      setLoading(false);
    }
  };

  // Initial fetch
  useEffect(() => {
    fetchLeaderboard();
  }, [currentUserId, filters]);

  // Subscribe to realtime updates
  useRealtimeSubscription('user_stats', fetchLeaderboard);
  useRealtimeSubscription('user_profiles', fetchLeaderboard);
  useRealtimeSubscription('time_entries', () => {
    if (filters?.timeframe === 'daily') {
      fetchLeaderboard();
    }
  });

  const getRankColor = (rank: number) => {
    if (rank === 1) return 'text-yellow-500';
    if (rank === 2) return 'text-gray-400';
    if (rank === 3) return 'text-amber-600';
    return 'text-gray-600';
  };

  const getStreakColor = (streak: number) => {
    if (streak >= 30) return 'text-red-500';
    if (streak >= 14) return 'text-orange-500';
    if (streak >= 7) return 'text-yellow-500';
    return 'text-gray-400';
  };

  const getUserDisplayName = (user: UserStats) => {
    if (user.user_profiles?.username) {
      return `@${user.user_profiles.username}`;
    }
    if (user.user_profiles?.display_name) {
      return user.user_profiles.display_name;
    }
    return 'Anonymous User';
  };

  const getTimeframeMinutes = (user: UserStats) => {
    switch (filters?.timeframe) {
      case 'daily':
        return user.daily_minutes || 0;
      case 'weekly':
        return user.weekly_minutes;
      case 'monthly':
        return user.monthly_minutes;
      case 'all-time':
        return user.total_minutes;
      default:
        return user.weekly_minutes;
    }
  };

  const toggleExpand = (userId: string) => {
    if (expandedUser === userId) {
      setExpandedUser(null);
    } else {
      setExpandedUser(userId);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {users.map((user) => (
        <div
          key={user.user_id}
          className={`rounded-lg transition-colors ${
            user.user_id === currentUserId
              ? 'bg-orange-50 border border-orange-100'
              : 'hover:bg-gray-50'
          }`}
        >
          {/* Main row - always visible */}
          <div 
            className="flex items-center p-3 md:p-4 gap-2 md:gap-4 cursor-pointer"
            onClick={() => toggleExpand(user.user_id)}
          >
            {/* Rank */}
            <div className={`text-lg md:text-xl font-bold w-6 md:w-8 text-center ${getRankColor(user.rank!)}`}>
              {user.rank === 1 && <Medal className="w-5 h-5 md:w-6 md:h-6 text-yellow-500" />}
              {user.rank === 2 && <Medal className="w-5 h-5 md:w-6 md:h-6 text-gray-400" />}
              {user.rank === 3 && <Medal className="w-5 h-5 md:w-6 md:h-6 text-amber-600" />}
              {user.rank! > 3 && `#${user.rank}`}
            </div>
            
            {/* Avatar */}
            <div className="w-8 h-8 md:w-10 md:h-10 rounded-full bg-gray-200 overflow-hidden flex-shrink-0">
              {user.user_profiles?.avatar_url ? (
                <img
                  src={user.user_profiles.avatar_url}
                  alt=""
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center bg-orange-100 text-orange-500">
                  {user.user_profiles?.username?.[0]?.toUpperCase() || 
                  user.user_profiles?.display_name?.[0]?.toUpperCase() || '?'}
                </div>
              )}
            </div>

            {/* User info */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1 md:gap-2">
                <button 
                  className="font-medium hover:text-orange-500 transition-colors truncate"
                  onClick={(e) => {
                    e.stopPropagation();
                    onUserClick?.(user);
                  }}
                >
                  {getUserDisplayName(user)}
                </button>
                {user.user_id === currentUserId && (
                  <span className="text-xs md:text-sm text-orange-500">(You)</span>
                )}
              </div>
              <div className="text-xs md:text-sm text-gray-500">
                Level {user.level}
              </div>
            </div>

            {/* Most important stat visible on all devices */}
            <div className="flex items-center gap-1 font-medium">
              <Clock className="w-4 h-4 text-blue-500" />
              <span>{Math.round(getTimeframeMinutes(user) / 60)}h</span>
            </div>

            {/* Only visible on medium screens and up */}
            <div className="hidden md:flex items-center gap-6">
              <div className="text-center">
                <div className="text-sm text-gray-500">Streak</div>
                <div className="flex items-center gap-1 font-medium">
                  <Flame className={`w-4 h-4 ${getStreakColor(user.current_streak)}`} />
                  {user.current_streak}
                </div>
              </div>

              <UserReactions
                userId={user.user_id}
                currentUserId={currentUserId}
                reactions={user.reactions || { fire: 0, thumbsup: 0, celebrate: 0 }}
                onReactionChange={fetchLeaderboard}
                size="sm"
              />
            </div>

            {/* Toggle indicator */}
            <ChevronRight 
              className={`w-5 h-5 text-gray-400 transition-transform ${
                expandedUser === user.user_id ? 'rotate-90' : ''
              }`} 
            />
          </div>

          {/* Expanded details - only shown on mobile when expanded */}
          {expandedUser === user.user_id && (
            <div className="px-3 pb-3 pt-1 md:hidden border-t border-gray-100">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <Flame className={`w-4 h-4 ${getStreakColor(user.current_streak)}`} />
                  <span className="text-sm">{user.current_streak} day streak</span>
                </div>
                
                <UserReactions
                  userId={user.user_id}
                  currentUserId={currentUserId}
                  reactions={user.reactions || { fire: 0, thumbsup: 0, celebrate: 0 }}
                  onReactionChange={fetchLeaderboard}
                  size="sm"
                />
              </div>
            </div>
          )}
        </div>
      ))}

      {users.length === 0 && (
        <div className="text-center py-8 md:py-12 text-gray-500">
          No users found matching the current filters
        </div>
      )}
    </div>
  );
}