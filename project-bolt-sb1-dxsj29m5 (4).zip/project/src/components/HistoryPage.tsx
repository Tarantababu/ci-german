import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { format } from 'date-fns';
import { Clock, Film, Headphones, Users, Edit2, Trash2, History as HistoryIcon, AlertTriangle } from 'lucide-react';
import { useAlerts } from '../hooks/useAlerts';
import { DeleteConfirmationModal } from './DeleteConfirmationModal';
import { useRealtimeSubscription } from '../hooks/useRealtimeSubscription';

interface TimeEntry {
  id: string;
  date: string;
  minutes: number;
  activity_type: string;
  description: string;
  created_at: string;
  video_id?: string;
  created_by: string;
  updated_at?: string;
  updated_by?: string;
  last_modified_by_email?: string;
  has_audit_logs: boolean;
}

interface EditModalProps {
  entry: TimeEntry | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: () => void;
}

function EditModal({ entry, isOpen, onClose, onSave }: EditModalProps) {
  const { showSuccess, showError } = useAlerts();
  const [date, setDate] = useState(entry?.date || '');
  const [minutes, setMinutes] = useState(entry?.minutes.toString() || '');
  const [description, setDescription] = useState(entry?.description || '');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (entry) {
      setDate(entry.date);
      setMinutes(entry.minutes.toString());
      setDescription(entry.description || '');
    }
  }, [entry]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!entry) return;
    
    setLoading(true);
    try {
      const { error } = await supabase
        .from('time_entries')
        .update({
          date,
          minutes: parseInt(minutes),
          description
        })
        .eq('id', entry.id);

      if (error) throw error;
      
      showSuccess('Entry updated successfully');
      onSave();
      onClose();
    } catch (error) {
      console.error('Error updating entry:', error);
      showError('Failed to update entry');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg max-w-md w-full p-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold">Edit Entry</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            ×
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">Date</label>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Minutes</label>
            <input
              type="number"
              min="1"
              value={minutes}
              onChange={(e) => setMinutes(e.target.value)}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Description (optional)
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              rows={3}
            />
          </div>

          <div className="flex justify-end gap-4">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-gray-700 hover:text-gray-500"
              disabled={loading}
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              {loading ? 'Saving...' : 'Save'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export function HistoryPage() {
  const { showSuccess, showError } = useAlerts();
  const [entries, setEntries] = useState<TimeEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingEntry, setEditingEntry] = useState<TimeEntry | null>(null);
  const [deletingEntry, setDeletingEntry] = useState<TimeEntry | null>(null);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const pageSize = 50;

  const fetchEntries = async (pageNumber = 1) => {
    try {
      setLoading(true);
      
      // Get current user ID
      const { data: { user }, error: userError } = await supabase.auth.getUser();
      if (userError) throw userError;
      if (!user) throw new Error('Not authenticated');

      const { data, error, count } = await supabase
        .rpc('get_user_history', {
          p_user_id: user.id,
          p_limit: pageSize,
          p_offset: (pageNumber - 1) * pageSize
        });

      if (error) throw error;
      
      setEntries(pageNumber === 1 ? data : [...entries, ...data]);
      setHasMore((count || 0) > pageNumber * pageSize);
      setPage(pageNumber);
    } catch (error) {
      console.error('Error fetching entries:', error);
      showError('Failed to load entries');
    } finally {
      setLoading(false);
    }
  };

  useRealtimeSubscription('time_entries', () => fetchEntries(page));
  useRealtimeSubscription('time_entries_audit_log', () => fetchEntries(page));

  useEffect(() => {
    fetchEntries();
  }, []);

  const handleDelete = async () => {
    if (!deletingEntry) return;
    setDeleteLoading(true);

    try {
      const { error } = await supabase
        .from('time_entries')
        .delete()
        .eq('id', deletingEntry.id);

      if (error) throw error;

      showSuccess('Entry deleted successfully');
      setDeletingEntry(null);
      await fetchEntries(1); // Reset to first page after delete
    } catch (error) {
      console.error('Error deleting entry:', error);
      showError('Failed to delete entry');
    } finally {
      setDeleteLoading(false);
    }
  };

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'watching':
        return <Film className="w-5 h-5 text-blue-500" />;
      case 'listening':
        return <Headphones className="w-5 h-5 text-green-500" />;
      case 'talking':
        return <Users className="w-5 h-5 text-purple-500" />;
      default:
        return <Clock className="w-5 h-5 text-gray-500" />;
    }
  };

  if (loading && entries.length === 0) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-900"></div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-2xl font-bold text-gray-900">History</h1>
        <div className="flex items-center gap-2">
          <HistoryIcon className="w-5 h-5 text-gray-400" />
          <span className="text-sm text-gray-500">
            Showing {entries.length} entries
          </span>
        </div>
      </div>

      {entries.length === 0 ? (
        <div className="text-center py-12 bg-gray-50 rounded-lg">
          <p className="text-gray-600">No entries yet</p>
        </div>
      ) : (
        <div className="space-y-4">
          {entries.map((entry) => (
            <div
              key={entry.id}
              className="bg-white rounded-lg shadow-sm p-4 hover:shadow-md transition-shadow"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-4">
                  <div className="mt-1">{getActivityIcon(entry.activity_type)}</div>
                  <div>
                    <div className="font-medium text-gray-900">
                      {entry.description || entry.activity_type}
                    </div>
                    <div className="text-sm text-gray-500 space-y-1">
                      <div>{format(new Date(entry.date), 'MMMM d, yyyy')}</div>
                      <div>{entry.minutes} minutes</div>
                      {entry.updated_at && (
                        <div className="flex items-center gap-1 text-xs text-gray-400">
                          <AlertTriangle className="w-3 h-3" />
                          Last modified by {entry.last_modified_by_email} on{' '}
                          {format(new Date(entry.updated_at), 'MMM d, yyyy HH:mm')}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setEditingEntry(entry)}
                    className="p-1 text-gray-400 hover:text-gray-600 rounded-full hover:bg-gray-100"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setDeletingEntry(entry)}
                    className="p-1 text-gray-400 hover:text-red-600 rounded-full hover:bg-gray-100"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}

          {hasMore && (
            <div className="flex justify-center pt-4">
              <button
                onClick={() => fetchEntries(page + 1)}
                className="px-4 py-2 text-sm text-gray-600 hover:text-gray-900 border rounded-md hover:bg-gray-50"
              >
                Load More
              </button>
            </div>
          )}
        </div>
      )}

      <EditModal
        entry={editingEntry}
        isOpen={!!editingEntry}
        onClose={() => setEditingEntry(null)}
        onSave={() => fetchEntries(page)}
      />

      <DeleteConfirmationModal
        isOpen={!!deletingEntry}
        onClose={() => setDeletingEntry(null)}
        onConfirm={handleDelete}
        loading={deleteLoading}
      />
    </div>
  );
}