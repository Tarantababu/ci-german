import React, { useState } from 'react';
import { useAlerts } from '../hooks/useAlerts';
import { supabase } from '../lib/supabase';

interface UserReactionsProps {
  userId: string;
  currentUserId: string;
  reactions: {
    fire: number;
    thumbsup: number;
    celebrate: number;
  };
  onReactionChange?: () => void;
  size?: 'sm' | 'md' | 'lg';
}

export function UserReactions({ userId, currentUserId, reactions, onReactionChange, size = 'md' }: UserReactionsProps) {
  const { showSuccess, showError } = useAlerts();
  const [processing, setProcessing] = useState(false);

  const handleReaction = async (type: 'fire' | 'thumbsup' | 'celebrate') => {
    if (processing) return;
    if (userId === currentUserId) {
      showError("You can't react to your own progress!");
      return;
    }

    try {
      setProcessing(true);

      // Check for existing reaction
      const { data: existingReaction, error: checkError } = await supabase
        .from('user_reactions')
        .select('id')
        .eq('user_id', currentUserId)
        .eq('target_user_id', userId)
        .eq('reaction', type)
        .maybeSingle();

      if (checkError) throw checkError;

      if (existingReaction) {
        // Remove reaction
        const { error: deleteError } = await supabase
          .from('user_reactions')
          .delete()
          .eq('id', existingReaction.id);

        if (deleteError) throw deleteError;
        showSuccess('Reaction removed');
      } else {
        // Add reaction
        const { error: insertError } = await supabase
          .from('user_reactions')
          .insert({
            user_id: currentUserId,
            target_user_id: userId,
            reaction: type
          });

        if (insertError) throw insertError;
        showSuccess('Reaction added');
      }

      onReactionChange?.();
    } catch (error) {
      console.error('Error handling reaction:', error);
      showError('Failed to update reaction');
    } finally {
      setProcessing(false);
    }
  };

  const buttonClasses = {
    sm: 'px-2 py-1 text-xs',
    md: 'px-3 py-1.5 text-sm',
    lg: 'px-4 py-2 text-base'
  };

  return (
    <div className="flex items-center gap-2">
      <button
        onClick={() => handleReaction('fire')}
        disabled={processing}
        className={`flex items-center gap-1 bg-orange-100 text-orange-600 rounded-full hover:bg-orange-200 transition-colors ${buttonClasses[size]} ${processing ? 'opacity-50 cursor-not-allowed' : ''}`}
        title="On fire!"
      >
        🔥 {reactions.fire}
      </button>
      <button
        onClick={() => handleReaction('thumbsup')}
        disabled={processing}
        className={`flex items-center gap-1 bg-blue-100 text-blue-600 rounded-full hover:bg-blue-200 transition-colors ${buttonClasses[size]} ${processing ? 'opacity-50 cursor-not-allowed' : ''}`}
        title="Great job!"
      >
        👍 {reactions.thumbsup}
      </button>
      <button
        onClick={() => handleReaction('celebrate')}
        disabled={processing}
        className={`flex items-center gap-1 bg-yellow-100 text-yellow-600 rounded-full hover:bg-yellow-200 transition-colors ${buttonClasses[size]} ${processing ? 'opacity-50 cursor-not-allowed' : ''}`}
        title="Celebrating your progress!"
      >
        🎉 {reactions.celebrate}
      </button>
    </div>
  );
}