import React, { useState, useEffect } from 'react';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay } from 'date-fns';
import { supabase } from '../lib/supabase';
import { VideoTimeEntry, Video } from '../types';
import { Clock, Edit2, Save, X } from 'lucide-react';
import toast from 'react-hot-toast';

interface VideoTimeCalendarProps {
  onDateSelect: (date: Date) => void;
  selectedDate: Date;
}

export function VideoTimeCalendar({ onDateSelect, selectedDate }: VideoTimeCalendarProps) {
  const [timeEntries, setTimeEntries] = useState<VideoTimeEntry[]>([]);
  const [videos, setVideos] = useState<Record<string, Video>>({});
  const [editingEntry, setEditingEntry] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<Partial<VideoTimeEntry>>({});

  useEffect(() => {
    fetchTimeEntries();
    fetchVideos();
  }, []);

  const fetchTimeEntries = async () => {
    const { data, error } = await supabase
      .from('video_time_entries')
      .select('*')
      .order('date', { ascending: false });

    if (error) {
      toast.error('Failed to load time entries');
      return;
    }

    setTimeEntries(data || []);
  };

  const fetchVideos = async () => {
    const { data, error } = await supabase
      .from('videos')
      .select('*');

    if (error) {
      toast.error('Failed to load videos');
      return;
    }

    const videoMap = (data || []).reduce((acc, video) => {
      acc[video.id] = video;
      return acc;
    }, {} as Record<string, Video>);

    setVideos(videoMap);
  };

  const handleEditSave = async () => {
    if (!editingEntry || !editForm) return;

    try {
      const { error } = await supabase
        .from('video_time_entries')
        .update({
          start_time: editForm.start_time,
          end_time: editForm.end_time,
          duration_seconds: editForm.duration_seconds,
          notes: editForm.notes
        })
        .eq('id', editingEntry);

      if (error) throw error;

      toast.success('Time entry updated');
      setEditingEntry(null);
      fetchTimeEntries();
    } catch (error) {
      toast.error('Failed to update time entry');
    }
  };

  const formatDuration = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const remainingSeconds = seconds % 60;

    return `${hours}:${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const getDayEntries = (date: Date) => {
    return timeEntries.filter(entry => 
      isSameDay(new Date(entry.date), date)
    );
  };

  const getTotalDuration = (entries: VideoTimeEntry[]) => {
    return entries.reduce((total, entry) => total + entry.duration_seconds, 0);
  };

  const start = startOfMonth(selectedDate);
  const end = endOfMonth(selectedDate);
  const days = eachDayOfInterval({ start, end });

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-7 gap-1">
        {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
          <div key={day} className="text-center text-sm font-medium text-gray-500 py-2">
            {day}
          </div>
        ))}
        
        {days.map(day => {
          const dayEntries = getDayEntries(day);
          const totalDuration = getTotalDuration(dayEntries);
          const isSelected = isSameDay(day, selectedDate);
          
          return (
            <button
              key={day.toString()}
              onClick={() => onDateSelect(day)}
              className={`
                aspect-square p-2 rounded-lg transition-all
                ${isSelected 
                  ? 'bg-orange-100 ring-2 ring-orange-500' 
                  : totalDuration > 0 
                    ? 'bg-blue-50 hover:bg-blue-100' 
                    : 'hover:bg-gray-50'
                }
              `}
            >
              <div className="flex flex-col h-full">
                <span className={`
                  text-sm font-medium
                  ${isSelected ? 'text-orange-700' : 'text-gray-700'}
                `}>
                  {format(day, 'd')}
                </span>
                {totalDuration > 0 && (
                  <div className="mt-auto">
                    <span className="text-xs font-medium text-blue-600">
                      {formatDuration(totalDuration)}
                    </span>
                  </div>
                )}
              </div>
            </button>
          );
        })}
      </div>

      {/* Selected Day Entries */}
      <div className="space-y-4">
        <h3 className="font-medium text-gray-900">
          {format(selectedDate, 'MMMM d, yyyy')}
        </h3>
        
        {getDayEntries(selectedDate).map(entry => (
          <div 
            key={entry.id}
            className="bg-white rounded-lg shadow-sm p-4"
          >
            {editingEntry === entry.id ? (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Start Time</label>
                    <input
                      type="time"
                      value={editForm.start_time}
                      onChange={e => setEditForm({...editForm, start_time: e.target.value})}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-orange-500 focus:ring-orange-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">End Time</label>
                    <input
                      type="time"
                      value={editForm.end_time}
                      onChange={e => setEditForm({...editForm, end_time: e.target.value})}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-orange-500 focus:ring-orange-500"
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700">Notes</label>
                  <textarea
                    value={editForm.notes || ''}
                    onChange={e => setEditForm({...editForm, notes: e.target.value})}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-orange-500 focus:ring-orange-500"
                    rows={2}
                  />
                </div>

                <div className="flex justify-end gap-2">
                  <button
                    onClick={() => setEditingEntry(null)}
                    className="px-3 py-2 text-sm text-gray-600 hover:text-gray-800"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleEditSave}
                    className="px-3 py-2 text-sm bg-orange-500 text-white rounded-md hover:bg-orange-600"
                  >
                    Save Changes
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex items-start justify-between">
                <div>
                  <h4 className="font-medium text-gray-900">
                    {videos[entry.video_id]?.title}
                  </h4>
                  <div className="mt-1 text-sm text-gray-500">
                    {entry.start_time} - {entry.end_time}
                  </div>
                  {entry.notes && (
                    <p className="mt-2 text-sm text-gray-600">{entry.notes}</p>
                  )}
                </div>
                <button
                  onClick={() => {
                    setEditingEntry(entry.id);
                    setEditForm(entry);
                  }}
                  className="p-1 text-gray-400 hover:text-gray-600"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}