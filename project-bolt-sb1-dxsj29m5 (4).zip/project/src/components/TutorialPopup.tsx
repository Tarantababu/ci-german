import React, { useState } from 'react';
import { X, ChevronLeft, ChevronRight, Lightbulb, Play, Brain, Target, Coffee, Rocket } from 'lucide-react';

interface TutorialStep {
  title: string;
  description: string;
  icon: React.ReactNode;
  visualElement: string;
}

interface TutorialPopupProps {
  isOpen: boolean;
  onClose: () => void;
}

export function TutorialPopup({ isOpen, onClose }: TutorialPopupProps) {
  const [currentStep, setCurrentStep] = useState(0);

  const steps: TutorialStep[] = [
    {
      title: "Dreaming German is not like other apps",
      description: "We use a very different method than what you may be used to. This introduction will teach you how to make the most of it.",
      icon: <Lightbulb className="w-12 h-12 text-orange-500" />,
      visualElement: "https://www.dreamingspanish.com/assets/images/icons/onboarding-1.svg"
    },
    {
      title: "Just watch",
      description: "Here, you'll learn everything by watching videos. Including vocabulary, grammar, and pronunciation. No need for dictionaries, practice or exercises!",
      icon: <Play className="w-12 h-12 text-orange-500" />,
      visualElement: "https://www.dreamingspanish.com/assets/images/icons/onboarding-2.svg"
    },
    {
      title: "You won't understand every word",
      description: "When watching a video, don't worry if you don't understand some words. Understanding the overall story is enough.",
      icon: <Brain className="w-12 h-12 text-orange-500" />,
      visualElement: "https://www.dreamingspanish.com/assets/images/icons/onboarding-3.svg"
    },
    {
      title: "Don't overthink it",
      description: "Don't try to memorize words or to think about why things are said in a certain way. Your brain is already learning everything little by little.",
      icon: <Target className="w-12 h-12 text-orange-500" />,
      visualElement: "https://www.dreamingspanish.com/assets/images/icons/onboarding-4.svg"
    },
    {
      title: "Be lazy",
      description: 'Watch videos about topics you really enjoy. Videos that feel "too easy" will lead to faster progress than videos that are too hard.',
      icon: <Coffee className="w-12 h-12 text-orange-500" />,
      visualElement: "https://www.dreamingspanish.com/assets/images/icons/onboarding-5.svg"
    },
    {
      title: "It really does work",
      description: "To learn why this is such a solid approach, you can read more about our method and its foundations in our detailed explanation. Or just start acquiring German right now!",
      icon: <Rocket className="w-12 h-12 text-orange-500" />,
      visualElement: "https://www.dreamingspanish.com/assets/images/icons/onboarding-6.svg"
    },
    {
      title: "Find this tutorial again",
      description: "If you want to watch this tutorial again, you can find it in: Learn about our method > Quick Tutorial",
      icon: <Target className="w-12 h-12 text-orange-500" />,
      visualElement: "https://www.dreamingspanish.com/assets/images/icons/onboarding-7.svg"
    }
  ];

  if (!isOpen) return null;

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      onClose();
    }
  };

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl max-w-2xl w-full overflow-hidden">
        {/* Header */}
        <div className="bg-purple-600 p-8 relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-white/80 hover:text-white transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
          <div className="flex justify-center items-center h-32">
            <img 
              src={steps[currentStep].visualElement} 
              alt=""
              className="w-32 h-32 object-contain"
            />
          </div>
        </div>

        {/* Content */}
        <div className="p-8 text-center">
          <h2 className="text-3xl font-bold mb-4">
            {steps[currentStep].title}
          </h2>
          <p className="text-gray-600 text-lg leading-relaxed max-w-lg mx-auto">
            {steps[currentStep].description}
          </p>

          {/* Progress dots */}
          <div className="flex justify-center gap-2 mt-8 mb-6">
            {steps.map((_, index) => (
              <div
                key={index}
                className={`w-2 h-2 rounded-full transition-colors ${
                  index === currentStep ? 'bg-purple-600' : 'bg-gray-200'
                }`}
              />
            ))}
          </div>

          {/* Navigation */}
          <div className="flex justify-between items-center">
            <button
              onClick={handlePrevious}
              className={`flex items-center gap-2 px-4 py-2 text-gray-600 transition-colors ${
                currentStep === 0 ? 'invisible' : 'hover:text-gray-900'
              }`}
            >
              <ChevronLeft className="w-5 h-5" />
              Previous
            </button>
            <button
              onClick={handleNext}
              className="flex items-center gap-2 px-4 py-2 text-orange-500 font-medium hover:text-orange-600 transition-colors"
            >
              {currentStep === steps.length - 1 ? 'Done' : 'Next'}
              {currentStep < steps.length - 1 && <ChevronRight className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}