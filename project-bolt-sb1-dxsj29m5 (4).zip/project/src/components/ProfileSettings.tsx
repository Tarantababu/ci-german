import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Check, X, Loader2 } from 'lucide-react';
import { useAlerts } from '../hooks/useAlerts';

interface ProfileSettingsProps {
  isOpen: boolean;
  onClose: () => void;
}

export function ProfileSettings({ isOpen, onClose }: ProfileSettingsProps) {
  const { showSuccess, showError } = useAlerts();
  const [username, setUsername] = useState('');
  const [originalUsername, setOriginalUsername] = useState('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isValid, setIsValid] = useState(false);
  const [isAvailable, setIsAvailable] = useState(false);
  const [debounceTimeout, setDebounceTimeout] = useState<NodeJS.Timeout | null>(null);

  useEffect(() => {
    fetchProfile();
  }, []);

  const fetchProfile = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('No user found');

      const { data, error } = await supabase
        .from('user_profiles')
        .select('username')
        .eq('id', user.id)
        .single();

      if (error) throw error;

      if (data?.username) {
        setUsername(data.username);
        setOriginalUsername(data.username);
      }
    } catch (error) {
      console.error('Error fetching profile:', error);
      showError('Failed to load profile');
    } finally {
      setLoading(false);
    }
  };

  const validateUsername = (value: string) => {
    // Reset states
    setError(null);
    setIsValid(false);
    setIsAvailable(false);

    // Check length
    if (value.length < 3 || value.length > 20) {
      setError('Username must be between 3 and 20 characters');
      return false;
    }

    // Check format (alphanumeric and underscore only)
    if (!/^[a-zA-Z0-9_]+$/.test(value)) {
      setError('Username can only contain letters, numbers, and underscores');
      return false;
    }

    return true;
  };

  const checkAvailability = async (value: string) => {
    if (!validateUsername(value)) return;

    try {
      const { data, error } = await supabase
        .from('user_profiles')
        .select('username')
        .ilike('username', value)
        .neq('username', originalUsername)
        .maybeSingle();

      if (error) throw error;

      setIsAvailable(!data);
      setIsValid(!data);
      if (data) {
        setError('Username is already taken');
      }
    } catch (error) {
      console.error('Error checking username:', error);
      setError('Failed to check username availability');
    }
  };

  const handleUsernameChange = (value: string) => {
    setUsername(value);
    
    // Clear any existing timeout
    if (debounceTimeout) {
      clearTimeout(debounceTimeout);
    }

    // Set new timeout
    const timeout = setTimeout(() => {
      checkAvailability(value);
    }, 500);

    setDebounceTimeout(timeout);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isValid || saving) return;

    setSaving(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('No user found');

      const { error } = await supabase
        .from('user_profiles')
        .update({ username })
        .eq('id', user.id);

      if (error) throw error;

      showSuccess('Username updated successfully');
      setOriginalUsername(username);
      onClose();
    } catch (error) {
      console.error('Error updating username:', error);
      showError('Failed to update username');
    } finally {
      setSaving(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-md w-full p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-semibold">Profile Settings</h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-500"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="w-8 h-8 text-orange-500 animate-spin" />
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Username
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={username}
                  onChange={(e) => handleUsernameChange(e.target.value)}
                  className={`
                    w-full px-4 py-2 border rounded-md
                    ${error ? 'border-red-300' : isValid ? 'border-green-300' : 'border-gray-300'}
                    focus:outline-none focus:ring-2
                    ${error ? 'focus:ring-red-200' : isValid ? 'focus:ring-green-200' : 'focus:ring-orange-200'}
                  `}
                  placeholder="Choose a username"
                />
                {username && (
                  <div className="absolute right-2 top-2">
                    {error ? (
                      <X className="w-5 h-5 text-red-500" />
                    ) : isValid ? (
                      <Check className="w-5 h-5 text-green-500" />
                    ) : (
                      <Loader2 className="w-5 h-5 text-gray-400 animate-spin" />
                    )}
                  </div>
                )}
              </div>
              {error && (
                <p className="mt-1 text-sm text-red-600">{error}</p>
              )}
              <p className="mt-1 text-sm text-gray-500">
                Username must be between 3 and 20 characters and can only contain letters, numbers, and underscores.
              </p>
            </div>

            <div className="flex justify-end gap-3 pt-4">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-gray-700 hover:text-gray-500 font-medium"
                disabled={saving}
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={!isValid || saving}
                className="px-4 py-2 bg-orange-500 text-white rounded-md hover:bg-orange-600 font-medium disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
              >
                {saving ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Saving...
                  </>
                ) : (
                  'Save Changes'
                )}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}