import React, { useState } from 'react';
import { Share2, Mail, Copy, Facebook, Twitter, Linkedin, MessageCircle, Check, X, Trophy } from 'lucide-react';
import { useAlerts } from '../hooks/useAlerts';

interface ShareProgressProps {
  username: string;
  stats: {
    level: number;
    totalMinutes: number;
    streak: number;
    videosWatched: number;
  };
  achievements: {
    type: string;
    tier: 'bronze' | 'silver' | 'gold';
    earnedAt: string;
  }[];
}

export function ShareProgress({ username, stats, achievements }: ShareProgressProps) {
  const { showSuccess, showError } = useAlerts();
  const [isOpen, setIsOpen] = useState(false);
  const [message, setMessage] = useState('');
  const [copied, setCopied] = useState(false);

  const baseUrl = 'https://comprehensiblegerman.org';
  const shareUrl = `${baseUrl}?ref=${encodeURIComponent(username)}`;
  
  const shareText = `Check out my German learning progress on ComprehensibleGerman!\n\n` +
    `🎯 Level ${stats.level}\n` +
    `⏱️ ${Math.floor(stats.totalMinutes / 60)} hours of practice\n` +
    `🔥 ${stats.streak} day streak\n` +
    `📺 ${stats.videosWatched} videos watched\n\n` +
    (message ? `${message}\n\n` : '') +
    `Join me in learning German naturally!`;

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(`${shareText}\n${shareUrl}`);
      setCopied(true);
      showSuccess('Link copied to clipboard!');
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      showError('Failed to copy link');
    }
  };

  const handleEmailShare = () => {
    const subject = 'Join me on ComprehensibleGerman!';
    const body = encodeURIComponent(`${shareText}\n\n${shareUrl}`);
    window.open(`mailto:?subject=${encodeURIComponent(subject)}&body=${body}`);
  };

  const handleSocialShare = (platform: string) => {
    const text = encodeURIComponent(shareText);
    const url = encodeURIComponent(shareUrl);

    const shareUrls = {
      facebook: `https://www.facebook.com/sharer/sharer.php?u=${url}`,
      twitter: `https://twitter.com/intent/tweet?text=${text}&url=${url}`,
      linkedin: `https://www.linkedin.com/sharing/share-offsite/?url=${url}`,
      whatsapp: `https://wa.me/?text=${text}%20${url}`
    };

    window.open(shareUrls[platform], '_blank', 'width=600,height=400');
  };

  return (
    <>
      <button
        onClick={() => setIsOpen(true)}
        className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-orange-500 to-orange-600 text-white rounded-lg hover:from-orange-600 hover:to-orange-700 transition-all duration-300 shadow-sm hover:shadow-md"
      >
        <Share2 className="w-4 h-4" />
        Share Progress
      </button>

      {isOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50 backdrop-blur-sm">
          <div className="bg-white rounded-2xl max-w-lg w-full shadow-xl">
            {/* Header */}
            <div className="flex items-center justify-between p-6">
              <h2 className="text-2xl font-bold bg-gradient-to-r from-orange-500 to-orange-600 text-transparent bg-clip-text">Share Your Progress</h2>
              <button
                onClick={() => setIsOpen(false)}
                className="text-gray-400 hover:text-gray-600 transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Preview Card */}
            <div className="px-6 pb-6">
              <div className="bg-gradient-to-br from-orange-50 to-orange-100/50 rounded-xl p-6 mb-6">
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-16 h-16 bg-gradient-to-br from-orange-500 to-orange-600 rounded-2xl flex items-center justify-center text-2xl font-bold text-white shadow-lg">
                    {username[0].toUpperCase()}
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900">@{username}</h3>
                    <div className="flex items-center gap-2 text-orange-600">
                      <Trophy className="w-4 h-4" />
                      <span className="font-medium">Level {stats.level}</span>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div className="bg-white rounded-xl p-4 shadow-sm">
                    <div className="text-2xl font-bold text-orange-500 mb-1">
                      {Math.floor(stats.totalMinutes / 60)}h
                    </div>
                    <div className="text-sm text-gray-600">Total Practice</div>
                  </div>
                  <div className="bg-white rounded-xl p-4 shadow-sm">
                    <div className="text-2xl font-bold text-orange-500 mb-1">
                      {stats.streak}
                    </div>
                    <div className="text-sm text-gray-600">Day Streak</div>
                  </div>
                </div>

                <div className="relative">
                  <textarea
                    value={message}
                    onChange={(e) => setMessage(e.target.value.slice(0, 150))}
                    placeholder="Add a personal message (optional)"
                    className="w-full p-4 border border-orange-100 rounded-xl resize-none bg-white/80 backdrop-blur-sm focus:outline-none focus:ring-2 focus:ring-orange-500/20 transition-all"
                    rows={2}
                    maxLength={150}
                  />
                  <div className="absolute bottom-2 right-2 text-sm text-orange-500/70">
                    {message.length}/150
                  </div>
                </div>
              </div>

              {/* Share Options */}
              <div className="grid grid-cols-2 gap-4">
                <button
                  onClick={handleEmailShare}
                  className="flex items-center justify-center gap-3 p-4 rounded-xl border border-gray-200 hover:bg-gray-50 transition-colors"
                >
                  <Mail className="w-5 h-5 text-gray-600" />
                  <span className="font-medium text-gray-700">Email</span>
                </button>
                <button
                  onClick={() => handleSocialShare('facebook')}
                  className="flex items-center justify-center gap-3 p-4 rounded-xl border border-gray-200 hover:bg-gray-50 transition-colors"
                >
                  <Facebook className="w-5 h-5 text-blue-600" />
                  <span className="font-medium text-gray-700">Facebook</span>
                </button>
                <button
                  onClick={() => handleSocialShare('twitter')}
                  className="flex items-center justify-center gap-3 p-4 rounded-xl border border-gray-200 hover:bg-gray-50 transition-colors"
                >
                  <Twitter className="w-5 h-5 text-blue-400" />
                  <span className="font-medium text-gray-700">Twitter</span>
                </button>
                <button
                  onClick={() => handleSocialShare('linkedin')}
                  className="flex items-center justify-center gap-3 p-4 rounded-xl border border-gray-200 hover:bg-gray-50 transition-colors"
                >
                  <Linkedin className="w-5 h-5 text-blue-700" />
                  <span className="font-medium text-gray-700">LinkedIn</span>
                </button>
                <button
                  onClick={() => handleSocialShare('whatsapp')}
                  className="flex items-center justify-center gap-3 p-4 rounded-xl border border-gray-200 hover:bg-gray-50 transition-colors"
                >
                  <MessageCircle className="w-5 h-5 text-green-500" />
                  <span className="font-medium text-gray-700">WhatsApp</span>
                </button>
                <button
                  onClick={handleCopyLink}
                  className="flex items-center justify-center gap-3 p-4 rounded-xl border border-gray-200 hover:bg-gray-50 transition-colors group"
                >
                  {copied ? (
                    <Check className="w-5 h-5 text-green-500" />
                  ) : (
                    <Copy className="w-5 h-5 text-gray-600 group-hover:text-gray-800" />
                  )}
                  <span className="font-medium text-gray-700">
                    {copied ? 'Copied!' : 'Copy Link'}
                  </span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}