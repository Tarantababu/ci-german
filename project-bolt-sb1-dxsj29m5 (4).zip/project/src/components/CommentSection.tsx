import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { formatTimeAgo } from '../lib/utils';
import { MessageSquare, ThumbsUp, ThumbsDown, Reply, MoreVertical, X } from 'lucide-react';
import { useAlerts } from '../hooks/useAlerts';
import { useRealtimeSubscription } from '../hooks/useRealtimeSubscription';

interface Comment {
  id: string;
  content: string;
  created_at: string;
  user_data: {
    email: string;
  };
  likes: number;
  dislikes: number;
  parent_id: string | null;
  user_id: string;
  user_like?: {
    is_like: boolean;
  }[];
}

interface CommentSectionProps {
  videoId: string;
}

export function CommentSection({ videoId }: CommentSectionProps) {
  const { showSuccess, showError } = useAlerts();
  const [comments, setComments] = useState<Comment[]>([]);
  const [newComment, setNewComment] = useState('');
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [replyTo, setReplyTo] = useState<Comment | null>(null);

  const fetchComments = async () => {
    try {
      const { data, error } = await supabase
        .from('video_comments')
        .select(`
          *,
          user_like:comment_likes(is_like)
        `)
        .eq('video_id', videoId)
        .eq('status', 'active')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setComments(data || []);
    } catch (error) {
      console.error('Error fetching comments:', error);
      showError('Failed to load comments');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchComments();
  }, [videoId]);

  useRealtimeSubscription('video_comments', fetchComments);
  useRealtimeSubscription('comment_likes', fetchComments);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim()) return;

    setSubmitting(true);
    try {
      const { error } = await supabase
        .from('video_comments')
        .insert({
          video_id: videoId,
          content: newComment.trim(),
          parent_id: replyTo?.id || null
        });

      if (error) throw error;

      setNewComment('');
      setReplyTo(null);
      showSuccess(replyTo ? 'Reply posted successfully' : 'Comment posted successfully');
      await fetchComments();
    } catch (error) {
      console.error('Error posting comment:', error);
      showError('Failed to post comment');
    } finally {
      setSubmitting(false);
    }
  };

  const handleLike = async (comment: Comment, isLike: boolean) => {
    try {
      const userLike = comment.user_like?.[0];
      
      if (userLike) {
        if (userLike.is_like === isLike) {
          // Remove like/dislike
          const { error } = await supabase
            .from('comment_likes')
            .delete()
            .eq('comment_id', comment.id)
            .eq('user_id', comment.user_id);

          if (error) throw error;
        } else {
          // Update like/dislike
          const { error } = await supabase
            .from('comment_likes')
            .update({ is_like: isLike })
            .eq('comment_id', comment.id)
            .eq('user_id', comment.user_id);

          if (error) throw error;
        }
      } else {
        // Add new like/dislike
        const { error } = await supabase
          .from('comment_likes')
          .insert({
            comment_id: comment.id,
            is_like: isLike
          });

        if (error) throw error;
      }

      await fetchComments();
    } catch (error) {
      console.error('Error updating like:', error);
      showError('Failed to update like');
    }
  };

  const getReplies = (parentId: string) => {
    return comments.filter(comment => comment.parent_id === parentId);
  };

  const renderComment = (comment: Comment, isReply = false) => {
    const replies = getReplies(comment.id);
    const userLike = comment.user_like?.[0];

    return (
      <div key={comment.id} className={`flex gap-4 ${isReply ? 'ml-12 mt-4' : ''}`}>
        <div className="w-10 h-10 rounded-full bg-orange-100 flex items-center justify-center flex-shrink-0">
          <span className="text-orange-600 font-medium">
            {comment.user_data.email[0].toUpperCase()}
          </span>
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <span className="font-medium text-gray-900">
              {comment.user_data.email.split('@')[0]}
            </span>
            <span className="text-sm text-gray-500">
              {formatTimeAgo(comment.created_at)}
            </span>
          </div>
          <p className="text-gray-800 whitespace-pre-wrap break-words">
            {comment.content}
          </p>
          <div className="flex items-center gap-4 mt-2">
            <button 
              onClick={() => handleLike(comment, true)}
              className={`flex items-center gap-1 ${
                userLike?.is_like ? 'text-orange-500' : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              <ThumbsUp className="w-4 h-4" />
              <span className="text-sm">{comment.likes}</span>
            </button>
            <button 
              onClick={() => handleLike(comment, false)}
              className={`flex items-center gap-1 ${
                userLike?.is_like === false ? 'text-orange-500' : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              <ThumbsDown className="w-4 h-4" />
              <span className="text-sm">{comment.dislikes}</span>
            </button>
            <button 
              onClick={() => setReplyTo(comment)}
              className="flex items-center gap-1 text-gray-500 hover:text-gray-700"
            >
              <Reply className="w-4 h-4" />
              <span className="text-sm">Reply</span>
            </button>
            <button className="ml-auto text-gray-500 hover:text-gray-700">
              <MoreVertical className="w-4 h-4" />
            </button>
          </div>

          {/* Nested Replies */}
          {replies.length > 0 && (
            <div className="mt-4 space-y-4">
              {replies.map(reply => renderComment(reply, true))}
            </div>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center gap-2 mb-6">
        <MessageSquare className="w-5 h-5 text-gray-600" />
        <h2 className="text-lg font-semibold">Comments</h2>
        <span className="text-sm text-gray-500">({comments.length})</span>
      </div>

      {/* Comment Form */}
      <form onSubmit={handleSubmit} className="mb-8">
        {replyTo && (
          <div className="mb-4 p-3 bg-gray-50 rounded-lg flex items-center justify-between">
            <span className="text-sm text-gray-600">
              Replying to {replyTo.user_data.email.split('@')[0]}
            </span>
            <button
              type="button"
              onClick={() => setReplyTo(null)}
              className="text-gray-500 hover:text-gray-700"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}
        <div className="mb-4">
          <textarea
            value={newComment}
            onChange={(e) => setNewComment(e.target.value)}
            placeholder={replyTo ? 'Write a reply...' : 'Add a comment...'}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 resize-none"
            rows={3}
            maxLength={1000}
            disabled={submitting}
          />
          <div className="flex justify-between items-center mt-2">
            <span className="text-sm text-gray-500">
              {newComment.length}/1000 characters
            </span>
            <div className="flex gap-2">
              {replyTo && (
                <button
                  type="button"
                  onClick={() => setReplyTo(null)}
                  className="px-4 py-2 text-gray-600 hover:text-gray-800"
                >
                  Cancel
                </button>
              )}
              <button
                type="submit"
                disabled={!newComment.trim() || submitting}
                className="px-4 py-2 bg-orange-500 text-white rounded-md hover:bg-orange-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                {submitting ? 'Posting...' : replyTo ? 'Post Reply' : 'Post Comment'}
              </button>
            </div>
          </div>
        </div>
      </form>

      {/* Comments List */}
      {loading ? (
        <div className="flex justify-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-orange-500" />
        </div>
      ) : comments.length > 0 ? (
        <div className="space-y-6">
          {comments
            .filter(comment => !comment.parent_id)
            .map(comment => renderComment(comment))}
        </div>
      ) : (
        <div className="text-center py-8 text-gray-500">
          No comments yet. Be the first to comment!
        </div>
      )}
    </div>
  );
}