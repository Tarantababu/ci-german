import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Gift, Clock, Trophy, Star, Users, Target, Award, ArrowRight } from 'lucide-react';
import { format, startOfWeek, endOfWeek, differenceInDays } from 'date-fns';
import { useRealtimeSubscription } from '../hooks/useRealtimeSubscription';

interface WeeklyChallengeProps {
  currentUserId: string;
}

interface WeeklyStats {
  user_id: string;
  weekly_minutes: number;
  user_profiles?: {
    username: string;
    avatar_url: string;
  };
}

interface WeeklyChallenge {
  id: string;
  start_date: string;
  end_date: string;
  target_hours: number;
}

interface ChallengeCompletion {
  id: string;
  challenge_id: string;
  user_id: string;
  completed_at: string;
}

interface TimeEntry {
  minutes: number;
  date: string;
}

export function WeeklyChallenge({ currentUserId }: WeeklyChallengeProps) {
  const [loading, setLoading] = useState(true);
  const [topUsers, setTopUsers] = useState<WeeklyStats[]>([]);
  const [currentUserStats, setCurrentUserStats] = useState<WeeklyStats | null>(null);
  const [challenge, setChallenge] = useState<WeeklyChallenge | null>(null);
  const [completion, setCompletion] = useState<ChallengeCompletion | null>(null);
  const [weekStart] = useState(() => startOfWeek(new Date(), { weekStartsOn: 1 })); // Monday
  const [weekEnd] = useState(() => endOfWeek(new Date(), { weekStartsOn: 1 }));
  const [consecutiveCompletions, setConsecutiveCompletions] = useState(0);
  const [weeklyTimeEntries, setWeeklyTimeEntries] = useState<TimeEntry[]>([]);

  useEffect(() => {
    fetchWeeklyData();
    fetchConsecutiveCompletions();
    fetchWeeklyTimeEntries();
  }, [currentUserId]);

  useRealtimeSubscription('weekly_challenge_completions', fetchWeeklyData);
  useRealtimeSubscription('time_entries', () => {
    fetchWeeklyTimeEntries();
    checkAndUpdateCompletion();
  });

  async function fetchWeeklyTimeEntries() {
    try {
      const monday = format(weekStart, 'yyyy-MM-dd');
      const sunday = format(weekEnd, 'yyyy-MM-dd');

      const { data, error } = await supabase
        .from('time_entries')
        .select('minutes, date')
        .eq('user_id', currentUserId)
        .gte('date', monday)
        .lte('date', sunday)
        .order('date', { ascending: true });

      if (error) throw error;
      setWeeklyTimeEntries(data || []);
    } catch (error) {
      console.error('Error fetching weekly time entries:', error);
    }
  }

  async function checkAndUpdateCompletion() {
    if (!challenge) return;

    const totalMinutes = weeklyTimeEntries.reduce((sum, entry) => sum + entry.minutes, 0);
    const targetMinutes = challenge.target_hours * 60;

    // If total minutes meets or exceeds target and no completion exists
    if (totalMinutes >= targetMinutes && !completion) {
      try {
        const { data, error } = await supabase
          .from('weekly_challenge_completions')
          .insert({
            challenge_id: challenge.id,
            user_id: currentUserId
          })
          .select()
          .single();

        if (error) throw error;
        setCompletion(data);
      } catch (error) {
        console.error('Error updating challenge completion:', error);
      }
    }
    // If total minutes falls below target and completion exists
    else if (totalMinutes < targetMinutes && completion) {
      try {
        const { error } = await supabase
          .from('weekly_challenge_completions')
          .delete()
          .match({
            challenge_id: challenge.id,
            user_id: currentUserId
          });

        if (error) throw error;
        setCompletion(null);
      } catch (error) {
        console.error('Error removing challenge completion:', error);
      }
    }
  }

  async function fetchWeeklyData() {
    try {
      setLoading(true);
      const monday = format(weekStart, 'yyyy-MM-dd');

      // Fetch current challenge
      const { data: challengeData, error: challengeError } = await supabase
        .from('weekly_challenges')
        .select('*')
        .eq('start_date', monday)
        .maybeSingle();

      if (challengeError && challengeError.code !== 'PGRST116') throw challengeError;

      if (!challengeData) {
        await supabase.rpc('ensure_weekly_challenge');
        const { data: newChallengeData, error: newChallengeError } = await supabase
          .from('weekly_challenges')
          .select('*')
          .eq('start_date', monday)
          .single();

        if (newChallengeError) throw newChallengeError;
        setChallenge(newChallengeData);

        if (newChallengeData) {
          const { data: completionData, error: completionError } = await supabase
            .from('weekly_challenge_completions')
            .select('*')
            .eq('challenge_id', newChallengeData.id)
            .eq('user_id', currentUserId)
            .maybeSingle();

          if (completionError && completionError.code !== 'PGRST116') throw completionError;
          setCompletion(completionData);
        }
      } else {
        setChallenge(challengeData);

        const { data: completionData, error: completionError } = await supabase
          .from('weekly_challenge_completions')
          .select('*')
          .eq('challenge_id', challengeData.id)
          .eq('user_id', currentUserId)
          .maybeSingle();

        if (completionError && completionError.code !== 'PGRST116') throw completionError;
        setCompletion(completionData);
      }

      // Fetch top users
      const { data: userData, error: userError } = await supabase
        .from('user_stats')
        .select(`
          user_id,
          weekly_minutes,
          user_profiles (
            username,
            avatar_url
          )
        `)
        .order('weekly_minutes', { ascending: false })
        .limit(5);

      if (userError) throw userError;
      setTopUsers(userData || []);

      // Get current user's stats if not in top users
      if (!userData?.find(user => user.user_id === currentUserId)) {
        const { data: currentUserData, error: currentUserError } = await supabase
          .from('user_stats')
          .select(`
            user_id,
            weekly_minutes,
            user_profiles (
              username,
              avatar_url
            )
          `)
          .eq('user_id', currentUserId)
          .maybeSingle();

        if (currentUserError && currentUserError.code !== 'PGRST116') throw currentUserError;
        setCurrentUserStats(currentUserData);
      }
    } catch (error) {
      console.error('Error fetching weekly data:', error);
    } finally {
      setLoading(false);
    }
  }

  async function fetchConsecutiveCompletions() {
    try {
      const { data, error } = await supabase
        .from('weekly_challenge_completions')
        .select('completed_at')
        .eq('user_id', currentUserId)
        .order('completed_at', { ascending: false });

      if (error) throw error;

      let consecutive = 0;
      if (data) {
        for (let i = 0; i < data.length - 1; i++) {
          const current = new Date(data[i].completed_at);
          const next = new Date(data[i + 1].completed_at);
          if (differenceInDays(current, next) <= 7) {
            consecutive++;
          } else {
            break;
          }
        }
      }
      setConsecutiveCompletions(consecutive);
    } catch (error) {
      console.error('Error fetching consecutive completions:', error);
    }
  }

  const daysRemaining = differenceInDays(weekEnd, new Date());
  const hoursToMinutes = (challenge?.target_hours || 0) * 60;
  const totalMinutes = weeklyTimeEntries.reduce((sum, entry) => sum + entry.minutes, 0);
  const progressPercentage = Math.min(100, (totalMinutes / hoursToMinutes) * 100);

  if (loading) {
    return (
      <div className="bg-white rounded-lg shadow-sm p-6 animate-pulse">
        <div className="h-8 bg-gray-200 rounded w-1/4 mb-4"></div>
        <div className="h-4 bg-gray-200 rounded w-3/4 mb-6"></div>
        <div className="h-6 bg-gray-200 rounded w-full mb-4"></div>
        <div className="grid grid-cols-3 gap-4">
          <div className="h-20 bg-gray-200 rounded"></div>
          <div className="h-20 bg-gray-200 rounded"></div>
          <div className="h-20 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-sm overflow-hidden">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-500 to-purple-600 p-6 text-white">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/10 rounded-lg backdrop-blur-sm">
              <Trophy className="w-6 h-6" />
            </div>
            <h2 className="text-xl font-bold">Weekly Challenge</h2>
          </div>
          <div className="flex items-center gap-2 bg-white/10 px-3 py-1 rounded-full backdrop-blur-sm">
            <Clock className="w-4 h-4" />
            <span className="text-sm">{daysRemaining} days left</span>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="relative h-4 bg-white/20 rounded-full overflow-hidden mb-2">
          <div
            className="absolute left-0 top-0 h-full bg-white transition-all duration-1000 ease-out"
            style={{ width: `${progressPercentage}%` }}
          >
            {completion && (
              <div className="absolute inset-0 bg-gradient-to-r from-yellow-400 to-yellow-300 animate-pulse"></div>
            )}
          </div>
        </div>

        <div className="flex items-center justify-between text-sm mb-4">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4" />
            <span>
              {Math.floor(totalMinutes / 60)} hours {totalMinutes % 60} minutes
            </span>
          </div>
          <div className="flex items-center gap-2">
            <Target className="w-4 h-4" />
            <span>Goal: {challenge?.target_hours} hours ({Math.round(progressPercentage)}%)</span>
          </div>
        </div>

        {/* Achievement Badges */}
        <div className="flex items-center gap-4 pt-4 border-t border-white/20">
          {completion ? (
            <div className="flex items-center gap-2 bg-yellow-400 text-purple-900 px-3 py-1 rounded-full font-medium">
              <Star className="w-4 h-4" />
              Challenge Completed!
            </div>
          ) : (
            <div className="text-white/90">
              {progressPercentage >= 50 ? 'Halfway there!' : 'Keep going!'}
            </div>
          )}
          {consecutiveCompletions > 0 && (
            <div className="flex items-center gap-2 bg-white/10 px-3 py-1 rounded-full">
              <Award className="w-4 h-4" />
              <span>{consecutiveCompletions} week streak</span>
            </div>
          )}
        </div>
      </div>

      {/* Leaderboard */}
      <div className="p-6">
        <h3 className="text-gray-900 font-medium mb-4 flex items-center gap-2">
          <Users className="w-5 h-5 text-purple-500" />
          Top Participants
        </h3>
        <div className="space-y-3">
          {topUsers.map((user, index) => (
            <div
              key={user.user_id}
              className={`flex items-center gap-4 p-3 rounded-lg transition-colors ${
                user.user_id === currentUserId
                  ? 'bg-purple-50 border border-purple-100'
                  : 'hover:bg-gray-50'
              }`}
            >
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                index === 0 ? 'bg-yellow-100 text-yellow-700' :
                index === 1 ? 'bg-gray-100 text-gray-700' :
                index === 2 ? 'bg-orange-100 text-orange-700' :
                'bg-purple-100 text-purple-700'
              }`}>
                {index + 1}
              </div>
              <div className="flex-1">
                <div className="font-medium text-gray-900">
                  @{user.user_profiles?.username}
                </div>
                <div className="text-sm text-gray-500">
                  {Math.round(user.weekly_minutes / 60)} hours completed
                </div>
              </div>
              {user.weekly_minutes >= hoursToMinutes && (
                <Trophy className="w-5 h-5 text-yellow-500" />
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Call to Action */}
      {!completion && (
        <div className="p-6 bg-gray-50 border-t">
          <div className="flex items-center justify-between">
            <div className="text-sm text-gray-600">
              {progressPercentage < 100 ? (
                `${Math.round(hoursToMinutes - totalMinutes)} minutes to go`
              ) : (
                'Ready to claim your completion!'
              )}
            </div>
            <a
              href="/watch"
              className="flex items-center gap-2 px-4 py-2 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition-colors"
            >
              <Target className="w-4 h-4" />
              Watch Now
              <ArrowRight className="w-4 h-4" />
            </a>
          </div>
        </div>
      )}
    </div>
  );
}