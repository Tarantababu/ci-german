import React from 'react';
import { format, startOfMonth, endOfMonth, eachDayOfInterval } from 'date-fns';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface TimeEntry {
  date: string;
  minutes: number;
}

interface CalendarProps {
  entries: TimeEntry[];
  currentDate: Date;
  onDateChange: (date: Date) => void;
}

export function Calendar({ entries, currentDate, onDateChange }: CalendarProps) {
  const start = startOfMonth(currentDate);
  const end = endOfMonth(currentDate);
  const days = eachDayOfInterval({ start, end });

  const getDayEntries = (date: Date) => {
    return entries.filter(
      (entry) => entry.date === format(date, 'yyyy-MM-dd')
    );
  };

  const getTotalMinutes = (date: Date) => {
    const dayEntries = getDayEntries(date);
    return dayEntries.reduce((sum, entry) => sum + entry.minutes, 0);
  };

  return (
    <div className="w-full max-w-3xl mx-auto bg-white rounded-lg shadow-sm border p-6">
      {/* Month Navigation */}
      <div className="flex items-center justify-between mb-6">
        <button 
          onClick={() => onDateChange(new Date(currentDate.setMonth(currentDate.getMonth() - 1)))}
          className="p-2 hover:bg-gray-100 rounded-full transition-colors"
        >
          <ChevronLeft className="w-5 h-5 text-gray-600" />
        </button>
        <h2 className="text-xl font-semibold text-gray-900">
          {format(currentDate, 'MMMM yyyy')}
        </h2>
        <button 
          onClick={() => onDateChange(new Date(currentDate.setMonth(currentDate.getMonth() + 1)))}
          className="p-2 hover:bg-gray-100 rounded-full transition-colors"
        >
          <ChevronRight className="w-5 h-5 text-gray-600" />
        </button>
      </div>

      {/* Day Headers */}
      <div className="grid grid-cols-7 gap-1 text-center mb-2">
        {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
          <div key={day} className="text-sm text-gray-500 font-medium py-2">
            {day}
          </div>
        ))}
      </div>

      {/* Calendar Grid */}
      <div className="grid grid-cols-7 gap-1">
        {days.map((day) => {
          const totalMinutes = getTotalMinutes(day);
          const isToday = format(day, 'yyyy-MM-dd') === format(new Date(), 'yyyy-MM-dd');
          
          return (
            <div
              key={day.toString()}
              className={`
                aspect-square p-2 rounded-lg
                transition-all duration-200
                hover:shadow-md cursor-pointer
                ${isToday ? 'bg-orange-50 ring-2 ring-orange-200' : 
                  totalMinutes > 0 ? 'bg-blue-50 hover:bg-blue-100' : 
                  'hover:bg-gray-50'}
              `}
              onClick={() => onDateChange(day)}
            >
              <div className="h-full flex flex-col justify-between">
                <span className={`
                  text-sm font-medium
                  ${isToday ? 'text-orange-600' : 'text-gray-700'}
                `}>
                  {format(day, 'd')}
                </span>
                {totalMinutes > 0 && (
                  <div className="flex items-center justify-center">
                    <span className={`
                      text-xs font-medium px-2 py-1 rounded-full
                      ${isToday ? 'bg-orange-100 text-orange-600' : 
                        'bg-blue-100 text-blue-600'}
                    `}>
                      {totalMinutes}m
                    </span>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default Calendar;