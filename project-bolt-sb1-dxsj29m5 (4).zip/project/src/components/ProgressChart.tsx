import React from 'react';

interface Level {
  number: number;
  hoursRequired: number;
  description: string;
  knownWords: string;
}

interface ProgressChartProps {
  totalMinutes: number;
}

export function ProgressChart({ totalMinutes }: ProgressChartProps) {
  const LEVELS: Level[] = [
    {
      number: 1,
      hoursRequired: 0,
      description: "Starting from zero.",
      knownWords: "0"
    },
    {
      number: 2,
      hoursRequired: 50,
      description: "You know some common words.",
      knownWords: "300"
    },
    {
      number: 3,
      hoursRequired: 150,
      description: "You can follow topics that are adapted for learners.",
      knownWords: "1,500"
    },
    {
      number: 4,
      hoursRequired: 300,
      description: "You can understand a person speaking to you patiently.",
      knownWords: "3,000"
    },
    {
      number: 5,
      hoursRequired: 600,
      description: "You can understand native speakers speaking to you normally.",
      knownWords: "5,000"
    },
    {
      number: 6,
      hoursRequired: 1000,
      description: "You are comfortable with daily conversation.",
      knownWords: "7,000"
    },
    {
      number: 7,
      hoursRequired: 1500,
      description: "You can use the language effectively for all practical purposes.",
      knownWords: "12,000+"
    }
  ];

  const totalHours = Math.floor(totalMinutes / 60);
  
  const currentLevel = LEVELS.reduce((prev, curr) => {
    if (totalHours >= curr.hoursRequired) {
      return curr;
    }
    return prev;
  }, LEVELS[0]);
  
  const nextLevel = LEVELS[currentLevel.number];

  const getBarHeight = (levelNumber: number) => {
    // Define height percentages for each level
    const heights = {
      1: 30,
      2: 40,
      3: 50,
      4: 60,
      5: 80,
      6: 90,
      7: 100
    };
    return heights[levelNumber as keyof typeof heights];
  };

  return (
    <div className="w-full max-w-md bg-white rounded-lg p-6">
      <div className="flex items-end justify-between h-48 mb-8">
        {LEVELS.map((level, index) => {
          const isCurrentLevel = level.number === currentLevel.number;
          const isPastLevel = level.number < currentLevel.number;
          
          return (
            <div
              key={level.number}
              className={`w-10 rounded-lg transition-all duration-300 ${
                isCurrentLevel ? 'bg-pink-500' :
                isPastLevel ? 'bg-red-400' : 'bg-gray-100'
              }`}
              style={{
                height: `${getBarHeight(level.number)}%`,
                minHeight: '20px'
              }}
            />
          );
        })}
      </div>

      <div className="text-center mb-6">
        <p className="text-gray-600 mb-2">You are currently in</p>
        <h2 className="text-2xl font-bold">Level {currentLevel.number}</h2>
      </div>

      <div className="mb-6">
        <div className="flex justify-between text-sm text-gray-600 mb-2">
          <span>Total input time</span>
          <span>{totalHours} hrs</span>
        </div>
        <div className="relative h-2 bg-gray-100 rounded-full overflow-hidden">
          <div
            className="absolute left-0 top-0 h-full bg-indigo-600 rounded-full"
            style={{
              width: `${(totalHours - currentLevel.hoursRequired) / (nextLevel?.hoursRequired - currentLevel.hoursRequired) * 100}%`
            }}
          />
        </div>
        <div className="flex justify-between text-sm text-gray-500 mt-1">
          <span>{currentLevel.hoursRequired} hrs</span>
          <span>{nextLevel?.hoursRequired} hrs</span>
        </div>
      </div>

      {nextLevel && (
        <div className="bg-blue-50 rounded-lg p-4 flex justify-between items-center">
          <span className="text-blue-600">Hours to level {nextLevel.number}</span>
          <span className="font-medium text-blue-600">
            {nextLevel.hoursRequired - totalHours} hrs
          </span>
        </div>
      )}
    </div>
  );
}

export default ProgressChart;