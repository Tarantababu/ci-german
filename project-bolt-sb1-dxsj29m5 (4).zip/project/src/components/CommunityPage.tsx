import React, { useState, useEffect } from 'react';
import { Trophy, Filter, ArrowDown, ArrowUp, Users, Star, Clock, Calendar } from 'lucide-react';
import { Leaderboard } from './Leaderboard';
import { WeeklyChallenge } from './WeeklyChallenge';
import { UserProfileModal } from './UserProfileModal';
import { ShareProgress } from './ShareProgress';
import { useAlerts } from '../hooks/useAlerts';
import { useRealtimeSubscription } from '../hooks/useRealtimeSubscription';
import { supabase } from '../lib/supabase';

interface UserStats {
  user_id: string;
  current_streak: number;
  longest_streak: number;
  total_minutes: number;
  weekly_minutes: number;
  monthly_minutes: number;
  total_videos_watched: number;
  level: number;
  user_profiles?: {
    display_name: string;
    avatar_url: string;
    username: string;
    created_at: string;
  };
}

interface CommunityPageProps {
  currentUserId: string;
}

interface Filters {
  timeframe: 'daily' | 'weekly' | 'monthly' | 'all-time';
  minLevel?: number;
  maxLevel?: number;
}

interface CommunityStats {
  total_users: number;
  active_today: number;
  average_streak: number;
}

export function CommunityPage({ currentUserId }: CommunityPageProps) {
  const { showError } = useAlerts();
  const [selectedUser, setSelectedUser] = useState<UserStats | null>(null);
  const [currentUserStats, setCurrentUserStats] = useState<UserStats | null>(null);
  const [filters, setFilters] = useState<Filters>(() => {
    const saved = localStorage.getItem('communityFilters');
    return saved ? JSON.parse(saved) : {
      timeframe: 'weekly',
      minLevel: undefined,
      maxLevel: undefined
    };
  });
  const [showFilters, setShowFilters] = useState(false);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState<{
    totalUsers: number;
    activeToday: number;
    averageStreak: number;
  }>({
    totalUsers: 0,
    activeToday: 0,
    averageStreak: 0
  });

  useEffect(() => {
    localStorage.setItem('communityFilters', JSON.stringify(filters));
    fetchCurrentUserStats();
  }, [filters]);

  useEffect(() => {
    fetchCommunityStats();
  }, []);

  useRealtimeSubscription('user_stats', () => {
    fetchCommunityStats();
    fetchCurrentUserStats();
  });

  async function fetchCurrentUserStats() {
    try {
      const { data, error } = await supabase
        .from('user_stats')
        .select(`
          *,
          user_profiles (
            display_name,
            avatar_url,
            username,
            created_at
          )
        `)
        .eq('user_id', currentUserId)
        .single();

      if (error) throw error;
      setCurrentUserStats(data);
    } catch (error) {
      console.error('Error fetching user stats:', error);
      showError('Failed to load your statistics');
    }
  }

  async function fetchCommunityStats() {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .rpc<CommunityStats>('get_community_stats')
        .single();

      if (error) throw error;

      if (data) {
        setStats({
          totalUsers: data.total_users,
          activeToday: data.active_today,
          averageStreak: data.average_streak
        });
      }
    } catch (error) {
      console.error('Error fetching community stats:', error);
      showError('Failed to load community statistics');
    } finally {
      setLoading(false);
    }
  }

  const resetFilters = () => {
    setFilters({
      timeframe: 'weekly',
      minLevel: undefined,
      maxLevel: undefined
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header Section */}
      <div className="bg-gradient-to-r from-orange-500 to-orange-600 text-white">
        <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-12">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="text-center md:text-left w-full md:w-auto">
              <h1 className="text-2xl sm:text-3xl font-bold flex items-center justify-center md:justify-start gap-3 mb-2">
                <Users className="w-6 h-6 sm:w-8 sm:h-8" />
                Community
              </h1>
              <p className="text-sm sm:text-base text-orange-100">
                Connect, compete, and celebrate progress together
              </p>
            </div>

            {/* Community Stats - Mobile Responsive */}
            <div className="w-full md:w-auto mt-4 md:mt-0 grid grid-cols-3 gap-2 sm:gap-4 bg-white/10 rounded-lg p-3 sm:p-4 backdrop-blur-sm">
              <div className="text-center">
                <div className="text-xl sm:text-2xl font-bold">{stats.totalUsers}</div>
                <div className="text-xs sm:text-sm text-orange-100">Members</div>
              </div>
              <div className="text-center border-x border-white/20">
                <div className="text-xl sm:text-2xl font-bold">{stats.activeToday}</div>
                <div className="text-xs sm:text-sm text-orange-100">Active Today</div>
              </div>
              <div className="text-center">
                <div className="text-xl sm:text-2xl font-bold">{stats.averageStreak}d</div>
                <div className="text-xs sm:text-sm text-orange-100">Avg Streak</div>
              </div>
            </div>
          </div>

          {/* Share Progress Button - Responsive placement */}
          {currentUserStats && currentUserStats.user_profiles?.username && (
            <div className="mt-6 sm:mt-8 flex justify-center">
              <ShareProgress
                username={currentUserStats.user_profiles.username}
                stats={{
                  level: currentUserStats.level,
                  totalMinutes: currentUserStats.total_minutes,
                  streak: currentUserStats.current_streak,
                  videosWatched: currentUserStats.total_videos_watched
                }}
                achievements={[]} // Add achievements when available
              />
            </div>
          )}
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-8">
        {/* Filters Section - Mobile Optimized */}
        <div className="bg-white rounded-lg shadow-sm p-4 sm:p-6 mb-6">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-4 sm:mb-6">
            <div className="flex items-center gap-2">
              <Filter className="w-5 h-5 text-gray-500" />
              <h2 className="font-medium text-gray-900">Filters</h2>
            </div>
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-4 py-2 text-gray-600 hover:text-gray-900 border rounded-md hover:bg-gray-50"
            >
              <Filter className="w-4 h-4" />
              <span>Filter Options</span>
              {showFilters ? <ArrowUp className="w-4 h-4" /> : <ArrowDown className="w-4 h-4" />}
            </button>
          </div>

          {showFilters && (
            <div className="space-y-4 border-t pt-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Timeframe
                </label>
                <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                  {['daily', 'weekly', 'monthly', 'all-time'].map((timeframe) => (
                    <button
                      key={timeframe}
                      onClick={() => setFilters({ ...filters, timeframe: timeframe as Filters['timeframe'] })}
                      className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                        filters.timeframe === timeframe
                          ? 'bg-orange-100 text-orange-800'
                          : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                      }`}
                    >
                      {timeframe.charAt(0).toUpperCase() + timeframe.slice(1)}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Level Range
                </label>
                <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2 sm:gap-4">
                  <div className="flex items-center gap-2 w-full sm:w-auto">
                    <span className="text-sm text-gray-500 w-10">Min:</span>
                    <input
                      type="number"
                      min="1"
                      max="100"
                      value={filters.minLevel || ''}
                      onChange={(e) => setFilters({ ...filters, minLevel: parseInt(e.target.value) || undefined })}
                      placeholder="1"
                      className="w-full sm:w-24 px-3 py-2 border border-gray-300 rounded-md"
                    />
                  </div>
                  <div className="flex items-center gap-2 w-full sm:w-auto">
                    <span className="text-sm text-gray-500 w-10">Max:</span>
                    <input
                      type="number"
                      min="1"
                      max="100"
                      value={filters.maxLevel || ''}
                      onChange={(e) => setFilters({ ...filters, maxLevel: parseInt(e.target.value) || undefined })}
                      placeholder="100"
                      className="w-full sm:w-24 px-3 py-2 border border-gray-300 rounded-md"
                    />
                  </div>
                </div>
              </div>

              <div className="flex justify-end">
                <button
                  onClick={resetFilters}
                  className="text-sm text-gray-500 hover:text-gray-700 hover:underline"
                >
                  Reset Filters
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Weekly Challenge */}
        <div className="mb-6">
          <WeeklyChallenge currentUserId={currentUserId} />
        </div>

        {/* Leaderboard */}
        <div className="bg-white rounded-lg shadow-sm overflow-hidden">
          <div className="p-4 sm:p-6 border-b">
            <h2 className="text-lg sm:text-xl font-bold flex items-center gap-2">
              <Trophy className="w-5 h-5 sm:w-6 sm:h-6 text-yellow-500" />
              Leaderboard
            </h2>
          </div>
          
          {/* Updated Leaderboard component with more elegant user list */}
          <Leaderboard
            currentUserId={currentUserId}
            onUserClick={setSelectedUser}
            filters={filters}
          />
        </div>
      </div>

      {/* User Profile Modal */}
      {selectedUser && (
        <UserProfileModal
          isOpen={true}
          onClose={() => setSelectedUser(null)}
          user={selectedUser}
        />
      )}
    </div>
  );
}