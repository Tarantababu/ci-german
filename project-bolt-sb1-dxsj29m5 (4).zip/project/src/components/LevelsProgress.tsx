import React from 'react';
import { Clock, MessageCircle } from 'lucide-react';
import { Link } from 'react-router-dom';

interface Level {
  number: number;
  hoursRequired: number;
  description: string;
  knownWords: string;
  color: string;
}

interface LevelsProgressProps {
  totalHours: number;
  dailyGoalMinutes: number;
}

export function LevelsProgress({ totalHours, dailyGoalMinutes }: LevelsProgressProps) {
  const LEVELS: Level[] = [
    {
      number: 1,
      hoursRequired: 0,
      description: "Starting from zero.",
      knownWords: "0",
      color: "rgb(255, 121, 112)"
    },
    {
      number: 2,
      hoursRequired: 50,
      description: "You know some common words.",
      knownWords: "300",
      color: "rgb(244, 126, 193)"
    },
    {
      number: 3,
      hoursRequired: 150,
      description: "You can follow topics that are adapted for learners.",
      knownWords: "1,500",
      color: "rgb(192, 133, 223)"
    },
    {
      number: 4,
      hoursRequired: 300,
      description: "You can understand a person speaking to you patiently.",
      knownWords: "3,000",
      color: "rgb(126, 135, 225)"
    },
    {
      number: 5,
      hoursRequired: 600,
      description: "You can understand native speakers speaking to you normally.",
      knownWords: "5,000",
      color: "rgb(80, 183, 210)"
    },
    {
      number: 6,
      hoursRequired: 1000,
      description: "You are comfortable with daily conversation.",
      knownWords: "7,000",
      color: "rgb(88, 203, 143)"
    },
    {
      number: 7,
      hoursRequired: 1500,
      description: "You can use the language effectively for all practical purposes.",
      knownWords: "12,000+",
      color: "rgb(130, 212, 105)"
    }
  ];

  const getCurrentLevel = () => {
    return LEVELS.reduce((prev, curr) => {
      if (totalHours >= curr.hoursRequired) {
        return curr;
      }
      return prev;
    }, LEVELS[0]);
  };

  const getNextLevel = (currentLevel: Level) => {
    const nextIndex = LEVELS.findIndex(level => level.number === currentLevel.number) + 1;
    return nextIndex < LEVELS.length ? LEVELS[nextIndex] : null;
  };

  const getDaysToNextLevel = (nextLevel: Level) => {
    const remainingHours = nextLevel.hoursRequired - totalHours;
    const dailyHours = dailyGoalMinutes / 60;
    return Math.ceil(remainingHours / dailyHours);
  };

  const currentLevel = getCurrentLevel();
  const nextLevel = getNextLevel(currentLevel);

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold">Your Progress</h2>
        <Link
          to="/method"
          className="text-sm text-orange-500 hover:text-orange-600 flex items-center gap-2"
        >
          <MessageCircle className="w-4 h-4" />
          Learn about our method
        </Link>
      </div>

      <div className="grid gap-4">
        {LEVELS.map((level) => {
          const isCurrentLevel = level.number === currentLevel.number;
          const isPastLevel = level.number < currentLevel.number;
          const isNextLevel = nextLevel && level.number === nextLevel.number;
          
          return (
            <div
              key={level.number}
              className={`relative p-4 rounded-lg border transition-all ${
                isCurrentLevel
                  ? 'border-orange-500 shadow-lg shadow-orange-100'
                  : isPastLevel
                  ? 'border-green-500 bg-green-50'
                  : 'border-gray-200'
              }`}
            >
              <div className="flex items-start gap-4">
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                    isCurrentLevel || isPastLevel
                      ? 'bg-orange-500 text-white'
                      : 'bg-gray-100 text-gray-500'
                  }`}
                >
                  {level.number}
                </div>
                <div className="flex-1">
                  <h3 className="font-medium text-gray-900">{level.description}</h3>
                  <div className="mt-2 flex flex-wrap gap-2">
                    <span className="inline-flex items-center gap-1 text-sm text-gray-600">
                      <Clock className="w-4 h-4" />
                      {level.hoursRequired} hours
                    </span>
                    <span className="inline-flex items-center gap-1 text-sm text-gray-600">
                      <MessageCircle className="w-4 h-4" />
                      {level.knownWords} words
                    </span>
                  </div>
                  {isNextLevel && (
                    <div className="mt-2 text-sm text-orange-600">
                      You'll reach this level in {getDaysToNextLevel(level)} days at your current pace
                    </div>
                  )}
                </div>
              </div>
              {isCurrentLevel && (
                <div className="absolute top-0 right-0 mt-4 mr-4">
                  <span className="px-3 py-1 bg-orange-100 text-orange-600 rounded-full text-sm font-medium">
                    Current Level
                  </span>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}