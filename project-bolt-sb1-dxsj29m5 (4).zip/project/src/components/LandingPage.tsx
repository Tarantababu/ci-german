import React from 'react';
import { Globe2, BookOpen, Headphones, Brain } from 'lucide-react';

interface LandingPageProps {
  onStartLearning: () => void;
}

export function LandingPage({ onStartLearning }: LandingPageProps) {
  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="fixed w-full bg-white/90 backdrop-blur-sm z-50 border-b border-gray-100">
        <div className="max-w-5xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Globe2 className="w-8 h-8 text-orange-500" />
            <span className="text-xl font-medium">ComprehensibleGerman</span>
          </div>
          <button 
            onClick={onStartLearning}
            className="px-4 py-2 bg-orange-500 text-white rounded-full text-sm font-medium hover:bg-orange-600 transition-colors"
          >
            Start Learning
          </button>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="pt-32 pb-20 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
            Learn German{' '}
            <span className="text-orange-500">naturally</span>
          </h1>
          <p className="text-xl text-gray-600 mb-12 max-w-2xl mx-auto">
            Master German through comprehensible input with content tailored to your level
          </p>
          <button
            onClick={onStartLearning}
            className="px-8 py-4 bg-orange-500 text-white rounded-full text-lg font-medium hover:bg-orange-600 transition-all hover:scale-105 transform"
          >
            Begin Your Journey
          </button>
        </div>
      </div>

      {/* Features */}
      <div className="py-20 bg-gray-50">
        <div className="max-w-5xl mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8">
            <div className="group p-6 bg-white rounded-2xl hover:shadow-lg transition-all">
              <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <BookOpen className="w-6 h-6 text-orange-500" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Comprehensible Input</h3>
              <p className="text-gray-600">
                Learn with content designed for optimal comprehension at your level
              </p>
            </div>

            <div className="group p-6 bg-white rounded-2xl hover:shadow-lg transition-all">
              <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <Headphones className="w-6 h-6 text-orange-500" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Natural Learning</h3>
              <p className="text-gray-600">
                Acquire German naturally through listening and understanding
              </p>
            </div>

            <div className="group p-6 bg-white rounded-2xl hover:shadow-lg transition-all">
              <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <Brain className="w-6 h-6 text-orange-500" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Proven Method</h3>
              <p className="text-gray-600">
                Based on decades of research in language acquisition
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Social Proof */}
      <div className="py-20">
        <div className="max-w-5xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Trusted by Learners</h2>
            <p className="text-gray-600">Join thousands of successful German learners</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                name: "Sarah M.",
                level: "B2 Achieved",
                image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400",
                quote: "The comprehensible input approach made all the difference in my learning journey."
              },
              {
                name: "Michael K.",
                level: "A2 to B1",
                image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400",
                quote: "I love how the content adapts to my level. It's challenging but never overwhelming."
              },
              {
                name: "Emma T.",
                level: "Complete Beginner",
                image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400",
                quote: "Starting from zero was intimidating, but this natural approach made it achievable."
              }
            ].map((testimonial, index) => (
              <div key={index} className="bg-white p-6 rounded-2xl hover:shadow-lg transition-all">
                <div className="flex items-center gap-4 mb-4">
                  <img
                    src={testimonial.image}
                    alt={testimonial.name}
                    className="w-12 h-12 rounded-full object-cover"
                  />
                  <div>
                    <h4 className="font-medium">{testimonial.name}</h4>
                    <p className="text-sm text-orange-500">{testimonial.level}</p>
                  </div>
                </div>
                <p className="text-gray-600 italic">"{testimonial.quote}"</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-orange-500 text-white py-20">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-6">
            Ready to start your German journey?
          </h2>
          <button
            onClick={onStartLearning}
            className="px-8 py-4 bg-white text-orange-500 rounded-full text-lg font-medium hover:bg-gray-50 transition-colors"
          >
            Get Started Now
          </button>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-5xl mx-auto px-4">
          <div className="flex items-center justify-center gap-2 mb-8">
            <Globe2 className="w-8 h-8 text-orange-500" />
            <span className="text-xl font-medium">ComprehensibleGerman</span>
          </div>
          <div className="text-center text-gray-400">
            <p>&copy; {new Date().getFullYear()} ComprehensibleGerman.com. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}