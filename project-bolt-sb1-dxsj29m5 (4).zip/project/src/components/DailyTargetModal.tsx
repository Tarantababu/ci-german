import React, { useState } from 'react';
import { supabase } from '../lib/supabase';
import { useAlerts } from '../hooks/useAlerts';
import { Target, Coffee, Rocket, Edit } from 'lucide-react';

interface DailyTargetModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentTarget: number;
  onSave: () => void;
}

interface GoalTemplate {
  id: string;
  name: string;
  minutes: number;
  description: string;
  icon: React.ReactNode;
}

export function DailyTargetModal({ isOpen, onClose, currentTarget, onSave }: DailyTargetModalProps) {
  const { showSuccess, showError } = useAlerts();
  const [selectedTemplate, setSelectedTemplate] = useState<string | null>(null);
  const [customMinutes, setCustomMinutes] = useState(currentTarget);
  const [loading, setLoading] = useState(false);

  const templates: GoalTemplate[] = [
    {
      id: 'casual',
      name: 'Casual',
      minutes: 15,
      description: 'Keeping your skills fresh',
      icon: <Coffee className="w-5 h-5" />
    },
    {
      id: 'learner',
      name: 'Learner',
      minutes: 30,
      description: 'Making progress every day',
      icon: <Target className="w-5 h-5" />
    },
    {
      id: 'serious',
      name: 'Serious',
      minutes: 60,
      description: 'Making progress very quickly',
      icon: <Rocket className="w-5 h-5" />
    }
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      const targetMinutes = selectedTemplate === 'custom' 
        ? customMinutes 
        : templates.find(t => t.id === selectedTemplate)?.minutes || currentTarget;

      const { error } = await supabase
        .from('daily_targets')
        .insert({
          target_minutes: targetMinutes,
        });

      if (error) throw error;
      
      showSuccess('Daily target updated!');
      onSave();
      onClose();
    } catch (error) {
      console.error('Error saving daily target:', error);
      showError('Failed to update daily target');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-md w-full p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-semibold">Set Daily Goal</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            ×
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Templates */}
          <div className="space-y-3">
            {templates.map((template) => (
              <button
                key={template.id}
                type="button"
                onClick={() => setSelectedTemplate(template.id)}
                className={`w-full flex items-center justify-between p-4 rounded-lg border-2 transition-all ${
                  selectedTemplate === template.id
                    ? 'border-orange-500 bg-orange-50'
                    : 'border-gray-200 hover:border-orange-200'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-full ${
                    selectedTemplate === template.id
                      ? 'bg-orange-100 text-orange-600'
                      : 'bg-gray-100 text-gray-600'
                  }`}>
                    {template.icon}
                  </div>
                  <div className="text-left">
                    <h3 className="font-medium text-gray-900">{template.name}</h3>
                    <p className="text-sm text-gray-600">{template.description}</p>
                  </div>
                </div>
                <span className="text-sm font-medium text-gray-900">
                  {template.minutes} min/day
                </span>
              </button>
            ))}

            {/* Custom Goal */}
            <button
              type="button"
              onClick={() => setSelectedTemplate('custom')}
              className={`w-full flex items-center justify-between p-4 rounded-lg border-2 transition-all ${
                selectedTemplate === 'custom'
                  ? 'border-orange-500 bg-orange-50'
                  : 'border-gray-200 hover:border-orange-200'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-full ${
                  selectedTemplate === 'custom'
                    ? 'bg-orange-100 text-orange-600'
                    : 'bg-gray-100 text-gray-600'
                }`}>
                  <Edit className="w-5 h-5" />
                </div>
                <div className="text-left">
                  <h3 className="font-medium text-gray-900">Choose your own goal!</h3>
                  <p className="text-sm text-gray-600">Write your goal in minutes</p>
                </div>
              </div>
              {selectedTemplate === 'custom' ? (
                <input
                  type="number"
                  min="1"
                  value={customMinutes}
                  onChange={(e) => setCustomMinutes(parseInt(e.target.value) || 0)}
                  onClick={(e) => e.stopPropagation()}
                  className="w-16 px-2 py-1 text-right border rounded-md"
                />
              ) : (
                <span className="text-sm font-medium text-gray-900">Custom</span>
              )}
            </button>
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-gray-700 hover:text-gray-500"
              disabled={loading}
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!selectedTemplate || loading}
              className="px-4 py-2 text-sm font-medium text-white bg-orange-500 rounded-md hover:bg-orange-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? 'Saving...' : 'Save'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}