import React from 'react';
import { Clock, Play, Calendar } from 'lucide-react';
import { TimeEntry } from '../types';
import { ProgressChart } from './ProgressChart';

interface StatisticsProps {
  entries: TimeEntry[];
}

export function Statistics({ entries }: StatisticsProps) {
  const calculateStats = () => {
    const now = new Date();
    const today = now.toISOString().split('T')[0];
    
    // Calculate total minutes watched
    const totalMinutes = entries.reduce((sum, entry) => sum + entry.minutes, 0);
    
    // Calculate number of watched videos
    const watchedVideos = entries.filter(entry => entry.activity_type === 'watching').length;
    
    // Calculate number of active days
    const uniqueDays = new Set(entries.map(entry => entry.date)).size;
    
    // Calculate current streak
    let streak = 0;
    let currentDate = new Date();
    
    while (true) {
      const dateStr = currentDate.toISOString().split('T')[0];
      const hasEntry = entries.some(entry => entry.date === dateStr);
      
      if (!hasEntry) break;
      streak++;
      currentDate.setDate(currentDate.getDate() - 1);
    }

    return {
      totalMinutes,
      watchedVideos,
      uniqueDays,
      streak
    };
  };

  const stats = calculateStats();

  return (
    <div className="space-y-8">
      <div className="bg-white rounded-lg shadow-sm p-6">
        <h2 className="text-xl font-bold mb-6">Statistics</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-purple-50 rounded-lg p-4 flex flex-col items-center text-center">
            <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mb-3">
              <Clock className="w-6 h-6 text-purple-600" />
            </div>
            <span className="text-2xl font-bold text-purple-600 mb-1">
              {stats.totalMinutes}
            </span>
            <span className="text-sm text-purple-600">
              minutes watched
            </span>
          </div>

          <div className="bg-blue-50 rounded-lg p-4 flex flex-col items-center text-center">
            <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-3">
              <Play className="w-6 h-6 text-blue-600" />
            </div>
            <span className="text-2xl font-bold text-blue-600 mb-1">
              {stats.watchedVideos}
            </span>
            <span className="text-sm text-blue-600">
              videos completed
            </span>
          </div>

          <div className="bg-green-50 rounded-lg p-4 flex flex-col items-center text-center">
            <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mb-3">
              <Calendar className="w-6 h-6 text-green-600" />
            </div>
            <span className="text-2xl font-bold text-green-600 mb-1">
              {stats.uniqueDays}
            </span>
            <span className="text-sm text-green-600">
              days practiced
            </span>
          </div>

          <div className="bg-orange-50 rounded-lg p-4 flex flex-col items-center text-center">
            <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center mb-3">
              <span className="text-xl text-orange-600">🔥</span>
            </div>
            <span className="text-2xl font-bold text-orange-600 mb-1">
              {stats.streak}
            </span>
            <span className="text-sm text-orange-600">
              day streak
            </span>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm p-6">
        <ProgressChart totalMinutes={stats.totalMinutes} />
      </div>
    </div>
  );
}