import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { format } from 'date-fns';
import { Trophy, Clock, Calendar, ArrowLeft, Award, Heart, MessageSquare } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { UserBadge, UserComment, UserReaction } from '../types';
import { useAlerts } from '../hooks/useAlerts';

interface UserStats {
  user_id: string;
  current_streak: number;
  longest_streak: number;
  total_minutes: number;
  weekly_minutes: number;
  monthly_minutes: number;
  total_videos_watched: number;
  level: number;
  user_profiles?: {
    display_name: string;
    avatar_url: string;
    username: string;
    created_at: string;
  };
}

export function UserProfile() {
  const { id } = useParams<{ id: string }>();
  const { showSuccess, showError } = useAlerts();
  const [user, setUser] = useState<UserStats | null>(null);
  const [badges, setBadges] = useState<UserBadge[]>([]);
  const [comments, setComments] = useState<UserComment[]>([]);
  const [reactions, setReactions] = useState<UserReaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [newComment, setNewComment] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (id) {
      fetchUserData();
    }
  }, [id]);

  const fetchUserData = async () => {
    try {
      setLoading(true);
      
      // Fetch user stats and profile
      const { data: userData, error: userError } = await supabase
        .from('user_stats')
        .select(`
          *,
          user_profiles (
            display_name,
            avatar_url,
            username,
            created_at
          )
        `)
        .eq('user_id', id)
        .single();

      if (userError) throw userError;
      setUser(userData);

      // Fetch badges
      const { data: badgeData, error: badgeError } = await supabase
        .from('user_badges')
        .select('*')
        .eq('user_id', id);

      if (badgeError) throw badgeError;
      setBadges(badgeData || []);

      // Fetch comments
      const { data: commentData, error: commentError } = await supabase
        .from('user_comments')
        .select(`
          *,
          user_profiles (
            username,
            avatar_url
          )
        `)
        .eq('target_user_id', id)
        .order('created_at', { ascending: false });

      if (commentError) throw commentError;
      setComments(commentData || []);

      // Fetch reactions
      const { data: reactionData, error: reactionError } = await supabase
        .from('user_reactions')
        .select('*')
        .eq('target_user_id', id);

      if (reactionError) throw reactionError;
      setReactions(reactionData || []);

    } catch (error) {
      console.error('Error fetching user data:', error);
      showError('Failed to load user data');
    } finally {
      setLoading(false);
    }
  };

  const handleReaction = async (reaction: UserReaction['reaction']) => {
    try {
      const { data, error } = await supabase
        .from('user_reactions')
        .upsert({
          target_user_id: id,
          reaction
        })
        .select()
        .single();

      if (error) throw error;
      
      await fetchUserData();
      showSuccess('Reaction added!');
    } catch (error) {
      console.error('Error adding reaction:', error);
      showError('Failed to add reaction');
    }
  };

  const handleComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim()) return;

    try {
      setSubmitting(true);
      const { error } = await supabase
        .from('user_comments')
        .insert({
          target_user_id: id,
          content: newComment.trim()
        });

      if (error) throw error;

      setNewComment('');
      await fetchUserData();
      showSuccess('Comment posted!');
    } catch (error) {
      console.error('Error posting comment:', error);
      showError('Failed to post comment');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-500" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-12 text-center">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">User not found</h2>
        <Link
          to="/community"
          className="text-orange-500 hover:text-orange-600 font-medium"
        >
          Return to Community
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      {/* Back Button */}
      <Link
        to="/community"
        className="inline-flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-8"
      >
        <ArrowLeft className="w-5 h-5" />
        Back to Community
      </Link>

      {/* Profile Header */}
      <div className="bg-white rounded-lg shadow-sm p-8 mb-8">
        <div className="flex items-center gap-6">
          <div className="w-24 h-24 rounded-full bg-orange-100 flex items-center justify-center text-4xl font-bold text-orange-600">
            {user.user_profiles?.username?.[0]?.toUpperCase() || '?'}
          </div>
          <div>
            <h1 className="text-3xl font-bold mb-2">
              {user.user_profiles?.username && `@${user.user_profiles.username}`}
            </h1>
            <p className="text-gray-600">
              Member since {format(new Date(user.user_profiles?.created_at || ''), 'MMMM d, yyyy')}
            </p>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
          <div className="bg-blue-50 rounded-lg p-6 text-center">
            <Trophy className="w-8 h-8 text-blue-600 mx-auto mb-2" />
            <div className="text-2xl font-bold text-blue-600">{user.current_streak}</div>
            <div className="text-sm text-blue-600">Day Streak</div>
          </div>
          <div className="bg-green-50 rounded-lg p-6 text-center">
            <Clock className="w-8 h-8 text-green-600 mx-auto mb-2" />
            <div className="text-2xl font-bold text-green-600">{user.total_minutes}</div>
            <div className="text-sm text-green-600">Total Minutes</div>
          </div>
          <div className="bg-purple-50 rounded-lg p-6 text-center">
            <Calendar className="w-8 h-8 text-purple-600 mx-auto mb-2" />
            <div className="text-2xl font-bold text-purple-600">{user.total_videos_watched}</div>
            <div className="text-sm text-purple-600">Videos Watched</div>
          </div>
        </div>

        {/* Reactions */}
        <div className="flex items-center justify-center gap-4 mt-8">
          <button
            onClick={() => handleReaction('fire')}
            className="flex items-center gap-2 px-4 py-2 bg-orange-100 text-orange-600 rounded-full hover:bg-orange-200 transition-colors"
          >
            🔥 {reactions.filter(r => r.reaction === 'fire').length}
          </button>
          <button
            onClick={() => handleReaction('thumbsup')}
            className="flex items-center gap-2 px-4 py-2 bg-blue-100 text-blue-600 rounded-full hover:bg-blue-200 transition-colors"
          >
            👍 {reactions.filter(r => r.reaction === 'thumbsup').length}
          </button>
          <button
            onClick={() => handleReaction('celebrate')}
            className="flex items-center gap-2 px-4 py-2 bg-yellow-100 text-yellow-600 rounded-full hover:bg-yellow-200 transition-colors"
          >
            🎉 {reactions.filter(r => r.reaction === 'celebrate').length}
          </button>
        </div>
      </div>

      {/* Badges */}
      <div className="bg-white rounded-lg shadow-sm p-8 mb-8">
        <h2 className="text-xl font-bold mb-6 flex items-center gap-2">
          <Award className="w-6 h-6 text-orange-500" />
          Achievements
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {badges.map((badge) => (
            <div
              key={badge.id}
              className={`rounded-lg p-4 ${
                badge.tier === 'gold' ? 'bg-yellow-100 text-yellow-800' :
                badge.tier === 'silver' ? 'bg-gray-100 text-gray-800' :
                'bg-orange-100 text-orange-800'
              }`}
            >
              <div className="font-medium">{badge.badge_type}</div>
              <div className="text-sm mt-1">
                Earned {format(new Date(badge.earned_at), 'MMM d, yyyy')}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Comments */}
      <div className="bg-white rounded-lg shadow-sm p-8">
        <h2 className="text-xl font-bold mb-6 flex items-center gap-2">
          <MessageSquare className="w-6 h-6 text-orange-500" />
          Comments
        </h2>

        {/* Comment Form */}
        <form onSubmit={handleComment} className="mb-8">
          <textarea
            value={newComment}
            onChange={(e) => setNewComment(e.target.value)}
            placeholder="Leave a comment..."
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 resize-none"
            rows={3}
            maxLength={500}
          />
          <div className="flex justify-between items-center mt-2">
            <span className="text-sm text-gray-500">
              {newComment.length}/500 characters
            </span>
            <button
              type="submit"
              disabled={!newComment.trim() || submitting}
              className="px-4 py-2 bg-orange-500 text-white rounded-md hover:bg-orange-600 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {submitting ? 'Posting...' : 'Post Comment'}
            </button>
          </div>
        </form>

        {/* Comments List */}
        <div className="space-y-6">
          {comments.map((comment) => (
            <div key={comment.id} className="flex gap-4">
              <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center flex-shrink-0">
                {comment.user_profiles?.username?.[0]?.toUpperCase() || '?'}
              </div>
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-medium">
                    @{comment.user_profiles?.username}
                  </span>
                  <span className="text-sm text-gray-500">
                    {format(new Date(comment.created_at), 'MMM d, yyyy')}
                  </span>
                </div>
                <p className="text-gray-800">{comment.content}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}