import { useState, useCallback, useEffect } from 'react';
import { Alert } from '../components/AlertSystem';

export function useAlerts() {
  const [alerts, setAlerts] = useState<Alert[]>([]);

  const addAlert = useCallback((alert: Omit<Alert, 'id'>) => {
    const id = Math.random().toString(36).substring(7);
    const newAlert = { ...alert, id };
    setAlerts(prev => [newAlert, ...prev]);

    if (alert.duration !== 0) {
      setTimeout(() => {
        dismissAlert(id);
      }, alert.duration || 5000);
    }
  }, []);

  const dismissAlert = useCallback((id: string) => {
    setAlerts(prev => prev.filter(alert => alert.id !== id));
  }, []);

  const showError = useCallback((message: string, duration?: number) => {
    addAlert({ message, type: 'error', duration });
  }, [addAlert]);

  const showWarning = useCallback((message: string, duration?: number) => {
    addAlert({ message, type: 'warning', duration });
  }, [addAlert]);

  const showInfo = useCallback((message: string, duration?: number) => {
    addAlert({ message, type: 'info', duration });
  }, [addAlert]);

  const showSuccess = useCallback((message: string, duration?: number) => {
    addAlert({ message, type: 'success', duration });
  }, [addAlert]);

  return {
    alerts,
    dismissAlert,
    showError,
    showWarning,
    showInfo,
    showSuccess
  };
}