import { useEffect, useRef } from 'react';
import { realtimeManager } from '../lib/realtimeSubscription';

export function useRealtimeSubscription(
  table: string,
  onUpdate: () => void,
  onError?: (error: Error) => void
) {
  const onUpdateRef = useRef(onUpdate);
  onUpdateRef.current = onUpdate;

  useEffect(() => {
    const unsubscribe = realtimeManager.subscribe(
      table,
      () => onUpdateRef.current(),
      onError
    );
    return () => unsubscribe();
  }, [table, onError]);
}