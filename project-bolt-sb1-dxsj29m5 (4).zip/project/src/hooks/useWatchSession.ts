import { useState, useEffect } from 'react';
import { watchSessionManager } from '../lib/watchSession';
import { VideoWatchSession } from '../types';

export function useWatchSession(videoId: string | null) {
  const [session, setSession] = useState<VideoWatchSession | null>(null);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    let mounted = true;

    const initSession = async () => {
      if (!videoId) return;

      try {
        const newSession = await watchSessionManager.startSession(videoId);
        if (mounted && newSession) {
          setSession(newSession);
          setError(null);
        }
      } catch (err) {
        if (mounted) {
          setError(err instanceof Error ? err : new Error('Failed to start session'));
        }
      }
    };

    initSession();

    return () => {
      mounted = false;
      watchSessionManager.destroy();
    };
  }, [videoId]);

  const updateProgress = async (position: number) => {
    try {
      await watchSessionManager.updateProgress(position);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err : new Error('Failed to update progress'));
    }
  };

  const endSession = async () => {
    try {
      await watchSessionManager.endCurrentSession();
      setSession(null);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err : new Error('Failed to end session'));
    }
  };

  return {
    session,
    error,
    updateProgress,
    endSession
  };
}