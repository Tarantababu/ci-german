export type VideoLevel = 'superbeginner' | 'beginner' | 'intermediate' | 'advanced';

export interface Video {
  id: string;
  url: string;
  title: string;
  level: VideoLevel;
  tags: string[];
  duration_seconds: number;
  created_at: string;
  created_by: string;
  is_watched?: boolean;
  watched_videos?: { id: string }[];
}

export interface VideoTimeEntry {
  id: string;
  video_id: string;
  user_id: string;
  date: string;
  start_time: string;
  end_time: string;
  duration_seconds: number;
  notes?: string;
  created_at: string;
}

export interface VideoWatchSession {
  id: string;
  video_id: string;
  user_id: string;
  started_at: string;
  ended_at?: string;
  progress_seconds: number;
  is_complete: boolean;
  last_position_seconds: number;
  created_at: string;
}

export interface TimeEntry {
  id: string;
  date: string;
  minutes: number;
  activity_type: string;
  description?: string;
  video_id?: string;
}

export interface DailyTarget {
  id?: string;
  target_minutes: number;
}

export interface UserBadge {
  id: string;
  user_id: string;
  badge_type: string;
  tier: 'bronze' | 'silver' | 'gold';
  earned_at: string;
  metadata: Record<string, any>;
}

export interface UserReaction {
  id: string;
  user_id: string;
  target_user_id: string;
  reaction: 'fire' | 'thumbsup' | 'celebrate';
  created_at: string;
}

export interface UserComment {
  id: string;
  user_id: string;
  target_user_id: string;
  content: string;
  created_at: string;
  updated_at: string;
  user_profiles?: {
    username: string;
    avatar_url: string;
  };
}

export interface UserFriend {
  id: string;
  user_id: string;
  friend_id: string;
  status: 'pending' | 'accepted' | 'declined';
  created_at: string;
  updated_at: string;
}