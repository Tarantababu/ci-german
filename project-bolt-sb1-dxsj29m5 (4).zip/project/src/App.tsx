import React, { useEffect, useState } from 'react';
import { supabase } from './lib/supabase';
import { LandingPage } from './components/LandingPage';
import { AuthForm } from './components/AuthForm';
import { WatchPage } from './components/WatchPage';
import { Calendar } from './components/Calendar';
import { TimeEntryModal } from './components/TimeEntryModal';
import { DailyTargetModal } from './components/DailyTargetModal';
import { ActivityStats } from './components/ActivityStats';
import { ProfileSettings } from './components/ProfileSettings';
import { CommunityPage } from './components/CommunityPage';
import { Statistics } from './components/Statistics';
import { LevelsProgress } from './components/LevelsProgress';
import { HistoryPage } from './components/HistoryPage';
import { MethodPage } from './components/MethodPage';
import { AlertSystem } from './components/AlertSystem';
import { useAlerts } from './hooks/useAlerts';
import { TimeEntry, DailyTarget } from './types';
import { format } from 'date-fns';
import { LogOut, User, Clock, Play, Users, History, Globe2, Menu, X, Target, Coffee, Pencil, RefreshCw } from 'lucide-react';
import { useRealtimeSubscription } from './hooks/useRealtimeSubscription';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { ShareProgress } from './components/ShareProgress';

export default function App() {
  const { alerts, dismissAlert, showError, showSuccess } = useAlerts();
  const [session, setSession] = useState(null);
  const [showAuth, setShowAuth] = useState(false);
  const [entries, setEntries] = useState<TimeEntry[]>([]);
  const [dailyTarget, setDailyTarget] = useState<DailyTarget | null>(null);
  const [currentDate, setCurrentDate] = useState(new Date());
  const [isTimeEntryModalOpen, setIsTimeEntryModalOpen] = useState(false);
  const [isTargetModalOpen, setIsTargetModalOpen] = useState(false);
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [showProfileSettings, setShowProfileSettings] = useState(false);
  const [currentPage, setCurrentPage] = useState<'time' | 'watch' | 'community' | 'history'>('time');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
    });

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      if (session) {
        setShowAuth(false);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (session) {
      fetchTimeEntries();
      fetchDailyTarget();
    }
  }, [session]);

  useRealtimeSubscription('time_entries', () => {
    if (currentPage === 'time') {
      fetchTimeEntries();
    }
  });

  const fetchTimeEntries = async () => {
    try {
      const { data, error } = await supabase
        .from('time_entries')
        .select('*')
        .order('date', { ascending: false });

      if (error) {
        console.error('Error fetching time entries:', error);
        return;
      }

      setEntries(data || []);
    } catch (error) {
      console.error('Error handling time entries:', error);
    }
  };

  const fetchDailyTarget = async () => {
    try {
      const { data, error } = await supabase
        .from('daily_targets')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(1);

      if ((!data || data.length === 0) && !error) {
        const { data: newTarget, error: insertError } = await supabase
          .from('daily_targets')
          .insert({ target_minutes: 60 })
          .select()
          .single();

        if (insertError) throw insertError;
        setDailyTarget(newTarget);
        return;
      }

      if (error && error.code !== 'PGRST116') {
        console.error('Error fetching daily target:', error);
        return;
      }

      setDailyTarget(data?.[0] || { target_minutes: 60 });
    } catch (error) {
      console.error('Error handling daily target:', error);
      setDailyTarget({ target_minutes: 60 });
    }
  };

  const handleSignOut = async () => {
    try {
      await supabase.auth.signOut();
      setShowProfileMenu(false);
      setIsMobileMenuOpen(false);
      showSuccess('Successfully signed out');
    } catch (error) {
      showError('Failed to sign out');
    }
  };

  const getTodayMinutes = () => {
    const today = format(new Date(), 'yyyy-MM-dd');
    return entries
      .filter((entry) => entry.date === today)
      .reduce((sum, entry) => sum + entry.minutes, 0);
  };

  const handleStartLearning = () => {
    setShowAuth(true);
  };

  const handlePageChange = (page: 'time' | 'watch' | 'community' | 'history') => {
    setCurrentPage(page);
    setIsMobileMenuOpen(false);
  };

  if (!session) {
    return showAuth ? (
      <AuthForm />
    ) : (
      <LandingPage onStartLearning={handleStartLearning} />
    );
  }

  const NavLink = ({ page, icon: Icon, label }: { page: typeof currentPage; icon: any; label: string }) => (
    <Link
      to={page === 'time' ? '/' : `/${page}`}
      className={`flex items-center gap-2 px-4 py-2 rounded-md transition-colors ${
        currentPage === page 
          ? 'bg-orange-100 text-orange-600' 
          : 'hover:bg-gray-100'
      }`}
      onClick={() => handlePageChange(page)}
    >
      <Icon className="w-5 h-5" />
      <span>{label}</span>
    </Link>
  );

  const renderProfileMenu = () => (
    <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-10">
      <div className="px-4 py-2 text-sm text-gray-700 border-b">
        {session.user.email}
      </div>
      <button
        onClick={() => {
          setShowProfileMenu(false);
          setShowProfileSettings(true);
        }}
        className="flex items-center gap-2 w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
      >
        <User className="w-4 h-4" />
        Profile Settings
      </button>
      <a
        href="https://buymeacoffee.com/comprehensiblegerman"
        target="_blank"
        rel="noopener noreferrer"
        className="flex items-center gap-2 w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 cursor-pointer"
        title="Support this project with a coffee"
      >
        <Coffee className="w-4 h-4 text-orange-500" />
        Support my work
      </a>
      <button
        onClick={handleSignOut}
        className="flex items-center gap-2 w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
      >
        <LogOut className="w-4 h-4" />
        Sign out
      </button>
    </div>
  );

  const renderMobileMenu = () => (
    <div className="md:hidden border-t">
      <div className="px-4 py-2 space-y-1">
        <NavLink page="time" icon={Clock} label="Time" />
        <NavLink page="watch" icon={Play} label="Watch" />
        <NavLink page="history" icon={History} label="History" />
        <NavLink page="community" icon={Users} label="Community" />
        <button
          onClick={() => {
            setIsMobileMenuOpen(false);
            setShowProfileSettings(true);
          }}
          className="flex items-center gap-2 w-full px-4 py-2 rounded-md hover:bg-gray-100"
        >
          <User className="w-5 h-5" />
          Profile Settings
        </button>
        <a
          href="https://buymeacoffee.com/comprehensiblegerman"
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-2 w-full px-4 py-2 rounded-md hover:bg-gray-100"
          title="Support this project with a coffee"
        >
          <Coffee className="w-5 h-5 text-orange-500" />
          Support my work
        </a>
        <button
          onClick={handleSignOut}
          className="flex items-center gap-2 w-full px-4 py-2 rounded-md hover:bg-gray-100"
        >
          <LogOut className="w-5 h-5" />
          Sign out
        </button>
      </div>
    </div>
  );

  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        <AlertSystem alerts={alerts} onDismiss={dismissAlert} />
        
        {/* Header */}
        <div className="bg-white border-b sticky top-0 z-50">
          <div className="max-w-7xl mx-auto px-4 py-2">
            <div className="flex justify-between items-center h-14">
              <div className="flex items-center gap-2">
                <Globe2 className="w-8 h-8 text-orange-500" />
                <span className="text-xl font-medium">ComprehensibleGerman</span>
              </div>
              
              {/* Desktop Navigation */}
              <div className="hidden md:flex items-center gap-2">
                <NavLink page="time" icon={Clock} label="Time" />
                <NavLink page="watch" icon={Play} label="Watch" />
                <NavLink page="history" icon={History} label="History" />
                <NavLink page="community" icon={Users} label="Community" />
                
                {/* Profile Menu */}
                <div className="relative ml-2">
                  <button
                    onClick={() => setShowProfileMenu(!showProfileMenu)}
                    className="p-2 rounded-full hover:bg-gray-100"
                  >
                    <User className="w-6 h-6" />
                  </button>
                  
                  {showProfileMenu && renderProfileMenu()}
                </div>
              </div>

              {/* Mobile Menu Button */}
              <button
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="md:hidden p-2 rounded-lg hover:bg-gray-100"
              >
                {isMobileMenuOpen ? (
                  <X className="w-6 h-6" />
                ) : (
                  <Menu className="w-6 h-6" />
                )}
              </button>
            </div>
          </div>

          {/* Mobile Navigation */}
          {isMobileMenuOpen && renderMobileMenu()}
        </div>

        <Routes>
          <Route path="/method" element={<MethodPage />} />
          <Route path="/community" element={<CommunityPage currentUserId={session.user.id} />} />
          <Route path="/watch" element={<WatchPage />} />
          <Route path="/history" element={<HistoryPage />} />
          <Route path="/" element={
            <div className="min-h-screen bg-gray-50 pb-12">
              {/* Daily Goal Banner */}
              <div className="bg-gradient-to-r from-orange-500 to-orange-600 text-white border-b">
                <div className="max-w-7xl mx-auto">
                  <div 
                    className="flex items-center justify-between px-4 py-4 cursor-pointer hover:bg-white/5 transition-colors"
                    onClick={() => setIsTargetModalOpen(true)}
                  >
                    <div className="flex items-center gap-3">
                      <Target className="w-5 h-5" />
                      <div>
                        <div className="text-sm text-white/90">Daily Goal Progress</div>
                        <div className="font-medium">
                          {getTodayMinutes()}/{dailyTarget?.target_minutes || 60} minutes
                        </div>
                      </div>
                    </div>
                    <button className="text-white/80 hover:text-white">
                      <Pencil className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>

              <div className="max-w-7xl mx-auto px-4 py-8 space-y-8">
                {/* Quick Actions */}
                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                    <div className="flex items-center gap-4">
                      <div className="bg-orange-100 p-3 rounded-full">
                        <Target className="w-6 h-6 text-orange-600" />
                      </div>
                      <div>
                        <h2 className="text-lg font-medium text-gray-900">Track Your Progress</h2>
                        <p className="text-gray-600">
                          Add your daily German learning activities
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 self-stretch sm:self-auto">
                      <button
                        onClick={() => {
                          fetchTimeEntries();
                          fetchDailyTarget();
                        }}
                        className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-full transition-all duration-200"
                        aria-label="Refresh data"
                        title="Refresh data"
                      >
                        <RefreshCw className="w-5 h-5" />
                      </button>
                      <ShareProgress
                        username={session.user.email?.split('@')[0] || ''}
                        stats={{
                          level: Math.floor(entries.reduce((sum, entry) => sum + entry.minutes, 0) / 3600),
                          totalMinutes: entries.reduce((sum, entry) => sum + entry.minutes, 0),
                          streak: entries.filter(entry => entry.date === format(new Date(), 'yyyy-MM-dd')).length > 0 ? 1 : 0,
                          videosWatched: entries.filter(entry => entry.activity_type === 'watching').length
                        }}
                        achievements={[]}
                      />
                      <button
                        onClick={() => setIsTimeEntryModalOpen(true)}
                        className="flex-1 sm:flex-none px-6 py-2.5 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-colors font-medium"
                      >
                        Add Time
                      </button>
                    </div>
                  </div>
                </div>

                {/* Statistics and Progress */}
                <Statistics entries={entries} />

                {/* Level Progress and Activity */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  <LevelsProgress 
                    totalHours={Math.floor(entries.reduce((sum, entry) => sum + entry.minutes, 0) / 60)}
                    dailyGoalMinutes={dailyTarget?.target_minutes || 60}
                  />
                  <div className="bg-white rounded-xl p-8 shadow-sm border border-gray-100">
                    <div className="flex justify-between items-center mb-6">
                      <h2 className="text-2xl font-bold text-gray-900">Your Activity</h2>
                      <div className="flex gap-2">
                        <button 
                          onClick={() => {
                            const newDate = new Date(currentDate);
                            newDate.setMonth(currentDate.getMonth() - 1);
                            setCurrentDate(newDate);
                          }}
                          className="text-orange-500 hover:text-orange-600"
                        >
                          ←
                        </button>
                        <span className="font-medium">{format(currentDate, 'MMMM - yyyy')}</span>
                        <button 
                          onClick={() => {
                            const newDate = new Date(currentDate);
                            newDate.setMonth(currentDate.getMonth() + 1);
                            setCurrentDate(newDate);
                          }}
                          className="text-orange-500 hover:text-orange-600"
                        >
                          →
                        </button>
                      </div>
                    </div>
                    <div className="space-y-8">
                      <ActivityStats entries={entries} />
                      <Calendar
                        entries={entries}
                        currentDate={currentDate}
                        onDateChange={setCurrentDate}
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Modals */}
              <TimeEntryModal
                isOpen={isTimeEntryModalOpen}
                onClose={() => setIsTimeEntryModalOpen(false)}
                onSave={() => {
                  fetchTimeEntries();
                }}
              />

              <DailyTargetModal
                isOpen={isTargetModalOpen}
                onClose={() => setIsTargetModalOpen(false)}
                currentTarget={dailyTarget?.target_minutes || 60}
                onSave={() => {
                  fetchDailyTarget();
                }}
              />
            </div>
          } />
        </Routes>

        <ProfileSettings
          isOpen={showProfileSettings}
          onClose={() => setShowProfileSettings(false)}
        />
      </div>
    </Router>
  );
}